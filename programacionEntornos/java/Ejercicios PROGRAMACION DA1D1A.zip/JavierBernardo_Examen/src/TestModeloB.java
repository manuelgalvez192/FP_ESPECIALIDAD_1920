import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class TestModeloB {
	private int a,b,c;
	private int esperado;
	
	public TestModeloB(int a,int b, int c, int esperado) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.esperado = esperado;
	}
	
	@Parameters(name="TestModeloB({0}, {1}, {2}) = {3}")
	public static Collection<Object[]> datos() {
		
		Object[][] datos = new Object[][] { {2,1,0,3}, {4,3,0,7}, {4,1,3,8}, {4,1,-2,2} };
		return Arrays.asList(datos);
	}
	
	@Test
	public void test() {
		assertEquals(esperado, ModeloB.metodoA(a,b,c));
	}

}
