
public class ModeloB {

	public static int metodoA (int a, int b, int c) {
		if(a<3 || b>2) {
			return a+b;
		}
		else if(c>0) {
			return a+b+c;
		}
		else {
			return -1 * c;
		}

	}

}
