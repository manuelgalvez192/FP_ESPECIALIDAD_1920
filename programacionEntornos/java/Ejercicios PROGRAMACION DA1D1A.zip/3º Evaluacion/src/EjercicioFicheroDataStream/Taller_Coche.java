package EjercicioFicheroDataStream;

public class Taller_Coche {
	private int codigoparte;
	private String descripcion;
	private String matricula;
	private double precio;
	private String mes;
	
	public Taller_Coche(int codigoparte, String descripcion, String matricula, double precio, String mes) {
		this.codigoparte = codigoparte;
		this.descripcion = descripcion;
		this.matricula = matricula;
		this.precio = precio;
		this.mes = mes;
	}

	public int getCodigoparte() {
		return codigoparte;
	}

	public void setCodigoparte(int codigoparte) {
		this.codigoparte = codigoparte;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	
	
}
