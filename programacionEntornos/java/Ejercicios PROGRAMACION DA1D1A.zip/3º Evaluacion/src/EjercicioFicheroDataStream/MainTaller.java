package EjercicioFicheroDataStream;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class MainTaller {

	public static void main(String[] args) throws IOException{
		Scanner teclado = new Scanner(System.in);
		int codparte=0;
		String desc="", mes="", matr="";
		double precio=0;
		String dataFile = "src/EjercicioFicheroDataStream/Taller.dat";
		DataOutputStream out = null;
		DataInputStream in = null;
		Taller_Coche c = null;
		
		try {
			out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(dataFile)));
			
			for(int i=0; i<30; i++) {
				
				System.out.println("CodParte:  ");
				codparte = Integer.parseInt(teclado.nextLine());
				System.out.println("Desc: ");
				desc = teclado.nextLine();
				System.out.println("Matricula: ");
				matr = teclado.nextLine();
				System.out.println("Precio: ");
				precio = teclado.nextDouble();
				System.out.println("Mes: ");
				mes = teclado.nextLine();
				teclado.nextLine();
				c = new Taller_Coche(codparte,desc,matr, precio, mes);
				
			}
				
				
				
				
		}finally {
			out.close();
		}

	}

}
