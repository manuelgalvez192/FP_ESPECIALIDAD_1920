package EjercicioFicheroDataStream;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Taller {
	
	static final String dataFile = "taller.dat";
	
	public static void escribirCoche(DataOutputStream out, Taller_Coche c) {
		DataInputStream in = null;
		int codparte=0, codAEscribir=-1;
		String descripcion;
		String matricula;
		double precio;
		String mes;
		boolean encontrado=false;
		try {
			in = new DataInputStream(new BufferedInputStream(new FileInputStream(dataFile)));
			
			while(true) {
				codparte = in.readInt();
				in.readUTF();
				matricula = in.readUTF();
				in.readDouble();
				in.readUTF();
				if(matricula.equals(c.getMatricula())) {
					encontrado = true;
					codAEscribir = codparte;
				}
			}
		} catch (IOException e) {
			if(encontrado) {
				try {
					out.writeInt(codAEscribir);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			else {
				try {
					out.writeInt(codparte);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
			try {
				out.writeUTF(c.getDescripcion());
				out.writeUTF(c.getMatricula());
				out.writeDouble(c.getPrecio());
				out.writeUTF(c.getMes());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
	}
}
