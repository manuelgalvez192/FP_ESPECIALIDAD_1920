package EjercicioFicheroDataStream;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class MainLibroDAT {

	public static void main(String[] args) throws IOException{
		Scanner teclado = new Scanner(System.in);
		String dataFile = "src/EjercicioFicheroDataStream/Libro.dat";
		DataOutputStream out = null;
		DataInputStream in = null;
		int id_cod=0, cont=3, cont2=0;
		double suma=0, media=0, nuevo=0;
		double[] precio = new double[100];
		
		
		try {
			out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(dataFile)));
			
			while(cont != 0) {
				System.out.println("Introduzca id del libro: ");
				id_cod = teclado.nextInt();
				System.out.println("Introduzca el precio del libro: ");
				precio[cont2] = teclado.nextDouble();
				System.out.println("�Desea continuar?(0/1)(No/Si)");
				cont = teclado.nextInt();
				
				suma +=precio[cont2];
				cont2++;
			}
			
			media = suma/cont2;
			for(int j=0; j<precio.length;j++) {
				if(precio[j] > media) {
					nuevo = precio[j] - (precio[j]*0.15);
					out.writeDouble(nuevo);
				}
			}
		} finally {
			System.out.println("Media: " + media + " Suma: "+suma);
			out.close();
		}
		
	}

}
