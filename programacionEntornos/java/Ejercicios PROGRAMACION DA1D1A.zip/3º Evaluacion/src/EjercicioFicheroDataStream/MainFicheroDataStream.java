package EjercicioFicheroDataStream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class MainFicheroDataStream {

	public static void main(String[] args) throws IOException {
		//teclado, min, max parejas de valores, numeros reales que son temperaturas hasta que ya no pida mas
		//guardar valores en fichero de bytes, leyendo del fichero mostrar la temperatura mas alta y baja almacenada 
		//e indicar el orden de pareja que aparece
		
		Scanner teclado = new Scanner(System.in);
		String dataFile = "src/EjercicioFicheroDataStream/DataStream";
		DataOutputStream out = null;
		DataInputStream in = null;
		String ciudad="", estacion = "", ciu="", esta = "";
		double min=0, max=0, maxi = 0, mini=0;
		int dia=1,d=0, cont=3;
		try {
			out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(dataFile)));
			
			while(cont !=0) {
				System.out.println("Introduzca temperatura minima: ");
				min = teclado.nextDouble();
				System.out.println("Introduzca temperatura maxima: ");
				max = teclado.nextDouble();
				out.writeInt(dia);
				out.writeDouble(min);
				out.writeDouble(max);
				teclado.nextLine();
				System.out.println("Introduzca la estacion: ");
				estacion = teclado.nextLine();
				System.out.println("Introduzca la ciudad: ");
				ciudad = teclado.nextLine();
				out.writeUTF(estacion);
				out.writeUTF(ciudad);
				System.out.println("�Desea continuar?(0/1)(No/Si)");
				cont = teclado.nextInt();
				dia++;
			}	
		} finally {
			out.close();
		}
		
		try {
			in = new DataInputStream(new BufferedInputStream(new FileInputStream(dataFile)));
			 double minimo, maximo;
	         int day;
	         String s;
	         day = in.readInt();
             minimo = in.readDouble();
             maximo = in.readDouble();
             esta = in.readUTF();
             ciu = in.readUTF();
             maxi = maximo;
             mini = minimo;
	          while (true) {
	              day = in.readInt();
	              minimo = in.readDouble();
	              maximo = in.readDouble();
	              if(maximo > maxi) {
	            	  maxi = maximo;
	            	  d = day;
	              }
	              if(minimo < mini) {
	            	  mini = minimo;
	            	  d = day;
	              }
	              System.out.format("Dia: %d" + " Minimo: %.1f" + " Maximo: %.1f", day, minimo, maximo);
	              System.out.println();
	          }
		}catch(EOFException e){
			
		}finally {
			System.out.format("Temperatura maxima: %.1f" + " y dia: %d", maxi, d);
			System.out.format("Temperatura minima: %.1f" + " y dia: %d", mini, d);
			in.close();
		}
		
		
		
	}

}
