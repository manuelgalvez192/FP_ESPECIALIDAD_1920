package EjerciciosRandomAccessFile;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class MainAgenda {
	// AGENDA:
	// CONTACTO: NUMREGISTRO, NOMBRE, APELLIDO, TLFNO
	// 1- A�ADIR CONTACTO
	// 2- MODIFICAR TELEFONO DADO EL NUMERO DE REGISTRO
	// 3- LISTAR NOMBRES Y APELLIDOS DE LOS CONTACTOS QUE TENGAN UN TELEFONO DADO
	// 4- SALIR
	public static void main(String[] args) throws IOException{
		RandomAccessFile r = new RandomAccessFile("src/EjerciciosRandomAccessFile/Agenda.txt", "rw");
		Scanner teclado = new Scanner(System.in);
		int opcion=0, numreg=0, postlfno=0, pos=0;
		String nombre = "", apellido = "", tlfno = "", tlfno2 = "";
		Contacto c1 = null;
		
		
		while(opcion != 4) {
			System.out.println("Elija opcion: ");
			System.out.println("1. A�ADIR CONTACTO");
			System.out.println("2. MODIFICAR TELEFONO DADO EL NUMERO DE REGISTRO");
			System.out.println("3. LISTAR NOMBRES Y APELLIDOS DE LOS CONTACTOS QUE TENGAN UN TELEFONO DADO");
			System.out.println("4. Salir");
			opcion = teclado.nextInt();
			
			switch(opcion) {
			
			case 1:
				r.seek(r.length());
				teclado.nextLine();
				System.out.println("Introduzca el nombre");
				nombre = teclado.nextLine();
				System.out.println("Introduzca el apellido");
				apellido = teclado.nextLine();
				System.out.println("Introduzca el tlfno");
				tlfno = teclado.nextLine();
				
				for(int i=nombre.length(); i<20;i++) {
					nombre += '*';
				}
				for(int i=apellido.length(); i<20;i++) {
					apellido += '*';
				}
				for(int i=tlfno.length(); i<10;i++) {
					tlfno += '*';
				}
				
				c1 = new Contacto(nombre, apellido, tlfno);
				r.writeInt(c1.getI());
				r.writeChars(c1.getNombre());
				r.writeChars(c1.getApellido());
				r.writeChars(c1.getTlfno());
				r.writeChars("\n");
							
				System.out.println("Puntero: " + r.getFilePointer());
				break;
			case 2:
				teclado.nextLine();
				System.out.println("Introduzca el numero de registro del contacto a modificar: ");
				numreg = teclado.nextInt();
				teclado.nextLine();
				postlfno = (numreg * 106)+ 84;
				r.seek(postlfno);
				System.out.println("Puntero: " + r.getFilePointer());
				System.out.println("Introduzca nuevo telefono: ");
				tlfno2 = teclado.nextLine();
				for(int i=tlfno2.length(); i<10;i++) {
					tlfno2 += '*';
				}
				r.writeChars(tlfno2);
				
				break;
			case 3:
				
				break;
			case 4:
				break;
				
			}
			
		}

		
		
		
		
		teclado.close();
	}

}
