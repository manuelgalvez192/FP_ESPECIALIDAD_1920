package EjerciciosRandomAccessFile;


import java.io.IOException;
import java.io.RandomAccessFile;

public class Ejemplo1RandomAccessFile {

	public static void main(String[] args) throws IOException {
		RandomAccessFile r = new RandomAccessFile("src/EjerciciosRandomAccessFile/ficherin.dat", "rw");
		String s, leido = "";
		
		s = "Alberto";
		
		for(int i=s.length(); i<50;i++) {
			s+='*';
		}
		
		r.writeChars(s);
		System.out.println("Puntero: "+r.getFilePointer());
		r.seek(0);
		for(int i=0;i<50;i++) {
			leido += r.readChar();
		}
		
		System.out.println("Leido: "+leido);
		leido = leido.substring(0, leido.indexOf('*'));
		System.out.println("Leido: "+leido);
		
	
		
		
	}

}
