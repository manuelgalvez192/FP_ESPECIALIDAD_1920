package EjerciciosRandomAccessFile;

import java.time.LocalDate;

public class Factura {
	private String fecha;
	private int id_cliente;
	private Double total;
	
	public Factura(int id_cliente, Double total) {
		this.fecha = LocalDate.now().toString();
		this.id_cliente = id_cliente;
		this.total = total;
	}

	public Factura(String fecha, int id_cliente, Double total) {
		this.fecha = fecha;
		this.id_cliente = id_cliente;
		this.total = total;
	}
	
	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public Double getTotal() {
		return total;
	}

	public void setTotal(Double total) {
		this.total = total;
	}

	public int getId_cliente() {
		return id_cliente;
	}

	public void setId_cliente(int id_cliente) {
		this.id_cliente = id_cliente;
	}
	
	public int comparar(Factura f) {
		
		return 0;
	}
	
}	
