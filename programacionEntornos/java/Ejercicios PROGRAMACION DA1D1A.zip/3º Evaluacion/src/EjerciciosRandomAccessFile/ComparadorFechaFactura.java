package EjerciciosRandomAccessFile;

import java.util.Comparator;

public class ComparadorFechaFactura implements Comparator<Factura>{

	@Override
	public int compare(Factura f1, Factura f2) {
		if(f1.comparar(f2)>0) {
			return 1;
		}
		else if(f1.comparar(f2) == 0) {
			return 0;
		}
		else {
			return -1;
		}
		
	}

}
