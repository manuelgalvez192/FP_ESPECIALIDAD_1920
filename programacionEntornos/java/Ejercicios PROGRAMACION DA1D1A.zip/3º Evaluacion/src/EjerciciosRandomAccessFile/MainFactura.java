package EjerciciosRandomAccessFile;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MainFactura {
	final static int LONGITUD_REGISTRO = 32;

	public static void main(String[] args) throws IOException {
		/*Aplicaci�n que gestione facturas en un fichero binario de acceso aleatorio. Datos de una factura: id que coincide con el n�mero de registro en el fichero, fecha (la actual; se obtiene autom�ticamente),id de cliente, total.

		1.A�adir factura (datos por teclado: id cliente y total)

		2.Modificar total dado id

		3.Volcar a otro fichero las facturas que superen 1000�

		4.Volcar a otro fichero las facturas posteriores a 12/10/2000 ordenadas por fecha. Se supondr� que hay m�ximo 200.

		5. Salir*/
		RandomAccessFile r = new RandomAccessFile("src/EjerciciosRandomAccessFile/Factura.txt", "rw");
		RandomAccessFile totales = new RandomAccessFile("src/EjerciciosRandomAccessFile/Factura>1000.txt", "rw");
		RandomAccessFile ordenadas = new RandomAccessFile("src/EjerciciosRandomAccessFile/FacturaOrdenada.txt", "rw");
		Scanner teclado = new Scanner(System.in);
		int opcion = 0, pos=0;
		String id_cl, total, total2;
		Factura fac = null; 
	
		
		
			while(opcion!= 6) {
				System.out.println("Elije opcion: ");
				System.out.println("1. A�adir factura");
				System.out.println("2. Modificar total dado id");
				System.out.println("3. Volcar a otro fichero las facturas que superen 1000�");
				System.out.println("4. Volcar a otro fichero las facturas posteriores a 12/10/2000 ordenadas por fecha. Se supondr� que hay m�ximo 200.");
				System.out.println("5. Salir");
				opcion = teclado.nextInt();
				
				switch(opcion) {
				
				case 1:
					
					System.out.println("Introduzca el id del cliente: ");
					id_cl = teclado.nextLine();
					System.out.println("Introduzca el total: ");
					total = teclado.nextLine();
					
					fac = new Factura(Integer.parseInt(id_cl), Double.parseDouble(total));
					guardar(r, fac);
					break;
				case 2:
					System.out.println("Introduzca posicion: ");
					pos = Integer.parseInt(teclado.nextLine());
					System.out.println("Introduzca nuevo total: ");
					total2 = teclado.nextLine();
					modificar(r, pos, Double.parseDouble(total2));
					break;
				case 3:
					volcar(r,totales);
					break;
				case 4:
					ordenarConVolcado(r, ordenadas);
					break;
				case 5:
					System.out.println("Adios");
					break;
					
				}
				
				
				
			}

		
		teclado.close();
	}
	
	public static void guardar (RandomAccessFile r, Factura f) throws IOException {
		
		r.seek(r.length());
		r.writeChars(f.getFecha().toString());
		r.writeInt(f.getId_cliente());
		r.writeDouble(f.getTotal());
		
		//Total bytes por factura 20 + 4 + 8 = 32 bytes
	}
	public static void modificar (RandomAccessFile r, int pos, double total2) throws IOException {
		r.seek((LONGITUD_REGISTRO * pos)+24);
		r.writeDouble(total2);
	}
	
	public static void volcar (RandomAccessFile r, RandomAccessFile totales) throws IOException{
		double total;
		String fecha="";
		int id=0;
		try{
			r.seek(0);
			totales.seek(0);
			int pos=0;
			while(true) {
				r.seek((LONGITUD_REGISTRO * pos)+24);
				total = r.readDouble();
				if(total > 1000) {
					r.seek(LONGITUD_REGISTRO * pos);
					fecha = "";
					for(int i=0; i<10;i++) {
						fecha += r.readChar();
					}
					id = r.readInt();
					totales.writeChars(fecha);
					totales.writeInt(id);
					totales.writeDouble(total);
				}
				pos++;
			}
		}catch(EOFException e) {
			
		}finally {
			totales.close();
		}
	}
	public static void ordenarConVolcado(RandomAccessFile r, RandomAccessFile ordenadas) throws IOException{
		double total;
		String fecha="";
		int id=0;
		ArrayList<Factura> facturas = new ArrayList<>();
		Factura faux = new Factura("2000-10-02", 0, 0.0);
		try{
			r.seek(0);
			ordenadas.seek(0);
			int pos=0;
			while(true) {
				r.seek((LONGITUD_REGISTRO * pos));
				fecha = "";
				for(int i=0; i<10;i++) {
					fecha += r.readChar();
				}
				if(faux.comparar(new Factura(fecha, 0, 0.0))>0) {
					id = r.readInt();
					total = r.readDouble();
					facturas.add(new Factura(fecha, id, total));
				}
				pos++;
			}
		}catch(EOFException e) {
			Collections.sort(facturas, new ComparadorFechaFactura());
			for(Factura f: facturas) {
				ordenadas.writeChars(f.getFecha());
				ordenadas.writeInt(f.getId_cliente());
				ordenadas.writeDouble(f.getTotal());
			}
		}finally {
			ordenadas.close();
		}
	}
	
	
	
	
	
	
	
	
	
	
}
