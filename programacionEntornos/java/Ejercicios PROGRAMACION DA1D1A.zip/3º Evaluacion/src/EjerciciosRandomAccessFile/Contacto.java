package EjerciciosRandomAccessFile;

public class Contacto {
	private static int id;
	private String nombre;
	private String apellido;
	private String tlfno;
	private int i=0;
	
	public Contacto(String nombre, String apellido, String tlfno) {
		this.id = i;
		this.nombre = nombre;
		this.apellido = apellido;
		this.tlfno = tlfno;
		i++;
	}

	public static int getId() {
		return id;
	}

	public static void setId(int id) {
		Contacto.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getTlfno() {
		return tlfno;
	}

	public void setTlfno(String tlfno) {
		this.tlfno = tlfno;
	}

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}
	
	
}
