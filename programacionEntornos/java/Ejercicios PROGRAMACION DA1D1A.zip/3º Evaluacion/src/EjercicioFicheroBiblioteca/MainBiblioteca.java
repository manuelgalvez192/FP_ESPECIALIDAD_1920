package EjercicioFicheroBiblioteca;

import java.io.RandomAccessFile;

public class MainBiblioteca {

	public static void main(String[] args) {
		/* 
		
		Consultar titulos disponibles. Buscar libros por titulo disponibles. 
		Buscar libros por titulo TODOS (los prestados poner CUANDO SE DEVUELVEN). Mostrar todos los ejemplares al buscar
		Buscar por autor (disponibles y no (cuando se devuelven)). Mostrar todos los ejemplares al buscar
	
		 */

	}
	
	public void consultarDisponibles() {
		
	}
	public void buscarTitulos(RandomAccessFile r) {
		
	}
}
