package EjercicioSerializable;

import java.io.Serializable;

public class Alumno implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int numexp;
	private String nombre;
	
	public Alumno(int numexp, String nombre) {
		this.numexp = numexp;
		this.nombre = nombre;
	}

	public int getNumexp() {
		return numexp;
	}

	public void setNumexp(int numexp) {
		this.numexp = numexp;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Numexp: " + numexp + " Nombre: " + nombre;
	}
	
	
}
