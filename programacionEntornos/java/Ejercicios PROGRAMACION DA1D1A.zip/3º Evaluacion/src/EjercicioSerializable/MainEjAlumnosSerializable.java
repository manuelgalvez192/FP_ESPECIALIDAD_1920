package EjercicioSerializable;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class MainEjAlumnosSerializable {

	static final String dataFile = "src/EjercicioSerializable/AlumnosSerializable";
	
	public static void main(String[] args) throws IOException, ClassNotFoundException{
		// array list de alumnos(num expendiente, nombre), preguntar si quiere guardar en fichero, 
		// dos opciones si acepta: guardar uno a uno o guardar el array list como array

		//recuperar valores uno a uno o todos de golpe, fallara si se guarda como arraylist y pide sacarlos uno a uno
		ArrayList<Alumno> al = new ArrayList<>(); 
		Scanner teclado = new Scanner(System.in);
		String opcion="", opcion2="", opcion3="";
		
		for(int i=0;i<10;i++) {
			al.add(new Alumno(i, "Alumno"+i));
		}
		
		ObjectOutputStream out = null;
		ObjectInputStream in = null;
		
		System.out.println("�Desea guardarlo en fichero?");
		opcion = teclado.nextLine();
		
		if(opcion.equals("Si") || opcion.equals("si")) {
			System.out.println("�Datos uno a uno o en array?");
			opcion2 = teclado.nextLine();
			
			if(opcion2.equals("Uno a uno")||opcion2.equals("uno a uno")) {
				try {
		            out = new ObjectOutputStream(new
		                    BufferedOutputStream(new FileOutputStream(dataFile)));
		            
		            for(int j=0; j<al.size();j++) {
		            	out.writeObject(al.get(j));
		            	out.writeUTF("\n");
		            }
		            
		        } finally {
		            out.close();
		        }
			}
			if(opcion2.equals("En array")||opcion2.equals("en array")) {
				try {
		            out = new ObjectOutputStream(new
		                    BufferedOutputStream(new FileOutputStream(dataFile)));
		            out.writeObject(al);		            
		            
		        } finally {
		            out.close();
		        }
			}
		}
		else {
			System.out.println("Adios");
		}
		
		if(opcion.equals("Si") || opcion.equals("si")) {
			System.out.println("�Mostrar datos uno a uno o en array?");
			opcion3= teclado.nextLine();
		
					
			if(opcion3.equals("Uno a uno")||opcion3.equals("uno a uno")) {
				try {
		            in = new ObjectInputStream(new
		                    BufferedInputStream(new FileInputStream(dataFile)));
		            Alumno alum = null;
				     try {
				          while(true) {
				            alum = (Alumno) in.readObject();
					        in.readUTF();
					        System.out.println(alum.toString());
				          }
			
				     	} catch (EOFException e) {
				     		System.out.println("Fin del fichero");
				     	}
			     } finally {
			    	
			    	 in.close();
			     }
			}     
			if(opcion3.equals("En array")||opcion3.equals("en array")) {
				try {
		            in = new ObjectInputStream(new
		                    BufferedInputStream(new FileInputStream(dataFile)));
		            ArrayList<Alumno> aux = new ArrayList<>();
				    aux = (ArrayList<Alumno>) in.readObject();
				    for(int k=0; k<aux.size();k++) {
				    	System.out.println(aux.get(k).toString());
				    }
			     }catch(OptionalDataException e){
			    	 System.out.println("No es posible de leer");
			     }finally {		    	
			    	 in.close();
			     }
				
			}     
		}
		teclado.close();
	}

}
