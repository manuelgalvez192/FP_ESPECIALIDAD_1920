
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class EjemploBBDD {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		//tabla con 3 campos, 5 filas y pedidos los datos por teclado
		Connection connection = null;

        try {

            connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@LAPTOP-436KIQSS:1521:xe", "system", "titi1304");

        } catch (SQLException e) {

            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
            return;

        }

        if (connection != null) {
            System.out.println("You made it, take control your database now!");
        } else {
            System.out.println("Failed to make connection!");
        }
        
		    String createString =
		        "create table " + "system" +
		        ".TABLA2 " +
		        "(ID integer NOT NULL, " +
		        "NAME varchar(40) NOT NULL, " +
		        "TELEFONO varchar(40) NOT NULL, " +
		        "PRIMARY KEY (ID))";

		    Statement stmt = null;
		    try {
		        stmt = connection.createStatement();
		        System.out.println(createString);
		        stmt.executeUpdate(createString);
		    } catch (SQLException e) {
		        System.out.println(e);
		    } finally {
		        if (stmt != null) { 
		        	stmt.close(); 
		        	
		        }
		    }
		}
	

}
