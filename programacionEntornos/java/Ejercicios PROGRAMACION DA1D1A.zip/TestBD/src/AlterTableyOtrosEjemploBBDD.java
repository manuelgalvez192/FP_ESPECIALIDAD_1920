import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class AlterTableyOtrosEjemploBBDD {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		//tabla con 3 campos, 5 filas y pedidos los datos por teclado, update, alter table, drop table, delete table
		Connection connection = null;

        try {

            connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@LAPTOP-436KIQSS:1521:xe", "system", "titi1304");

        } catch (SQLException e) {

            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
            return;

        }

        if (connection != null) {
            System.out.println("You made it, take control your database now!");
        } else {
            System.out.println("Failed to make connection!");
        }
        	
        String createString =
        		"ALTER TABLE " +  "TABLA1 " +
		                "DROP COLUMN " + "TRABAJO";
        String delete = "DROP TABLE TABLA1 ";
        
		    Statement stmt = null;
		    try {
		        stmt = connection.createStatement();
//		        stmt.executeUpdate(
//		                "update table " + "system" +
//		                ".TABLA1 " +
//		                "set (ID = 8)" + "where (nombre = 'Javier')"
//		                );
//		        System.out.println(createString);
//		        stmt.executeUpdate(createString);
		        System.out.println(delete);
		        stmt.executeUpdate(delete);             
		                		

		    } catch (SQLException e) {
		       System.out.println(e);
		    } finally {
		        if (stmt != null) { 
		        	stmt.close(); 
		        	connection.close();
		        }
		    }
		}

	}