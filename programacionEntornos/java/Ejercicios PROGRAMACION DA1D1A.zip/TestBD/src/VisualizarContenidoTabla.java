import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;

public class VisualizarContenidoTabla {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VisualizarContenidoTabla window = new VisualizarContenidoTabla();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		}
			

	/**
	 * Create the application.
	 */
	public VisualizarContenidoTabla() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(10, 38, 391, 82);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Ver Contenido");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				  Connection connection = null;
				  Statement stmt = null;
				  try {
					connection = DriverManager.getConnection(
					            "jdbc:oracle:thin:@LAPTOP-436KIQSS:1521:xe", "system", "titi1304");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				    try {
				        stmt = connection.createStatement();
				        stmt = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
				                   ResultSet.CONCUR_UPDATABLE);
				        String query="SELECT * FROM TABLA2";
						 ResultSet rset = stmt.executeQuery(query);
					     while(rset.next())
					     {
					      textField.setText("ID: " + rset.getInt(1) + "\n" 
					    		  +"NAME : " + rset.getString(2) + "\n"
					    		  +"TELEFONO : " + rset.getString(3) + "\n");  
					      rset.updateRow();
					     }
						      
				                		

				    } catch (SQLException e) {
				       System.out.println(e);
				    } finally {
				        if (stmt != null) { 
				        	//stmt.close(); 
				        }
				    }
				
			}
		});
		btnNewButton.setBounds(44, 172, 139, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Mostrar M�s Alto");
		btnNewButton_1.setBounds(240, 172, 129, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(407, 38, 17, 82);
		frame.getContentPane().add(scrollBar);
	}
}
