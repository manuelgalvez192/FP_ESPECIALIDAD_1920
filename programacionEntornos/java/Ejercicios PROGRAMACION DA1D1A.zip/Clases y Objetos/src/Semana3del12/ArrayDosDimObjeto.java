package Semana3del12;

public class ArrayDosDimObjeto {

	public static int[][] sumarMatrices(int[][] a1 , int[][] a2){
		int[][] suma = new int[a1.length][a2.length];
		
		for (int i=0; i < a1.length; i++) {
			for (int j=0; j < a1[i].length; j++) {				
			    suma[i][j]= a1[i][j] + a2[i][j];								
			}
		}
		return suma;
	}
	
	public static int[][] restarMatrices(int[][] a1, int[][] a2){
		int[][] resta = new int[a1.length][a2.length];
		
		for (int i=0; i < a1.length; i++) {
			for (int j=0; j < a1[i].length; j++) {				
			    resta[i][j]= a1[i][j] - a2[i][j];								
			}
		}
		
		return resta;
	}
	
	public static int[][] multiplicarMatrices(int[][] a1, int[][] a2){
		int[][] mul = new int[a1.length][a2.length];
		
		 for (int i = 0; i < a1.length; i++) {
	            for (int j = 0; j < a2[i].length; j++) {
	                for (int k = 0; k < a1.length; k++) {
	                    mul[i][j] += a1[i][k] * a2[k][j];
	                }
	            }
	        }
		
		return mul;
	}
	
	public static int[][] transpuestaMatriz(int[][] a1){
		int[][] trans = new int[a1.length][a1.length];
		
		for (int i=0; i < a1.length; i++) {
			for (int j=0; j < a1[i].length; j++) {				
			    trans[j][i]= a1[i][j];								
			}
		}
		return trans;
	}
	
	public static int[][] inversaMatriz(int[][] d){
		int [][] inv = new int[d.length][d.length];
	 
	  
		return inv;
		
	}
	
	
}

