package Semana3del12;

import java.lang.reflect.Array;
import java.util.Scanner;

public class ArrayDosDimensiones {

	public static void main(String[] args) {
		//Sumar, restar y multiplicar dos matrices pedidas
		
		Scanner teclado = new Scanner(System.in);
		int[][] a1 = null;
		int[][] a2 = null;
		int[][] suma = null;
		int[][] resta = null;
		int[][] multiplicacion = null;
		int[][] trans = null;
		int[][] inv = null;
		int dim1a=0, dim2a=0;
		int dim1b=0, dim2b=0;
		int valores=0,opcion=0;
		
		while(opcion != 6) {
			System.out.println("Elije opcion: ");
			System.out.println("1. Sumar dos arrays");
			System.out.println("2. Restar dos arrays");
			System.out.println("3. Multiplicar dos arrays");
			System.out.println("4. Matriz transpuesta");
			System.out.println("5. Matriz inversa");
			System.out.println("6. Salir");
			opcion = teclado.nextInt();
			
			switch(opcion) {
			
			case 1:
				System.out.println("Introduzca dimension1 matriz1: ");
				dim1a = teclado.nextInt();
				System.out.println("Introduzca dimension2 matriz1: ");
				dim2a = teclado.nextInt();
				a1 = new int[dim1a][dim2a];
				
				for(int i=0; i<dim1a; i++) {
					for(int j=0; j<dim2a; j++) {
						System.out.println("Introduzca valores: ");
						valores = teclado.nextInt();
						a1[i][j] = valores;		
					}
				}
				for(int i=0; i<dim1a; i++) {
					for(int j=0; j<dim2a; j++) {
						System.out.print(a1[i][j]+ " ");
					}
					System.out.println();
				}
				System.out.println();
				System.out.println("Introduzca dimension1 matriz2: ");
				dim1b = teclado.nextInt();
				System.out.println("Introduzca dimension2 matriz2: ");
				dim2b = teclado.nextInt();
				a2 = new int[dim1b][dim2b];
				
				for(int i=0; i<dim1b; i++) {
					for(int j=0; j<dim2b; j++) {
						System.out.println("Introduzca valores: ");
						valores = teclado.nextInt();
						a2[i][j] = valores;
						valores = 0;		
					}
				}
				
				for(int i=0; i<dim1b; i++) {
					for(int j=0; j<dim2b; j++) {
						System.out.print(a2[i][j]+ " ");
					}
					System.out.println();
				}
				
				suma = ArrayDosDimObjeto.sumarMatrices(a1, a2);
				System.out.println();
				System.out.println("Suma: ");
				
				for(int i=0; i<suma.length; i++) {
					for(int j=0; j<suma[i].length; j++) {
						System.out.print(suma[i][j]+ " ");
					}
					System.out.println();
				}
				System.out.println();
				break;
				
			case 2:
				System.out.println("Introduzca dimension1 matriz1: ");
				dim1a = teclado.nextInt();
				System.out.println("Introduzca dimension2 matriz1: ");
				dim2a = teclado.nextInt();
				a1 = new int[dim1a][dim2a];
				
				for(int i=0; i<dim1a; i++) {
					for(int j=0; j<dim2a; j++) {
						System.out.println("Introduzca valores: ");
						valores = teclado.nextInt();
						a1[i][j] = valores;		
					}
				}
				for(int i=0; i<dim1a; i++) {
					for(int j=0; j<dim2a; j++) {
						System.out.print(a1[i][j]+ " ");
					}
					System.out.println();
				}
				System.out.println();
				System.out.println("Introduzca dimension1 matriz2: ");
				dim1b = teclado.nextInt();
				System.out.println("Introduzca dimension2 matriz2: ");
				dim2b = teclado.nextInt();
				a2 = new int[dim1b][dim2b];
				
				for(int i=0; i<dim1b; i++) {
					for(int j=0; j<dim2b; j++) {
						System.out.println("Introduzca valores: ");
						valores = teclado.nextInt();
						a2[i][j] = valores;
						valores = 0;		
					}
				}
				
				for(int i=0; i<dim1b; i++) {
					for(int j=0; j<dim2b; j++) {
						System.out.print(a2[i][j]+ " ");
					}
					System.out.println();
				}
				
				resta = ArrayDosDimObjeto.restarMatrices(a1, a2);
				System.out.println();
				System.out.println("Resta: ");
				
				for(int i=0; i<resta.length; i++) {
					for(int j=0; j<resta[i].length; j++) {
						System.out.print(resta[i][j]+ " ");
					}
					System.out.println();
				}
				System.out.println();
				break;
				
			case 3:	
				System.out.println("Introduzca dimension1 matriz1: ");
				dim1a = teclado.nextInt();
				System.out.println("Introduzca dimension2 matriz1: ");
				dim2a = teclado.nextInt();
				a1 = new int[dim1a][dim2a];
				
				for(int i=0; i<dim1a; i++) {
					for(int j=0; j<dim2a; j++) {
						System.out.println("Introduzca valores: ");
						valores = teclado.nextInt();
						a1[i][j] = valores;		
					}
				}
				for(int i=0; i<dim1a; i++) {
					for(int j=0; j<dim2a; j++) {
						System.out.print(a1[i][j]+ " ");
					}
					System.out.println();
				}
				System.out.println();
				System.out.println("Introduzca dimension1 matriz2: ");
				dim1b = teclado.nextInt();
				System.out.println("Introduzca dimension2 matriz2: ");
				dim2b = teclado.nextInt();
				a2 = new int[dim1b][dim2b];
				
				for(int i=0; i<dim1b; i++) {
					for(int j=0; j<dim2b; j++) {
						System.out.println("Introduzca valores: ");
						valores = teclado.nextInt();
						a2[i][j] = valores;
						valores = 0;		
					}
				}
				
				for(int i=0; i<dim1b; i++) {
					for(int j=0; j<dim2b; j++) {
						System.out.print(a2[i][j]+ " ");
					}
					System.out.println();
				}
				
				multiplicacion = ArrayDosDimObjeto.multiplicarMatrices(a1, a2);
				
				System.out.println();
				System.out.println("Multiplicacion: ");
				
				for(int i=0; i<multiplicacion.length; i++) {
					for(int j=0; j<multiplicacion[i].length; j++) {
						System.out.print(multiplicacion[i][j]+ " ");
					}
					System.out.println();
				}
				System.out.println();
				break;
				
			case 4:
				System.out.println("Introduzca dimension1 matriz: ");
				dim1b = teclado.nextInt();
				System.out.println("Introduzca dimension2 matriz: ");
				dim2b = teclado.nextInt();
				a2 = new int[dim1b][dim2b];
				
				for(int i=0; i<dim1b; i++) {
					for(int j=0; j<dim2b; j++) {
						System.out.println("Introduzca valores: ");
						valores = teclado.nextInt();
						a2[i][j] = valores;
						valores = 0;		
					}
				}
				
				for(int i=0; i<dim1b; i++) {
					for(int j=0; j<dim2b; j++) {
						System.out.print(a2[i][j]+ " ");
					}
					System.out.println();
				}
				
				trans = ArrayDosDimObjeto.transpuestaMatriz(a2);
				
				System.out.println();
				System.out.println("Transpuesta: ");
				
				for(int i=0; i<trans.length; i++) {
					for(int j=0; j<trans[i].length; j++) {
						System.out.print(trans[i][j]+ " ");
					}
					System.out.println();
				}
				System.out.println();
				break;
				
			case 5:
				System.out.println("Introduzca dimension1 matriz1: ");
				dim1a = teclado.nextInt();
				System.out.println("Introduzca dimension2 matriz1: ");
				dim2a = teclado.nextInt();
				a1 = new int[dim1a][dim2a];
				
				for(int i=0; i<dim1a; i++) {
					for(int j=0; j<dim2a; j++) {
						System.out.println("Introduzca valores: ");
						valores = teclado.nextInt();
						a1[i][j] = valores;		
					}
				}
				
				inv = ArrayDosDimObjeto.inversaMatriz(a1);
				
				System.out.println();
				System.out.println("Inversa: ");
				
				for(int i=0; i<inv.length; i++) {
					for(int j=0; j<inv[i].length; j++) {
						System.out.print(inv[i][j]+ " ");
					}
					System.out.println();
				}
				System.out.println();
				break;
				
				
				
			}

		}
		
	}
}
