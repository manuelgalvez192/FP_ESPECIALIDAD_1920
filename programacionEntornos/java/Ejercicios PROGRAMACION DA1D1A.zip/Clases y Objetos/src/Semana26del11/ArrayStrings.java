package Semana26del11;

import java.util.Scanner;

public class ArrayStrings {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		String[] s = new String[10];
		int longitud=0;
		int[] long2 = new int[10];
		
		for(int i=0; i<s.length;i++) {
			System.out.println("Introduzca cadena pos "+ i);
			s[i] = teclado.nextLine();
		}
		
		/*for(int i=0; i<s.length;i++) {
			longitud = s[i].length();
			System.out.println("Longitud cadena pos " +i + " es " +longitud);
			longitud = 0;
		}
		
		for(int i=0; i<s.length;i++) {
			long2[i] = s[i].length();
		}
		
		int mayor = long2[0];
        for(int i=0;i<long2.length;i++) {
        	if(long2[i] > mayor) {
        		mayor = long2[i];
        	}
        }
        
        System.out.println("Mayor: "+mayor);
        
        int num = 0, num2=0;		
		for(int i=0; i<s.length;i++) {
			for(int j=0; j<s[i].length();j++) {
				if(s[i].charAt(j) == 'a') {
					num++;
				}
				else if(s[i].charAt(j) == 'e') {
					num++;
				}
				else if(s[i].charAt(j) == 'i') {
					num++;
				}
				else if(s[i].charAt(j) == 'o') {
					num++;
				}
				else if(s[i].charAt(j) == 'u') {
					num++;
				}
			}
			System.out.println("Vocales en pos " + i + " : " + num);
			num2+=num;
			num=0;
		}
		
		System.out.println("Vocales en total: " + num2 +"\n");
		
		int pos1=0, pos2=0;
		String temp= "";
		System.out.println("Introduzca pos1");
		pos1 = teclado.nextInt();
		System.out.println("Introduzca pos2");
		pos2 = teclado.nextInt();
		
		System.out.println("Contenido de s[pos1] antes: " + s[pos1]);
		System.out.println("Contenido de s[pos2] antes: " + s[pos2]);
		
		temp = s[pos1];
		s[pos1] = s[pos2];
		s[pos2] = temp;
		
		System.out.println("Contenido de s[pos1] despues: " + s[pos1]);
		System.out.println("Contenido de s[pos2] despues: " + s[pos2]+"\n");
		
		String aux = "";
		int res=0;
		aux = teclado.nextLine();
		System.out.println("Introduzca cadena a comparar");
		aux = teclado.nextLine();
		
		for(int i=0; i<s.length;i++) {
			if(s[i].equals(aux)) {
				res++;
			}
		}
		System.out.println(aux +" se repite "+ res +" veces\n");*/
		
		//Mostrar cadena que mas se repite
		int num=0, mayor=0, pos=0;
		boolean esta;
		//String cadmayor="";
		ArrayObjeto[] cad = new ArrayObjeto[10];
		
		for(int i=0;i<s.length;i++) {
			esta = false;
			for(int j=0; j<num && !esta;j++) {
				if(s[i].equals(cad[j].getS())) {
					cad[j].setRep(cad[j].getRep()+1);
					esta = true;
				}
				
			}
			if(!esta) {
				cad[num] = new ArrayObjeto(s[i],1);
				num++;
			}
			
		}
		
		mayor = cad[0].getRep();
				
		for(int j=1;j<num;j++) {
			if(cad[j].getRep()>mayor) {
				mayor=cad[j].getRep();
				pos = j;
				//cadmayor = cad[j].getS();
			}
			System.out.println(cad[j].getRep() + "  " + cad[j].getS());
		}
		
		
		
	    System.out.println("Palabra que mas se repite es "+cad[pos].getS() +" num veces: " + mayor);
		
		
		
		
		
		
		teclado.close();
	}
}
