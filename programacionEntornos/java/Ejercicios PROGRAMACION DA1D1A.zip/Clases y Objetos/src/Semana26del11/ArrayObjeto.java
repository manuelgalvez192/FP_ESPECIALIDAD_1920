package Semana26del11;

public class ArrayObjeto {
	private String s;
	private int rep;
	
	public ArrayObjeto(String s, int rep) {
		this.s = s;
		this.rep = rep;
	}

	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}

	public int getRep() {
		return rep;
	}

	public void setRep(int rep) {
		this.rep = rep;
	}
	
	



}
