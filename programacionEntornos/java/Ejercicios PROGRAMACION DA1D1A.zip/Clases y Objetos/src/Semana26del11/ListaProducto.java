package Semana26del11;

public class ListaProducto {
	private Producto[] productos; //max 50 productos
	private int numProductos;

	public ListaProducto(Producto[] productos) {
		this.productos = productos;
		this.numProductos=50;
	}
		
	public Producto[] getProductos() {
		return productos;
	}

	public void setProductos(Producto[] productos) {
		this.productos = productos;
	}

	public int getNumProductos() {
		return numProductos;
	}

	public void setNumProductos(int numProductos) {
		this.numProductos = numProductos;
	}

	public boolean introducirProducto(Producto p) {
		int i=-1;
		if(this.numProductos == 50) {
			return false;
		}
		else {
			for(Producto pr: this.productos) {
				i++;
				if(pr == null) {
					this.productos[i]=p;
					this.numProductos++;
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean borrarProducto(int id) {
		for(Producto pr: this.productos) {
			if(pr != null) {
				if(pr.getId() == id) {
					this.productos[pr.getId()] = null;
					this.numProductos--;
					return true;
				}
			}
		}
			
		
		return false;
	}
	
	public boolean modificarPrecio(int id) {
		for(Producto pr: this.productos) {
			if(pr.getId() == id) {
				this.productos[pr.getId()].setPrecio(1000);
			}
		}
		return false;
	}
	public void listarProductos() {
		for(Producto pr: this.productos) {
			if(pr != null) {
				System.out.println("Id:" +pr.getId() +" Nombre: "+pr.getNombre()+ " Precio: " + pr.getPrecio() + " Stock: " + pr.getStock());
			}
		}
	}

	public Producto masStock() {
		Producto p2 = null;
		int mayor=0;
		
		mayor = this.productos[0].getStock();
		
		for(Producto p: this.productos) {
			if(p.getStock()>mayor) {
				mayor = p.getStock();
				p2 = p;
			}
		}
		
		return p2;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
