package Semana26del11;

import java.util.Scanner;

public class MainProducto {

	public static void main(String[] args) {
		//Menu con las opciones disponibles en lista producto
		Scanner teclado = new Scanner(System.in);
		int id2=0, precio=0, stock=0;
		String nombre = "";
		//int id=0;
		int opcion=0, idprod=0;
		Producto[] p2 = new Producto[50];
		for(int i=0;i<50;i++) {
			p2[i] = new Producto(i, "Producto"+i, (int)(Math.random()*100), i*50);
		}
		ListaProducto lp = new ListaProducto(p2);
		boolean res = false;
		Producto aux = null;
		
		while(opcion!= 6) {
			System.out.println("Elige opcion: ");
			System.out.println("1. Borrar producto");
			System.out.println("2. A�adir producto");
			System.out.println("3. Modificar precio producto");
			System.out.println("4. Listar productos");
			System.out.println("5. Producto mayor stock");
			System.out.println("6. Salir");
			opcion = teclado.nextInt();
			
			switch(opcion) {
			case 1:
				System.out.println("Id del producto a borrar: ");
				idprod = teclado.nextInt();
				
				res = lp.borrarProducto(idprod);
				if(res) {
					System.out.println("Borrado realizado con exito");
				}
				else {
					System.out.println("Error al eliminar");
				}
				break;
			case 2:
				System.out.println("Introduzca id del producto nuevo: ");
				id2 = teclado.nextInt();
				System.out.println("Introduzca nombre del producto nuevo: ");
				teclado.nextLine();
				nombre = teclado.nextLine();
				System.out.println("Introduzca precio del producto nuevo: ");
				precio = teclado.nextInt();
				System.out.println("Introduzca stock del producto nuevo: ");
				stock = teclado.nextInt();
				
				Producto p = new Producto(id2, nombre, precio, stock);
				res = lp.introducirProducto(p);
				if(res) {
					System.out.println("A�adido correctamente");
				}
				else {
					System.out.println("Error al a�adir");
				}
				break;
			case 3:
				System.out.println("Introducir id del producto a modificar precio: ");
				id2 = teclado.nextInt();
				res = lp.modificarPrecio(id2);
				if(res) {
					System.out.println("Precio modificado correctamente");
				}
				else {
					System.out.println("Error al modificar precio");
				}
				break;
			case 4:
				lp.listarProductos();
				System.out.println();
				break;
			case 5:
				aux = lp.masStock();
				System.out.println(aux.toString());
				break;
			case 6:
				System.out.println("Adios");
				break;
			default:
				System.out.println("Opcion erronea");				
			}
		}		
		
		
		teclado.close();
	}

}
