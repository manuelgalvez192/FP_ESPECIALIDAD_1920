package Semana10del12;

public class MainClases {

	public static void main(String[] args) {

		//Mostrar id y nombre alumno con la nota mas baja, en caso de empate mostrar cualquiera
		//mostrar numero grupo donde haya al menos un alumno entre 5 y 6
		
		Profesor p1 = null;
		Alumno[][] a1 = new Alumno[4][30];
		Alumno a2=null;
		int k=0;
		double nota = 0;
		double[]nota2 = null;
		int[] c1 = null;
		
		for(int i=0;i<a1.length; i++) {
			for(int j=0;j<a1[i].length;j++) {
				a1[i][j] = new Alumno(Math.random()*10, "Nombre"+k, "Apellido"+k, k, i);
				k++;
			}
		}
		p1 = new Profesor(a1);
		for(int i=0;i<a1.length; i++) {
			for(int j=0;j<a1[i].length;j++) {
				System.out.println(p1.getAlumnos()[i][j].toString());
			}
		}
		System.out.println();
		nota = p1.notaMasAltaTodos();
		System.out.println(String.format("Nota m�s alta de todas las clases: %.2f",nota));
		System.out.println();
		
		nota2 = p1.notaMasAltaClase();
		for(int i=0; i<a1.length;i++) {
			System.out.println(String.format("Nota m�s alta de la clase "+i+" : %.2f",nota2[i]));
		}
		System.out.println();
		
		a2 = p1.notaMasBajaTodos();
		System.out.println("La nota m�s baja es: "+a2);
		System.out.println();
		
		c1 = p1.claseConAlumnosEntre5y6();
		for(int i=0; i<c1.length;i++) {
			if(c1[i] != -1) {
				System.out.println("Clases con notas entre 5 y 5.2: "+ c1[i]);
			}
			
		}
		
	}

}
