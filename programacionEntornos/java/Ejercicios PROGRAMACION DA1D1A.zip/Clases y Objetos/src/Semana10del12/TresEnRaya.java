package Semana10del12;

public class TresEnRaya {
	private char[][] tablero;
	private int id;

	public TresEnRaya(char[][] tablero) {
		this.tablero = tablero;
		this.id = 1;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean actualizarTableroJ1(int fila, int col) {
		boolean posible = false;
		
		if(fila >= 3 || col >= 3) {
			return posible;
		}
		
		for(int i=0; i<this.tablero.length;i++) {
			for(int j=0; j<this.tablero[i].length;j++) {
				if(this.tablero[fila][col] == '-') {
					this.tablero[fila][col] = 'X';
					posible = true;
				}
			}
		}
		return posible;
	}
	public boolean actualizarTableroJ2(int fila, int col) {
		boolean posible = false;
		
		if(fila >= 3 || col >= 3) {
			return posible;
		}
		
		for(int i=0; i<this.tablero.length;i++) {
			for(int j=0; j<this.tablero[i].length;j++) {
				if(this.tablero[fila][col] == '-') {
					this.tablero[fila][col] = 'O';
					posible = true;
				}
			}
		}
		return posible;
	}
	
	public boolean finpartida() {
		boolean fin = true;
		
		for(int i=0; i<this.tablero.length;i++) {
			for(int j=0; j<this.tablero[i].length;j++) {
				if(this.tablero[i][j] == '-') {
					fin = false;
				}
			}
		}
		
		return fin;
	}
	
	public boolean ganadorJ1() {
		boolean ganar = false;
		
		if((tablero[0][0] == 'X') && (tablero[1][0] == 'X') && (tablero[1][0] == 'X') && (tablero[2][0] == 'X')) {
			ganar = true;
		}
		else if((tablero[0][0] == 'X')&&(tablero[0][1]== 'X') && (tablero[0][1]== 'X') && (tablero[0][2]== 'X')) {
			ganar = true;
		}
		else if((tablero[0][0]== 'X')&&(tablero[1][1]== 'X') && (tablero[1][1]== 'X')&& (tablero[2][2]== 'X')) {
			ganar = true;
		}
		else if((tablero[0][1] == 'X')&& (tablero[1][1]== 'X') && (tablero[1][1]== 'X')&&(tablero[2][1]== 'X')) {
			ganar = true;
		}
		else if((tablero[0][2]== 'X')&&(tablero[1][2]== 'X') && (tablero[1][2]== 'X')&&(tablero[2][2]== 'X')){
			ganar = true;
		}
		else if((tablero[0][2]== 'X')&&(tablero[1][1]== 'X') && (tablero[1][1]== 'X')&&(tablero[2][0]== 'X')) {
			ganar = true;
		}
		else if((tablero[2][0]== 'X')&&(tablero[2][1]== 'X') && (tablero[2][1]== 'X')&&(tablero[2][2]== 'X')) {
			ganar = true;
		}
		else if((tablero[1][0]== 'X')&&(tablero[1][1]== 'X') && (tablero[1][1]== 'X')&&(tablero[1][2]== 'X')) {
			ganar = true;
		}
				
		
		return ganar;
	}
	public boolean ganadorJ2() {
		boolean ganar = false;
		
		if((tablero[0][0] == 'O') && (tablero[1][0] == 'O') && (tablero[1][0] == 'O') && (tablero[2][0] == 'O')) {
			ganar = true;
		}
		else if((tablero[0][0] == 'O')&&(tablero[0][1]== 'O') && (tablero[0][1]== 'O') && (tablero[0][2]== 'O')) {
			ganar = true;
		}
		else if((tablero[0][0]== 'O')&&(tablero[1][1]== 'O') && (tablero[1][1]== 'O')&& (tablero[2][2]== 'O')) {
			ganar = true;
		}
		else if((tablero[0][1] == 'O')&& (tablero[1][1]== 'O') && (tablero[1][1]== 'O')&&(tablero[2][1]== 'O')) {
			ganar = true;
		}
		else if((tablero[0][2]== 'O')&&(tablero[1][2]== 'O') && (tablero[1][2]== 'O')&&(tablero[2][2]== 'O')){
			ganar = true;
		}
		else if((tablero[0][2]== 'O')&&(tablero[1][1]== 'O') && (tablero[1][1]== 'O')&&(tablero[2][0]== 'O')) {
			ganar = true;
		}
		else if((tablero[2][0]== 'O')&&(tablero[2][1]== 'O') && (tablero[2][1]== 'O')&&(tablero[2][2]== 'O')) {
			ganar = true;
		}
		else if((tablero[1][0]== 'O')&&(tablero[1][1]== 'O') && (tablero[1][1]== 'O')&&(tablero[1][2]== 'O')) {
			ganar = true;
		}
				
		return ganar;
	}
	
	public boolean actualizarTableroCPU() {
		boolean mover = false;
		int fila = (int)((Math.random()*10)/4);
		int col = (int)((Math.random()*10)/4);
		
		for(int i=0; i<this.tablero.length;i++) {
			for(int j=0; j<this.tablero[i].length;j++) {
				if(this.tablero[fila][col] == '-') {
					while( this.tablero[fila][col] != 'O' &&  this.tablero[fila][col] != 'O') {
						if(this.finpartida()) {
							return mover;
						}
						this.tablero[fila][col] = 'O';
						mover = true;
					}
					
				}
			}
		}
		
		return mover;
	}
	
	public void mostrarTablero() {
		for(int i=0; i<tablero.length;i++) {
			for(int j=0; j<tablero[i].length;j++) {
				System.out.print(tablero[i][j] + " ");
			}
			System.out.println();
		}
	}
	
}
