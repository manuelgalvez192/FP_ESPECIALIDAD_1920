package Semana10del12;

public class Profesor {
	private Alumno[][] alumnos;
	
	public Profesor(Alumno[][] alumnos) {
		this.alumnos = alumnos;
	}
	
	public Alumno[][] getAlumnos() {
		return alumnos;
	}

	public void setAlumnos(Alumno[][] alumnos) {
		this.alumnos = alumnos;
	}

	public double notaMasAltaTodos() {
		double nota = 0;
		
		nota = this.getAlumnos()[0][0].getNota();
		for(int i=0;i<this.getAlumnos().length; i++) {
			for(int j=0;j<this.getAlumnos()[i].length;j++) {
				if(nota < this.getAlumnos()[i][j].getNota()) {
					nota = this.getAlumnos()[i][j].getNota();
				}
			}
		}
		
		return nota;
	}
	
	/*public double notaMasAltaClase(int clase) {
		double nota = 0;
		
		nota = this.getAlumnos()[clase][0].getNota();
		for(int j=0;j<this.getAlumnos()[clase].length;j++) {
			if(nota < this.getAlumnos()[clase][j].getNota()) {
				nota = this.getAlumnos()[clase][j].getNota();
			}
		}
		
		return nota;
	}*/
	
	public double[] notaMasAltaClase() {
		double notas[] = new double[this.getAlumnos().length];
		
		notas[0] = 0;
		
		for(int i=0;i<this.getAlumnos().length; i++) {
			for(int j=0;j<this.getAlumnos()[i].length;j++) {
				if(notas[i] < this.getAlumnos()[i][j].getNota()) {
					notas[i] = this.getAlumnos()[i][j].getNota();
				}
			}
		}
		
		return notas;
	}
	
	
	public Alumno notaMasBajaTodos() {
		double nota = 0;
		Alumno a1 = null;
		
		nota = this.getAlumnos()[0][0].getNota();
		for(int i=0;i<this.getAlumnos().length; i++) {
			for(int j=0;j<this.getAlumnos()[i].length;j++) {
				if(nota > this.getAlumnos()[i][j].getNota()) {
					nota = this.getAlumnos()[i][j].getNota();
					a1 = this.getAlumnos()[i][j];
				}
			}
		}
		
		return a1;
	}
	
	public int[] claseConAlumnosEntre5y6() {
		int[] cl = new int[this.getAlumnos().length];
		
		for(int k=0; k<cl.length;k++) {
			cl[k] = -1;
		}
		for(int i=0;i<this.getAlumnos().length; i++) {
			for(int j=0;j<this.getAlumnos()[i].length;j++) {
				if(this.getAlumnos()[i][j].getNota()>5 && this.getAlumnos()[i][j].getNota()<5.2) {
					cl[i] = this.getAlumnos()[i][j].getClase();
				}
			}
		}
		
		return cl;
	}
	
}
