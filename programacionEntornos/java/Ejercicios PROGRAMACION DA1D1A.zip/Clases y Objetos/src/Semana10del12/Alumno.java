package Semana10del12;

public class Alumno {

	//profesor con array alumnos(nombre, apellido, id, nota) de 4x30
	//Nota mas alta de todos los alumnos, nota mas alta de cada grupo
	//Mostrar id y nombre alumno con la nota mas baja, en caso de empate mostrar cualquiera
	//mostrar numero grupo donde haya al menos un alumno con un 5
	private double nota;
	private String nombre;
	private String apellido;
	private int id;
	private int clase;
	
	public Alumno(double nota, String nombre, String apellido, int id, int clase) {
		this.nota = nota;
		this.nombre = nombre;
		this.apellido = apellido;
		this.id = id;
		this.clase = clase;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getClase() {
		return clase;
	}

	public void setClase(int clase) {
		this.clase = clase;
	}

	@Override
	public String toString() {
		return String.format("Nota: %.2f", nota) + " Nombre y Apellido: "+ nombre + ","+apellido+" Id: " +id +" Clase: " +clase;
	}
	
	
	
}
