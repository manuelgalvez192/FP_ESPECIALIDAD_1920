package Semana10del12;

import java.util.Scanner;

public class TresEnRayaMain {

	public static void main(String[] args) {
		//0 vacio, X un jugador, O otro jugador
		//1vs1, 1vsmaquina, mostrar resultado final
		Scanner teclado = new Scanner(System.in);
		TresEnRaya juego = null;
		int opcion=0, opcion2=0;
		int id1 = 1;
		int filajug1 = 0, filajug2=0;
		int coljug1=0, coljug2=0;
		char[][] tablero = new char[3][3];
		boolean movimiento=false, fin = false, ganar = false;
		
		for(int i=0; i<tablero.length;i++) {
			for(int j=0; j<tablero[i].length;j++) {
				tablero[i][j] = '-';
			}
		}
		
		juego = new TresEnRaya(tablero);
		
	
		while(opcion != 3) {
			System.out.println("Elije opci�n: ");
			System.out.println("1. 1 VS 1");
			System.out.println("2. 1 VS CPU");
			System.out.println("3. Abandonar");
			opcion = teclado.nextInt();
			
			switch(opcion) {
			
			case 1:
				while(juego.getId() != 3) {
					juego.mostrarTablero();
					System.out.println();
					if(juego.getId() == 1) {
						System.out.println("Turno Jugador 1");
							fin = juego.finpartida();
							if(fin) {
								System.out.println("Juego acabado en Empate");
							}
							else {
								System.out.println("�Qu� fila busca rellenar?");
								filajug1 = teclado.nextInt();
								System.out.println("�Qu� columna busca rellenar?");
								coljug1 = teclado.nextInt();
								movimiento = juego.actualizarTableroJ1(filajug1, coljug1);
								juego.setId(juego.getId()+1);
								if(!movimiento) {
									System.out.println("No es posible colocar en esa posicion");
									juego.setId(juego.getId()-1);
								}
								
								ganar = juego.ganadorJ1();
								if(ganar) {
									System.out.println("Enhorabuena has ganado");
									juego.setId(3);
								}
							}
						System.out.println();
					}
				
				else if(juego.getId() == 2) {
					System.out.println("Turno Jugador 2");
					fin = juego.finpartida();
						if(fin) {
							System.out.println("Juego acabado en Empate");
						}
						else {
							System.out.println("�Qu� fila busca rellenar?");
							filajug2 = teclado.nextInt();
							System.out.println("�Qu� columna busca rellenar?");
							coljug2 = teclado.nextInt();
							movimiento = juego.actualizarTableroJ2(filajug2, coljug2);
							juego.setId(juego.getId()-1);
							if(!movimiento) {
								System.out.println("No es posible colocar en esa posicion");
								juego.setId(juego.getId()+1);
							}
							
							ganar = juego.ganadorJ2();
							if(ganar) {
								System.out.println("Enhorabuena has ganado");
								juego.setId(3);
							}
						}
					System.out.println();
				}
			}	
			break;
			case 2:	
				while(juego.getId() != 3) {
					juego.mostrarTablero();
					System.out.println();
					if(juego.getId() == 1) {
						System.out.println("Turno Jugador 1");
						fin = juego.finpartida();
						if(fin) {
							System.out.println("Juego acabado en Empate");
						}
						else {
							System.out.println("�Qu� fila busca rellenar?");
							filajug1 = teclado.nextInt();
							System.out.println("�Qu� columna busca rellenar?");
							coljug1 = teclado.nextInt();
							movimiento = juego.actualizarTableroJ1(filajug1, coljug1);
							juego.setId(juego.getId()+1);
							if(!movimiento) {
								System.out.println("No es posible colocar en esa posicion");
								juego.setId(juego.getId()-1);
							}
							
							ganar = juego.ganadorJ1();
							if(ganar) {
								System.out.println("Enhorabuena has ganado");
								juego.setId(3);
							}
						}
					}
					else {
						System.out.println("No es su turno");
					}
					
					if(juego.getId() == 2) {
						System.out.println("Turno CPU");
						fin = juego.finpartida();
						if(fin) {
							System.out.println("Juego acabado en Empate");
						}
						else {
							movimiento = juego.actualizarTableroCPU();
							juego.setId(juego.getId()-1);
							if(!movimiento) {
								System.out.println("No es posible colocar en esa posicion");
								juego.setId(juego.getId()+1);
							}
							
							ganar = juego.ganadorJ2();
							if(ganar) {
								System.out.println("Enhorabuena ha ganado la CPU");
								juego.setId(3);
							}
						}
					}
							
				}	
				System.out.println();
				break;
			case 3:
				System.out.println("Resultado �ltima partida: ");
				juego.mostrarTablero();
				System.out.println("�Gracias por jugar!");
				break;				
			}
			
			
	 teclado.nextLine();
		}
	}
}
