package EjerciciosArrays;

import java.util.Scanner;

public class EjemploArrays {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		EjemploArrayRotaciones ej = null;
		 // declares an array of integers
        int[] anArray;
        int suma = 0, cont=0, num=0, pos=0, num2=0;
        // allocates memory for 10 integers
        anArray = new int[10];
        int array2[];   
        int[] array3 = new int[10];
        // initialize first element
        anArray[0] = 100;
        // initialize second element
        anArray[1] = 200;
        // and so forth
        anArray[2] = 300;
        anArray[3] = -400;
        anArray[4] = 500;
        anArray[5] = 600;
        anArray[6] = 700;
        anArray[7] = 800;
        anArray[8] = 900;
        anArray[9] = 1000;

        System.out.println("Element at index 0: "
                           + anArray[0]);
        System.out.println("Element at index 1: "
                           + anArray[1]);
        System.out.println("Element at index 2: "
                           + anArray[2]);
        System.out.println("Element at index 3: "
                           + anArray[3]);
        System.out.println("Element at index 4: "
                           + anArray[4]);
        System.out.println("Element at index 5: "
                           + anArray[5]);
        System.out.println("Element at index 6: "
                           + anArray[6]);
        System.out.println("Element at index 7: "
                           + anArray[7]);
        System.out.println("Element at index 8: "
                           + anArray[8]);
        System.out.println("Element at index 9: "
                           + anArray[9]);
        
       for(int i=0;i<anArray.length;i++) {
        	if(anArray[i] < 0) {
        		cont++;
        	}
        }
        System.out.println("Negativos: " +cont);
        
        for(int i=0;i<anArray.length;i++) {
        	suma += anArray[i];
        }
        System.out.println("Suma: " + suma);
        
        for(int i=anArray.length-1;i>-1;i--) {
        	System.out.println("Elementos at index "+i+" reverse: "+ anArray[i]);
        }
        
        int mayor = anArray[0];
        for(int i=0;i<anArray.length;i++) {
        	if(anArray[i] > mayor) {
        		mayor = anArray[i];
        	}
        }
        System.out.println("Mayor: "+mayor);
        
        int j=0;
        for(int i=0;i<anArray.length;i++) {
        	array2 = new int[anArray.length];
        	if(anArray[i] > 0) {
        		array2[j] = anArray[i];
        		System.out.println("Elemento positivo: "+array2[j]);
        		j++;
        	}
        }
        
        System.out.println("Introduzca una posicion del array");
        pos = teclado.nextInt();
        
        if(pos < anArray.length) {
        	  System.out.println("Introduzca un valor para esa posicion del array");
              num = teclado.nextInt();
              
              anArray[pos] = num;
              
              for(int i=0;i<anArray.length;i++) {
              	System.out.println("Valor: " + anArray[i]);
              }
        }
        else {
        	System.out.println("Posicion err�nea");
        }
        
        boolean res = false;
        System.out.println("Introduzca un valor a comprobar: ");
        num2 = teclado.nextInt();
        
        for(int i=0;i<anArray.length;i++) {
        	if(anArray[i] == num2) {
        		res = true;
        	}
        }
        
        if(res) {
        	System.out.println("Numero est�");
        }
        else {
        	System.out.println("Numero no est�");
        }
        
        //Ver cuantas veces est� un numero en el array
        int cont2=0, aux=0;
        for(int i=0;i<anArray.length;i++) {
        	for(int k=0; k<anArray.length;k++) {
        		if(anArray[i] == anArray[k]) {
        			cont2++;
        			aux = i;
        			if(cont2 > 1) {
        				i++;
        			}
        		}
        	}
        	if(i<=10) {
        		i=aux;
        	}
        	
        	System.out.println("El valor "+anArray[i]+ " se repite: "+cont2);
        	cont2=0;
        }
        /*
        //Rotacion circular a la derecha de los numeros del array
        ej = new EjemploArrayRotaciones(anArray);
        array3 = ej.rotaruno();
        for(int i=0; i<anArray.length;i++) {
        	System.out.println("El valor "+anArray[i]);
        }
        
        
        //Rotacion circular a la derecha diciendo cuantas veces quiere rotar
        int rot=0;
        int[] array4 = new int[10];
        System.out.println("Introduzca rotacion: ");
        rot = teclado.nextInt();
        
        array4 = ej.rotaruno();
        for(int i=0; i<anArray.length;i++) {
        	System.out.println("El valor "+anArray[i]);
        }
        */
        System.out.println("\n");
        
        for(int i=0; i<anArray.length;i++) {
        	System.out.println("El valor "+anArray[i] +" antes de la ordenacion.");
        }
        
        System.out.println("\n");
        int temp=0;
        //Ordenar un array de menor a mayor
        for(int i=0;i<anArray.length;i++) {
        	for(int k=1; k<anArray.length-i;k++) {
        		 if(anArray[k-1] > anArray[k]){  
                     temp = anArray[k-1];  
                     anArray[k-1] = anArray[k];  
                     anArray[k] = temp;  
        		}
        	}
        
        }
        for(int i=0; i<anArray.length;i++) {
        	System.out.println("El valor "+anArray[i]+" despues de la ordenacion.");
        }
        teclado.close();
	}
}

