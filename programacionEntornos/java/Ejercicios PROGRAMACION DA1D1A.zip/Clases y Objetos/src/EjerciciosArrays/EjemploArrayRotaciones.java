package EjerciciosArrays;

public class EjemploArrayRotaciones {
	private int[] anArray;

	public EjemploArrayRotaciones(int[] anArray) {
		this.anArray = anArray;
	}
	
	public int[] rotaruno() {
		int nu2=0;
        nu2 = this.anArray[0];
        for(int i=0;i<this.anArray.length;i++) {
        	if(i == this.anArray.length-1) {
        		this.anArray[i] = nu2;
        	}
        	else {
        		this.anArray[i] = this.anArray[i+1];
        		
        	}
        		
        }
        return anArray;
	}
	
	//Rotacion a la derecha varias veces
	public int[] rotarvarios(int rot) {
		for(int i=0;i<anArray.length;i++) {
        	if(i == anArray.length) {
        		i = i % anArray.length;
        	}
        	else {
        		anArray[i] = anArray[i+rot];
        		
        	}
        	
        	System.out.println("El valor "+anArray[i]);
        	
        	
        }
        return anArray;
	}
	
}
