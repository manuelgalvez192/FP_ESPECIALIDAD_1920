package Semana10del10;

public class Jugador {
	private double altura;
	private double porcentajedos;
	private double porcentajetres;
	
	public Jugador(double altura, double porcentajedos, double porcentajetres) {
		this.altura = altura;
		if(porcentajedos < 0) {
			this.porcentajedos = 0;
		}	
		else {
			if(porcentajedos > 100) {
				this.porcentajedos = 100;
			}
			else {
				this.porcentajedos = porcentajedos;
			}
		}
		if(porcentajetres < 0) {
			this.porcentajetres = 0;
		}
		else {
			if(porcentajetres > 100) {
				this.porcentajetres = 100;
			}
			else {
				this.porcentajetres = porcentajetres;
			}
		}
		
	}

	public Jugador() {
		this.altura = 1.85;
		this.porcentajedos = 0.40;
		this.porcentajetres = 0.15;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public double getPorcentajedos() {
		return porcentajedos;
	}

	public void setPorcentajedos(double porcentajedos) {
		this.porcentajedos = porcentajedos;
	}

	public double getPorcentajetres() {
		return porcentajetres;
	}

	public void setPorcentajetres(double porcentajetres) {
		this.porcentajetres = porcentajetres;
	}
	
	public boolean lanzar_de_tres() {
		double p1 = 0;
		p1 = Math.random();
		if(p1 < this.porcentajetres) {
			return true;
		}
		else {
			return false;
		}
		
	}
	public boolean lanzar_de_dos() {
		double p1 = 0;
		p1 = Math.random();
		if(p1 < this.porcentajedos) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public void entrenar_dos() {
		double p1 = Math.random();
		if(p1 < 0.5) {
			if(this.porcentajedos >= 1) {
				this.porcentajedos = 1;
			}
			else {
				this.porcentajedos = this.porcentajedos + 0.005;
			}
			
		}
	}
	
	public void entrenar_tres() {
		double p1 = Math.random();
		if(p1 < 0.5) {
			if(this.porcentajetres >= 1) {
				this.porcentajetres = 1;
			}
			else {
				this.porcentajetres = this.porcentajetres + 0.005;
			}
			
		}
	}
	
	public void entrenar_dos(int dias) {
		double p1 = Math.random();
		if(p1 < 0.5) {
			if(this.porcentajedos >= 1) {
				this.porcentajedos = 1;
			}
			else {
				this.porcentajedos = this.porcentajedos + 0.005*dias;
			}
			
		}
	}
	
	public void entrenar_tres(int dias) {
		double p1 = Math.random();
		if(p1 < 0.5) {
			if(this.porcentajetres >= 1) {
				this.porcentajetres = 1;
			}
			else {
				this.porcentajetres = this.porcentajetres + 0.005*dias;
			}
			
		}
	}

	@Override
	public String toString() {
		return "Jugador -> Altura: " + this.altura + ", Porcentaje tiros de dos: " + this.porcentajedos + ", Porcentaje tiros de tres: " + this.porcentajetres;
	}
	
	






}	
