package Semana10del10;

import java.util.Scanner;

public class MainBaloncesto {

	public static void main(String[] args) {
		//jugador con datos o no, porcentaje de canastas, cuantas canastas y fallos ha hecho
		Jugador j1 = null;
		//Jugador j2 = null;
		Scanner teclado = new Scanner(System.in);
		int cont1=0, cont2=0, /*cont3=0, cont4=0,*/ opcion = 0, fallos=0, canasta=0,canasta2=0 ,fallos2=0;
		double altura=0, porcentajededos=0, porcentajedetres=0, p1=0, p2=0;
		boolean acierto=false; /*acierto2=false;*/
		
		System.out.println("1. Jugador con datos manual");
		System.out.println("2. Jugador sin datos");
		opcion = teclado.nextInt();
		
		while(opcion > 2) {
			System.out.println("1. Jugador con datos manual");
			System.out.println("2. Jugador sin datos");
			opcion = teclado.nextInt();
		}
		
		if(opcion == 1) {
			System.out.println("Introduzca la altura del jugador: ");
			altura = teclado.nextDouble();
			System.out.println("Introduzca el porcentaje de dos: ");
			porcentajededos = teclado.nextDouble();
			System.out.println("Introduzca el porcentaje de tres: ");
			porcentajedetres = teclado.nextDouble();
			j1 = new Jugador(altura, porcentajededos, porcentajedetres);
		}
		if(opcion == 2) {
			j1 = new Jugador();
		}
		
		
		j1.entrenar_tres(10);
		j1.entrenar_dos(10);
		
		System.out.println("�Cuanto porcentaje de dobles deseas conseguir?");
		p1 = teclado.nextDouble();
		System.out.println("�Cuanto porcentaje de triples deseas conseguir?");
		p2 = teclado.nextDouble();
		
//		if(p1 < j1.getPorcentajedos()) {
//			
//		}
		while(j1.getPorcentajedos() <= p1) {
			j1.entrenar_dos();
		}
		while(j1.getPorcentajetres() <= p2) {
			j1.entrenar_tres();
		}
		
		System.out.println("�Cuantas canastas de dos desea encestar?");
		canasta = teclado.nextInt();
		
		while(cont1 != canasta) {
			acierto = j1.lanzar_de_dos();
			if(acierto) {
				cont1++;
			}
			else {
				fallos++;
			}
		}
		System.out.println("�Cuantas canastas de tres desea encestar?");
		canasta2 = teclado.nextInt();
		while (cont2!= canasta2) {
			if(j1.lanzar_de_tres()) {
				cont2++;
			}
			else {
				fallos2++;
			}
			
		}
		System.out.println("El jugador ha encestado: " + cont1 + " canastas de dos y ha fallado: " + fallos);
		System.out.println("El jugador ha encestado: " + cont2 + " canastas de tres y ha fallado: " + fallos2);
		System.out.println(j1.toString());
		teclado.close();
		
// A partir de aqui es con datos introducidos ya de por si
//		j2.entrenar_tres(10);
//		j2.entrenar_dos(10);
		
//		while(j2.getPorcentajedos() <= 0.65) {
//			j2.entrenar_dos();
//		}
//		while(j2.getPorcentajetres() <= 0.45) {
//			j2.entrenar_tres();
//		}
		
		/*while(cont1 != 10) {
			acierto = j2.lanzar_de_dos();
			if(acierto) {
				cont1++;
			}
		}
		while (cont2!=4) {
			
			if(j2.lanzar_de_tres()) {
				cont2++;
			}
			
		}
		
		while(cont3 != 10) {
			acierto = j2.lanzar_de_dos();
			if(acierto == true) {
				cont3++;
			}
		}
		while (cont4!=4) {
			acierto2 = j2.lanzar_de_tres();
			if(acierto2 == true) {
				cont4++;
			}
			
		}*/
		
	
		
		//System.out.println(j2.toString());

	}

}
