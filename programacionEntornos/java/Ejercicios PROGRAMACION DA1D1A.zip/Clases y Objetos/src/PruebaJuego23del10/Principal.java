package PruebaJuego23del10;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		int suerte=0, vida=100, turno = 1, eleccion=0, eleccion2=0;
		suerte = (int) (Math.random()*100);
		double prob = 0, prob2 = 0;
		Planta p1 = new Planta(1);
		Jugador j1 = new Jugador(vida,suerte, p1);
		Scanner teclado = new Scanner(System.in);
		
		while(turno!= 100 || vida != 0) {
			System.out.println("Elige comando: ");
			System.out.println("1. Mover derecha");
			System.out.println("2. Mover izquierda");
			System.out.println("3. Mover hacia delante");
			System.out.println("4. Mover hacia atr�s");
			System.out.println("5. Subir una planta");
			System.out.println("6. Bajar una planta");
			System.out.println("7. Buscar Diamantes");
			System.out.println("10. Mostrar planta y coordenadas del jugador");
			System.out.println("11. Mostrar Lista de comandos");
			System.out.println("12. Mostrar turno");
			eleccion = teclado.nextInt();
			switch(eleccion) {
			case 1:
				j1.moverDerecha();
				turno++;
				break;
			case 2:
				j1.moverIzquierda();
				turno++;
				break;
			case 3:
				j1.moverAdelante();
				turno++;
				break;
			case 4:
				j1.moverAtras();
				turno++;
				break;
			case 5:
				j1.subirPlanta();
				turno++;
				break;
			case 6:
				j1.bajarPlanta();
				turno++;
				break;
			case 7:
				prob = j1.buscarDiamantes();
				if(prob <= 20) {
					System.out.println("8. Huir");
					System.out.println("9. Pelear");
					eleccion2=teclado.nextInt();
					switch(eleccion2) {
					case 8:
						prob2 = j1.huir();
						if(prob2 <= 90) {
							System.out.println("Ha vuelto a la posicion anterior");
						}
						else {
							System.out.println("Ha perdido vida");
						}
						break;
					case 9:
						prob2 = j1.pelear();
						if(prob2 <= 30) {
							System.out.println("Pelea ganada");
						}
						else if(prob2 > 30){
							System.out.println("Ha perdido vida");
						}
						break;
					}
				}
				else {
					System.out.println("Diamantes encontrados sin problemas");
				}
				turno++;
				break;
			case 10:
				System.out.println(j1.toString());
				break;
			case 11:
				System.out.println("Lista de comandos: \n");
				System.out.println("1. Mover derecha");
				System.out.println("2. Mover izquierda");
				System.out.println("3. Mover hacia delante");
				System.out.println("4. Mover hacia atr�s");
				System.out.println("5. Subir una planta");
				System.out.println("6. Bajar una planta");
				System.out.println("7. Buscar Diamantes");
				System.out.println("10. Mostrar planta y coordenadas del jugador");
				System.out.println("11. Mostrar Lista de comandos");
				System.out.println("12. Mostrar turno\n");
				break;
			case 12: 
				System.out.println("Su turno es el: " + turno);
				break;
			}
		}
		teclado.close();
	}

}
