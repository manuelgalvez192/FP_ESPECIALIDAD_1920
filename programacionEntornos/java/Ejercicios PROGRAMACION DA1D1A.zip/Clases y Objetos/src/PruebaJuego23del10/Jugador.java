package PruebaJuego23del10;

public class Jugador {
	private int vida;
	private int suerte;
	private int diamantes;
	private Planta p1;
	private Habitacion h1;
	private Habitacion anterior;
	
	public Jugador(int vida, int suerte, Planta p1) {
		this.vida = vida;
		this.suerte = suerte;
		this.p1 = p1;
		this.h1 = new Habitacion(0,0);
		this.anterior = null;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getSuerte() {
		return suerte;
	}

	public void setSuerte(int suerte) {
		this.suerte = suerte;
	}

	public int getDiamantes() {
		return diamantes;
	}

	public void setDiamantes(int diamantes) {
		this.diamantes = diamantes;
	}
		
	public Planta getP1() {
		return p1;
	}

	public void setP1(Planta p1) {
		this.p1 = p1;
	}

	public Habitacion getH1() {
		return h1;
	}

	public void setH1(Habitacion h1) {
		this.h1 = h1;
	}
	
	public void guardarAnterior(int coordX, int coordY) {
		this.anterior = new Habitacion(coordX, coordY);
	}
	
	public Habitacion getAnterior() {
		return anterior;
	}

	public void moverDerecha() {
		this.guardarAnterior(this.getH1().getCoordX(),this.getH1().getCoordY());
		if(this.getH1().getCoordX() == 0) {
			if(this.getH1().getCoordY() < 3) {
				this.getH1().setCoordY(this.getH1().getCoordY()+1); 
			}
			else {
				System.out.println("No puede realizar ese movimiento");
			}
			
		}
		else if(this.getH1().getCoordX() == 1){
			if(this.getH1().getCoordY() < 3) {
				this.getH1().setCoordY(this.getH1().getCoordY()+1); 
			}
			else {
				System.out.println("No puede realizar ese movimiento");
			}
		}
		else if(this.getH1().getCoordX() == 2) {
			if(this.getH1().getCoordY() < 3) {
				this.getH1().setCoordY(this.getH1().getCoordY()+1); 
			}
			else {
				System.out.println("No puede realizar ese movimiento");
			}
		}
		
		else {
			System.out.println("No puede realizar ese movimiento");
		}
	}
	public void moverIzquierda() {
		this.guardarAnterior(this.getH1().getCoordX(),this.getH1().getCoordY());
		if(this.getH1().getCoordX() == 0) {
			if(this.getH1().getCoordY() >= 1 && this.getH1().getCoordY()<3) {
				this.getH1().setCoordY(this.getH1().getCoordY()-1);
			}
			else {
				System.out.println("No puede realizar ese movimiento");
			}
					
		}
		else if(this.getH1().getCoordX() == 1) {
			if(this.getH1().getCoordY() >= 1 && this.getH1().getCoordY()<3) {
				this.getH1().setCoordY(this.getH1().getCoordY()-1);
			}
			else {
				System.out.println("No puede realizar ese movimiento");
			}
		}
		else if(this.getH1().getCoordX() == 2) {
			if(this.getH1().getCoordY() >= 1 && this.getH1().getCoordY()<3) {
				this.getH1().setCoordY(this.getH1().getCoordY()-1);
			}
			else {
				System.out.println("No puede realizar ese movimiento");
			}
		}
	}
	public void moverAdelante() {
		this.guardarAnterior(this.getH1().getCoordX(),this.getH1().getCoordY());
		if(this.getH1().getCoordX() == 0) {
			this.getH1().setCoordX(this.getH1().getCoordX()+1);
			this.getH1().setCoordY(this.getH1().getCoordY());
					
		}
		else if(this.getH1().getCoordX() == 1){
			this.getH1().setCoordX(this.getH1().getCoordX()+1);
			this.getH1().setCoordY(this.getH1().getCoordY());
		}
		else if(this.getH1().getCoordX() == 2) {
			System.out.println("No puede realizar ese movimiento");
		}
		else {
			System.out.println("No puede realizar ese movimiento");
		}
	}
	public void moverAtras() {
		this.guardarAnterior(this.getH1().getCoordX(),this.getH1().getCoordY());
		if(this.getH1().getCoordX() == 0) {
			System.out.println("No puede realizar ese movimiento");
		}
		else if(this.getH1().getCoordX() == 1){
			this.getH1().setCoordX(this.getH1().getCoordX()-1);
			this.getH1().setCoordY(this.getH1().getCoordY());
		}
		else if(this.getH1().getCoordX() == 2) {
			this.getH1().setCoordX(this.getH1().getCoordX()-1);
			this.getH1().setCoordY(this.getH1().getCoordY());
		}
		else {
			System.out.println("No puede realizar ese movimiento");
		}
	}
	public void subirPlanta() {
		int planta = this.getP1().getPlanta()+1;
		if (this.getP1().getPlanta() >= 3) {
			this.getP1().setPlanta(3);
			System.out.println("No puede subir m�s");
		}
		else {
			this.getP1().setPlanta(planta);
		}
	}
	public void bajarPlanta() {
		int planta = this.getP1().getPlanta()-1;
		if (this.getP1().getPlanta() <= 1) {
			this.getP1().setPlanta(1);
			System.out.println("No puede bajar m�s");
		}
		else {
			this.getP1().setPlanta(planta);
		}
	}
	public double buscarDiamantes() {
		double prob = 0, error = 0;
		prob = Math.random()*100;
		if(prob < this.suerte) {
			if(prob <= 20) {
				return prob;
			}
			else if(prob > 20) {
				this.diamantes+=10;
				return prob;
			}
			
		}
		return error;
	}
	
	public double huir() {
		double prob = 0, error = 0;
		prob = Math.random()*100;
		if(prob <= 90) {
			this.setH1(this.getAnterior());
			return prob;
		}
		else if(prob > 90) {
			this.setVida(this.getVida()-10);
			return prob;
		}
		return error;
	}
	public double pelear() {
		double prob = 0, error = 0;
		prob = Math.random()*100;
		if(prob <= 30) {
			this.setDiamantes(this.getDiamantes()+3);
			return prob;
		}
		else if(prob > 30){
			this.setVida(this.getVida()-10);
			return prob;
		}
		return error;
	}
	@Override
	public String toString() {
		return "Planta: " + this.p1.getPlanta() + " Habitacion: " + "("+ this.h1.getCoordX() +","+ this.h1.getCoordY() +")";
	}
	
}
