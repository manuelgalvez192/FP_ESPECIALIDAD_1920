package PruebaJuego23del10;

public class Planta {
	private Habitacion h1;
	private Habitacion h2;
	private Habitacion h3;
	private Habitacion h4;
	private Habitacion h5;
	private Habitacion h6;
	private Habitacion h7;
	private Habitacion h8;
	private Habitacion h9;
	private Habitacion h10;
	private Habitacion h11;
	private Habitacion h12;
	private int planta;
	
	public Planta(int planta) {
		this.h1 = new Habitacion(0,0);
		this.h2 = new Habitacion(0,1);
		this.h3 = new Habitacion(0,2);
		this.h4 = new Habitacion(0,3);
		this.h5 = new Habitacion(1,0);
		this.h6 = new Habitacion(1,1);
		this.h7 = new Habitacion(1,2);
		this.h8 = new Habitacion(1,3);
		this.h9 = new Habitacion(2,0);
		this.h10 = new Habitacion(2,1);
		this.h11 = new Habitacion(2,2);
		this.h12 = new Habitacion(2,3);
		/*
		this.h1 = new ArrayList<Habitacion>();
		for(int i=0; i<3; i++) {
			for(int j=0; j<4; j++) {
				this.h2 = new Habitacion(i,j);
				h1.add(h2);				
			}
		}*/
		this.planta = planta;
	}

	public Habitacion getH1() {
		return h1;
	}

	public void setH1(Habitacion h1) {
		this.h1 = h1;
	}

	public Habitacion getH2() {
		return h2;
	}

	public void setH2(Habitacion h2) {
		this.h2 = h2;
	}

	public Habitacion getH3() {
		return h3;
	}

	public void setH3(Habitacion h3) {
		this.h3 = h3;
	}

	public Habitacion getH4() {
		return h4;
	}

	public void setH4(Habitacion h4) {
		this.h4 = h4;
	}

	public Habitacion getH5() {
		return h5;
	}

	public void setH5(Habitacion h5) {
		this.h5 = h5;
	}

	public Habitacion getH6() {
		return h6;
	}

	public void setH6(Habitacion h6) {
		this.h6 = h6;
	}

	public Habitacion getH7() {
		return h7;
	}

	public void setH7(Habitacion h7) {
		this.h7 = h7;
	}

	public Habitacion getH8() {
		return h8;
	}

	public void setH8(Habitacion h8) {
		this.h8 = h8;
	}

	public Habitacion getH9() {
		return h9;
	}

	public void setH9(Habitacion h9) {
		this.h9 = h9;
	}

	public Habitacion getH10() {
		return h10;
	}

	public void setH10(Habitacion h10) {
		this.h10 = h10;
	}

	public Habitacion getH11() {
		return h11;
	}

	public void setH11(Habitacion h11) {
		this.h11 = h11;
	}

	public Habitacion getH12() {
		return h12;
	}

	public void setH12(Habitacion h12) {
		this.h12 = h12;
	}

	public int getPlanta() {
		return planta;
	}

	public void setPlanta(int planta) {
		this.planta = planta;
	}
	
	
	
}
