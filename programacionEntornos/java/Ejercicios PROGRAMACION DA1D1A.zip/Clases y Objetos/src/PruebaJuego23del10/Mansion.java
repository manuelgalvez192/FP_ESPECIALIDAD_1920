package PruebaJuego23del10;

public class Mansion {
	private Planta p1;
	private Planta p2;
	private Planta p3;
	private Jugador j1;
	
	public Mansion(Planta p1, Planta p2, Planta p3, Jugador j1) {
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
		this.j1 = j1;
	}
	
	
}
