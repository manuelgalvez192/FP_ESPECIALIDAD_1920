package ProyectoAhorcado;

import java.util.Scanner;

public class MainAhorcado {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		String palabra = "", palabra2 = ""/*, op=""*/;
		boolean res = true, acierto = false, res2 = true;
		int opcion = 0;
		char c; //caracter a buscar en la palabra
		
		System.out.println("Introduzca palabra a adivinar");
		palabra = teclado.nextLine();
		
		Ahorcado ah = new Ahorcado(palabra);
		
		while(opcion != 4 && !acierto) {
			System.out.println("�Que desea hacer?");
			System.out.println("1. Probar letra");
			System.out.println("2. Resolver");
			System.out.println("3. Ver vidas disponibles");
			System.out.println("4. Abandonar");
			//op = teclado.nextLine();
			//opcion = Integer.parseInt(op);
			opcion = teclado.nextInt();
			teclado.nextLine();
			switch(opcion) {
			
			case 1:
				System.out.println("Introduzca letra a probar");
				c = teclado.next().charAt(0);			
				
				res = ah.probarLetra(c);
				
				if(res) {
					System.out.println("Letra encontrada");
					System.out.println("Cadena: "+ ah.getT());
				}
				else {
					System.out.println("Letra no encontrada");
					ah.setVida(ah.getVida()-1);
				}
				
				break;
			case 2:
				System.out.println("Introduzca la palabra que usted crea que es la correcta: ");
				palabra2 = teclado.nextLine();
				
				res2 = ah.comprobarPalabra(palabra2);

				if(res2) {
					acierto = true;
					System.out.println("Enhorabuena, ha acertado la palabra");
				}
				else {
					System.out.println("Por desgracia no ha acertado");
					ah.setVida(ah.getVida()-1);
				}
				
				break;
			case 3:
				System.out.println("Vidas: " + ah.getVida());
				break;
			case 4:
				System.out.println("Game Over");
				break;
			default:
				System.out.println("Opcion err�nea");
			}
		}
		
		
		teclado.close();
		
	}

}
