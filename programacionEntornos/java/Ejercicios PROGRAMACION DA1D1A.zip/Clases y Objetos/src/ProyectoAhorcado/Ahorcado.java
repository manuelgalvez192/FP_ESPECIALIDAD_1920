package ProyectoAhorcado;

public class Ahorcado {
	private String s; //String que queremos adivinar
	private int vida; //Numero de vidas disponible
	private String t = ""; //String provisional donde se va a�adiendo las letras encontradas
	
	public Ahorcado(String s) {
		this.s = s;
		this.vida = 6;
		for(int i=0;i<this.s.length();i++) {
			this.t += ';';
		}
	}

	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}
		
	public String getT() {
		return t;
	}

	public void setT(String t) {
		this.t = t;
	}

	public boolean probarLetra(char c) {
		boolean res = false;
		int pos = 0;
		char s;
		
		for(int i=0; i<this.s.length();i++) {
			if(c == this.s.charAt(i)) {
				pos = i;
				s = this.t.charAt(pos);
				this.t.replace(s,c);
				res = true;
			}
		}
		return res;
	}
	
	public boolean comprobarPalabra(String r) {
		boolean res = false;
		
		if(this.s.equals(r)) {
			res = true;
		}
		
		return res;
	}
	
	
	
	
	
	
	
}
