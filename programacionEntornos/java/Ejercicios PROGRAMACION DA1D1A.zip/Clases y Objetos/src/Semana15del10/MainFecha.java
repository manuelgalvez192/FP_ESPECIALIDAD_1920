package Semana15del10;

import java.util.Scanner;

public class MainFecha {

	public static void main(String[] args) {
		// dos fechas, bisiestas, compararlas, validas?,dias del mes de la fecha, siguientefecha y anteriorfecha
		int dia1 = 0, dia2 = 0, mes1 = 0, mes2 = 0, anyo1 = 0, anyo2 = 0;
		int comp=0, opcion =0;
		Fecha f1 = null;
		Fecha f2 = null;
		Fecha f3 = null, f4 = null, f5=null, f6=null;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca el dia de la primera fecha");
		dia1 = teclado.nextInt();
		System.out.println("Introduzca el mes de la primera fecha");
		mes1 = teclado.nextInt();
		System.out.println("Introduzca el a�o de la primera fecha");
		anyo1 = teclado.nextInt();
		
		if(dia1 > 31 || dia1 < 0) {
			System.out.println("Error de dia");
		}
		if(mes1<0 || mes1 > 12) {
			 System.out.println("Error de mes");
		}
		if(anyo1 < 0) {
			System.out.println("No existen a�os negativos");
		}
		
		f1 = new Fecha(dia1,mes1,anyo1);
		
		System.out.println("Introduzca el dia de la segunda fecha");
		dia2 = teclado.nextInt();
		System.out.println("Introduzca el mes de la segunda fecha");
		mes2 = teclado.nextInt();
		System.out.println("Introduzca el a�o de la segunda fecha");
		anyo2 = teclado.nextInt();
		
		if(dia2 > 31 || dia2 < 0) {
			System.out.println("Error de dia");
		}
		if(mes2<0 || mes2 > 12) {
			 System.out.println("Error de mes");
		}
		if(anyo2 < 0) {
			System.out.println("No existen a�os negativos");
		}
		
		f2 = new Fecha(dia2,mes2,anyo2);
		
		while(opcion != 7) {
			System.out.println("Elige opcion: ");
			System.out.println("1. Bisiesto");
			System.out.println("2. Comparar");
			System.out.println("3. Valida");
			System.out.println("4. DiaMes");
			System.out.println("5. Fecha Siguiente");
			System.out.println("6. Fecha Anterior");
			System.out.println("7. Salir");
			opcion = teclado.nextInt();
			switch(opcion) {
			case 1: 
				if(f1.bisiesto()) {
					System.out.println(anyo1 + " es A�o bisiesto");
				}
				else {
					System.out.println(anyo1 + " es A�o NO bisiesto");
				}
				
				if(f2.bisiesto()) {
					System.out.println(anyo2 + " es A�o bisiesto");
				}
				else {
					System.out.println(anyo2 + " es A�o NO bisiesto");
				}
				break;
			case 2:
				comp = f1.comparar(f2);
				if(comp == 0) {
					System.out.println("Ambas fechas son iguales");
				}
				else if(comp == 1) {
					System.out.println("Fecha1 mayor que Fecha2");
				}
				else if(comp == -1) {
					System.out.println("Fecha1 menor que Fecha2");
				}
				break;
			case 3:
				if(f1.valida()) {
					System.out.println("La fecha: " + f1.toString() + " es valida");
				}
				else {
					System.out.println("La fecha: " + f1.toString() + " NO es valida");
				}
				
				if(f2.valida()) {
					System.out.println("La fecha: " + f2.toString() + " es valida");
				}
				else {
					System.out.println("La fecha: " + f2.toString() + " NO es valida");
				}
				break;
			case 4:
				System.out.println("Dias del mes de la fecha1: " + f1.diasMes());
				System.out.println("Dias del mes de la fecha2: " + f2.diasMes());
				break;
			case 5:
				f3 = f1.siguienteFecha();
				System.out.println("Fecha siguiente: " + f3.toString());
				f4 = f2.siguienteFecha();
				System.out.println("Fecha siguiente: " + f4.toString());
				break;
			case 6:
				f5 = f1.anteriorFecha();
				f6 = f2.anteriorFecha();
				System.out.println("Fecha anterior: " + f5.toString());
				System.out.println("Fecha anterior: " + f6.toString());
				break;
			case 7:
				System.out.println("Adios");
				break;
			default:
				System.out.println("Opcion erronea");
				
			}
		}
//		if(f1.bisiesto()) {
//			System.out.println(anyo1 + " es A�o bisiesto");
//		}
//		else {
//			System.out.println(anyo1 + " es A�o NO bisiesto");
//		}
//		
//		if(f2.bisiesto()) {
//			System.out.println(anyo2 + " es A�o bisiesto");
//		}
//		else {
//			System.out.println(anyo2 + " es A�o NO bisiesto");
//		}
//		
//		comp = f1.comparar(f2);
//		if(comp == 0) {
//			System.out.println("Ambas fechas son iguales");
//		}
//		else if(comp == 1) {
//			System.out.println("Fecha1 mayor que Fecha2");
//		}
//		else if(comp == -1) {
//			System.out.println("Fecha1 menor que Fecha2");
//		}
//		
//		if(f1.valida()) {
//			System.out.println("La fecha: " + f1.toString() + " es valida");
//		}
//		else {
//			System.out.println("La fecha: " + f1.toString() + " NO es valida");
//		}
//		
//		if(f2.valida()) {
//			System.out.println("La fecha: " + f2.toString() + " es valida");
//		}
//		else {
//			System.out.println("La fecha: " + f2.toString() + " NO es valida");
//		}
//		
//		System.out.println("Dias del mes de la fecha1: " + f1.diasMes());
//		System.out.println("Dias del mes de la fecha2: " + f2.diasMes());
//		
//		f3 = f1.siguienteFecha();
//		System.out.println("Fecha siguiente: " + f3.toString());
//		f4 = f2.siguienteFecha();
//		System.out.println("Fecha siguiente: " + f4.toString());
//		
//		f5 = f1.anteriorFecha();
//		f6 = f2.anteriorFecha();
//		
//		System.out.println("Fecha anterior: " + f5.toString());
//		System.out.println("Fecha anterior: " + f6.toString());
		
		teclado.close();
	}

}
