package Semana15del10;

import java.util.Scanner;

public class MainCalculadora {

	public static void main(String[] args) {
		// menu, pide dos numeros, 1suma 2resta...7salir en bucle hasta salir
		int n1 = 0, n2=0;
		int opcion = 0;
		
		Scanner teclado = new Scanner(System.in);
		while(opcion != 7) {
			System.out.println("Introduzca un numero: ");
			n1 = teclado.nextInt();
			System.out.println("Introduzca otro numero: ");
			n2 = teclado.nextInt();
			System.out.println("Elige opcion: ");
			System.out.println("1. Sumar");
			System.out.println("2. Restar");
			System.out.println("3. Multiplicar");
			System.out.println("4. Dividir");
			System.out.println("5. Potenciar");
			System.out.println("6. Mostrar resto");
			System.out.println("7. Salir");
			opcion = teclado.nextInt();
			switch(opcion) {
			case 1: 
				System.out.println("Suma: "+ Calculadora.suma(n1, n2)  +"\n");
				break;
			case 2:
				System.out.println("Resta: " + Calculadora.resta(n1, n2) +"\n");
				break;
			case 3:
				System.out.println("Multiplicacion: " + Calculadora.producto(n1, n2) +"\n");
				break;
			case 4:
				System.out.println("Division: " + Calculadora.division(n1, n2) +"\n");
				break;
			case 5:
				System.out.println("Potencia: " + Calculadora.potencia(n1, n2) +"\n");
				break;
			case 6: 
				System.out.println("Resto: " + Calculadora.restodivision(n1, n2) +"\n");
				break;
			case 7:
				System.out.println("Adios\n");
				break;
			default:
				System.out.println("Opcion incorrecta \n");
			}
		}
		
		teclado.close();
		
	}
	

}
