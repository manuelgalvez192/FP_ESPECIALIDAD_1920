package Semana15del10;

import java.util.Scanner;

public class MainCuenta {

	public static void main(String[] args) {
		// COMPARAR ANTIGUEDAD DE LAS CUENTAS, VER CUAL MAS ANTIGUA
		// COMPROBAR BISIESTO SI LA CUENTA SE ABRE EN BISIESTO
		// ACTUALIZAR SALDO, INGRESAR DINERO, RETIRAR DINERO, COMPARAR DUE�OS CON EL NIF, COMPARAR SALDOs
		
		Cuenta c1 = null;
		Cuenta c2 = null;
		int opcion = 0, opcion2=0, opcion3=0;
		int nif=0, id=0, nif2=0, id2=0;
		int dia1 = 0, dia2 = 0, mes1 = 0, mes2 = 0, anyo1 = 0, anyo2 = 0;
		double cantidad1=0, cantidad2 = 0, cantidad3 = 0, cantidad4=0;
		double saldo1=1200, saldo2=5000;
		final double INTERES1 = 0.12, INTERES2 = 0.09;
		Fecha f1 = null, f2 = null;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca el NIF de la primera cuenta: ");
		nif = teclado.nextInt();
		System.out.println("Introduzca el ID de la primera cuenta: ");
		id = teclado.nextInt();
		System.out.println("Introduzca el dia de la primera cuenta");
		dia1 = teclado.nextInt();
		System.out.println("Introduzca el mes de la primera cuenta");
		mes1 = teclado.nextInt();
		System.out.println("Introduzca el a�o de la primera cuenta");
		anyo1 = teclado.nextInt();
		f1 = new Fecha(dia1, mes1, anyo1);
		while(f1.valida() == false) {
			System.out.println("Vuelva a introducir la fecha");
			System.out.println("Introduzca el dia de la primera cuenta");
			dia1 = teclado.nextInt();
			System.out.println("Introduzca el mes de la primera cuenta");
			mes1 = teclado.nextInt();
			System.out.println("Introduzca el a�o de la primera cuenta");
			anyo1 = teclado.nextInt();
			f1 = new Fecha(dia1, mes1, anyo1);
			
		}
		System.out.println("Introduzca el NIF de la segunda cuenta: ");
		nif2 = teclado.nextInt();
		System.out.println("Introduzca el ID de la segunda cuenta: ");
		id2 = teclado.nextInt();
		System.out.println("Introduzca el dia de la segunda fecha");
		dia2 = teclado.nextInt();
		System.out.println("Introduzca el mes de la segunda fecha");
		mes2 = teclado.nextInt();
		System.out.println("Introduzca el a�o de la segunda fecha");
		anyo2 = teclado.nextInt();
		f2 = new Fecha(dia2,mes2,anyo2);
		while(f2.valida() == false) {
			System.out.println("Vuelva a introducir la fecha");
			System.out.println("Introduzca el dia de la segunda fecha");
			dia2 = teclado.nextInt();
			System.out.println("Introduzca el mes de la segunda fecha");
			mes2 = teclado.nextInt();
			System.out.println("Introduzca el a�o de la segunda fecha");
			anyo2 = teclado.nextInt();
			f2 = new Fecha(dia2,mes2,anyo2);
		}
		
		c1 = new Cuenta(nif, id, saldo1, INTERES1, f1);
		c2 = new Cuenta(nif2, id2, saldo2, INTERES2, f2);
		
		while(opcion !=3) {
			System.out.println("Elige opcion: ");
			System.out.println("1. Acceder a Cuenta1");
			System.out.println("2. Acceder a Cuenta2");
			System.out.println("3. Salir");
			opcion = teclado.nextInt();
			switch(opcion) {
			case 1:
				while(opcion2 != 8) {
					System.out.println("Datos de nuestra cuenta: \n" + c1.toString());
					System.out.println("Elige opcion: ");
					System.out.println("1. Actualizar Saldo");
					System.out.println("2. Ingresar Dinero");
					System.out.println("3. Retirar Dinero");
					System.out.println("4. Comparar Due�os");
					System.out.println("5. Comparar Saldo");
					System.out.println("6. Comparar Antig�edad");
					System.out.println("7. Comprobar FechaApertura Bisiesta");
					System.out.println("8. Salir");
					opcion2 = teclado.nextInt();
					switch(opcion2) {
						case 1:
							c1.actualizarSaldo();
							System.out.println("Su nuevo saldo es de: " + c1.getSaldo() + "\n");
							break;
						case 2:
							System.out.println("Introduzca la cantidad a ingresar: ");
							cantidad1 = teclado.nextDouble();
							c1.ingresarDinero(cantidad1);
							System.out.println("Nuevo saldo: " + c1.getSaldo()+ "\n");
							break;					
						case 3:
							System.out.println("Introduzca la cantidad a retirar: ");
							cantidad2 = teclado.nextDouble();
							c1.retirarDinero(cantidad2);
							System.out.println("Nuevo saldo: " + c1.getSaldo()+ "\n");
							break;
						case 4:
							if(c1.compararDue�os(c2)) {
								System.out.println("Mismo due�o"+ "\n");
							}
							else {
								System.out.println("Distinto due�o"+ "\n");
							}
							break;
						case 5:
							if(c1.compararCuenta(c2) == 1) {
								System.out.println("Cuenta1 tiene m�s saldo que la Cuenta2"+ "\n");
							}
							else if(c1.compararCuenta(c2) == -1) {
								System.out.println("Cuenta1 tiene menos saldo que la Cuenta2"+ "\n");
							}
							else if(c1.compararCuenta(c2) == 0) {
								System.out.println("Cuenta1 tiene el mismo saldo que la Cuenta2"+ "\n");
							}
							else {
								System.out.println("Error"+ "\n");
							}
							break;
							
						case 6:
							if(c1.compararAntiguedad(c2) == 1) {
								System.out.println("Cuenta1 tiene m�s a�os que la Cuenta2"+ "\n");
							}
							else if(c1.compararAntiguedad(c2) == -1) {
								System.out.println("Cuenta1 tiene menos a�os que la Cuenta2"+ "\n");
							}
							else if(c1.compararAntiguedad(c2) == 0) {
								System.out.println("Cuenta1 tiene los mismos a�os que la Cuenta2"+ "\n");
							}
							else {
								System.out.println("Error"+ "\n");
							}
							break;
							
						case 7:
							if(c1.comprobarFechaApertura()) {
								System.out.println("Fecha de apertura bisiesta: " + c1.getFechaapertura()+ "\n");
							}
							else {
								System.out.println("Fecha de apertura: " + c1.getFechaapertura()+ "\n");
							}
							break;
						case 8:
							System.out.println("Adios"+ "\n");
							break;
						default:
							System.out.println("Opcion erronea"+ "\n");
					}
				}
				break;
			case 2:
				while(opcion3 != 8) {
					System.out.println("Datos de nuestra cuenta: \n" + c2.toString());
					System.out.println("Elige opcion: ");
					System.out.println("1. Actualizar Saldo");
					System.out.println("2. Ingresar Dinero");
					System.out.println("3. Retirar Dinero");
					System.out.println("4. Comparar Due�os");
					System.out.println("5. Comparar Saldo");
					System.out.println("6. Comparar Antig�edad");
					System.out.println("7. Comprobar FechaApertura Bisiesta");
					System.out.println("8. Salir");
					opcion3 = teclado.nextInt();
					switch(opcion3) {
						
						case 1:
							c2.actualizarSaldo();
							System.out.println("Su nuevo saldo es de: " + c2.getSaldo() + "\n");
							break;
						case 2:
							System.out.println("Introduzca la cantidad a ingresar: ");
							cantidad3 = teclado.nextDouble();
							c2.ingresarDinero(cantidad3);
							System.out.println("Nuevo saldo: " + c2.getSaldo()+ "\n");
							break;					
						case 3:
							System.out.println("Introduzca la cantidad a retirar: ");
							cantidad4 = teclado.nextDouble();
							c2.retirarDinero(cantidad4);
							System.out.println("Nuevo saldo: " + c2.getSaldo()+ "\n");
							break;
						case 4:
							if(c2.compararDue�os(c1)) {
								System.out.println("Mismo due�o"+ "\n");
							}
							else {
								System.out.println("Distinto due�o"+ "\n");
							}
							break;
						case 5:
							if(c2.compararCuenta(c1) == 1) {
								System.out.println("Cuenta1 tiene m�s saldo que la Cuenta2"+ "\n");
							}
							else if(c2.compararCuenta(c1) == -1) {
								System.out.println("Cuenta1 tiene menos saldo que la Cuenta2"+ "\n");
							}
							else if(c2.compararCuenta(c1) == 0) {
								System.out.println("Cuenta1 tiene el mismo saldo que la Cuenta2"+ "\n");
							}
							else {
								System.out.println("Error"+ "\n");
							}
							break;
							
						case 6:
							if(c2.compararAntiguedad(c1) == 1) {
								System.out.println("Cuenta1 tiene m�s a�os que la Cuenta2"+ "\n");
							}
							else if(c2.compararAntiguedad(c1) == -1) {
								System.out.println("Cuenta1 tiene menos a�os que la Cuenta2"+ "\n");
							}
							else if(c2.compararAntiguedad(c1) == 0) {
								System.out.println("Cuenta1 tiene los mismos a�os que la Cuenta2"+ "\n");
							}
							else {
								System.out.println("Error"+ "\n");
							}
							break;
							
						case 7:
							if(c2.comprobarFechaApertura()) {
								System.out.println("Fecha de apertura bisiesta: " + c2.getFechaapertura()+ "\n");
							}
							else {
								System.out.println("Fecha de apertura: " + c2.getFechaapertura()+ "\n");
							}
							break;
						case 8:
							System.out.println("Adios"+ "\n");
							break;
						default:
							System.out.println("Opcion erronea"+ "\n");
					}
					
				}
				break;
			case 3:
				System.out.println("Adios\n");
				break;
			default:
				System.out.println("Opcion incorrecta");
				
			}	
		
		}
		teclado.close();
	}
}
