package Semana15del10;

public class Fecha {
	private int dia, mes, anyo;

	public Fecha(int dia, int mes, int anyo) {
		this.dia = dia;
		this.mes = mes;
		this.anyo = anyo;
	}

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		this.dia = dia;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		this.mes = mes;
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		this.anyo = anyo;
	}
	
	public boolean bisiesto() {

		if (this.anyo % 4 == 0) {
			if (this.anyo % 100 == 0) {
				if (this.anyo % 400 == 0) {
					return true;
				} 
				else {
					return false;
				}
			}
			else {
				return false;
			}

		} 
		else {
			return false;
		}

	}
	
	public int comparar(Fecha f2) {
		//mayor menor o igual
		int mayor = 1, menor = -1, igual = 0, error = 2;
		
		if(this.dia < f2.dia) {
			if(this.mes < f2.mes) {
				if(this.anyo < f2.anyo) {
					return menor;
				}
				else if(this.anyo > f2.anyo) {
					return mayor;
				}
				else {
					return menor;
				}
			}
			else if(this.mes > f2.mes) {
				if(this.anyo < f2.anyo) {
					return menor;
				}
				else if(this.anyo > f2.anyo){
					return mayor;
				}
				else {
					return mayor;
				}
			}
			else if(this.mes == f2.mes) {
				if(this.anyo < f2.anyo) {
					return menor;
				}
				else if(this.anyo > f2.anyo) {
					return mayor;
				}
				else {
					return menor;
				}
			}
		}
		else if(this.dia > f2.dia) {
			if(this.mes < f2.mes) {
				if(this.anyo < f2.anyo) {
					return menor;
				}
				else if(this.anyo > f2.anyo) {
					return mayor;
				}
				else {
					return menor;
				}
			}
			else if(this.mes > f2.mes) {
				if(this.anyo < f2.anyo) {
					return menor;
				}
				else if(this.anyo > f2.anyo){
					return mayor;
				}
				else {
					return mayor;
				}
			}
			else if(this.mes == f2.mes) {
				if(this.anyo < f2.anyo) {
					return menor;
				}
				else if(this.anyo > f2.anyo){
					return mayor;
				}
				else {
					return mayor;
				}
			}
		}
		else if(this.dia == f2.dia){
			if(this.mes < f2.mes) {
				if(this.anyo < f2.anyo) {
					return menor;
				}
				else if(this.anyo > f2.anyo) {
					return mayor;
				}
				else if(this.anyo == f2.anyo){
					return menor;
				}
			}
			else if(this.mes > f2.mes) {
				if(this.anyo < f2.anyo) {
					return menor;
				}
				else if(this.anyo > f2.anyo){
					return mayor;
				}
				else if(this.anyo == f2.anyo){
					return mayor;
				}
			}
			else if(this.mes == f2.mes) {
				if(this.anyo < f2.anyo) {
					return menor;
				}
				else if(this.anyo > f2.anyo){
					return mayor;
				}
				else if(this.anyo == f2.anyo){
					return igual;
				}
			}
		}
		return error;
	}
	
	public boolean valida() {
		if(dia == 31) {
			if(mes == 2 || mes == 4 || mes == 6 || mes == 9 || mes == 11) {
				return false;
			}
			else {
				return true;
			}
		}
		else if(dia == 30) {
			if(mes == 2) {
				return false;
			}
			else {
				return true;
			}
		}
		else if(dia == 29 && mes == 2) {
			if(this.bisiesto()) {
				return true;
			}
			else {
				return false;
			}
		}
		else if(dia > 0 && dia < 31) {
			if(mes >= 1 && mes <= 12) {
				return true;
			}
			else {
				return false;
			}
			
		}
		else{
			return false;
		}
		
	}
	
	public int diasMes() {
		int dias = 0;
		if(mes == 4 || mes == 6 || mes == 9 || mes == 11) {
			dias = 30;
		}
		else if(mes == 1 || mes == 3|| mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) {
			dias = 31;
		}
		else if(mes == 2) {
			if(this.bisiesto()) {
				dias = 29;
			}
			else {
				dias = 28;
			}
		}
		return dias;
	}
	
	public Fecha siguienteFecha() {
		Fecha f3 = null;
		int dia = 0, mes = 0, anyo = 0;
		if(this.dia == 30) {
			if(this.mes == 1 || this.mes == 3 || this.mes == 5 || this.mes == 12 || this.mes == 7 || this.mes == 8 || this.mes == 10) {
				dia = this.dia;
				dia++;
				f3 = new Fecha(dia, this.mes, this.anyo);
				return f3;
			}
			else if(this.mes == 2) {
				return null;
			}
			else {
				dia = 1;
				mes = this.mes;
				mes++;
				f3 = new Fecha(dia, mes, this.anyo);
				return f3;
			}
		}
		else if(this.dia == 31) {
			if(this.mes == 1 || this.mes == 3 || this.mes == 5 || this.mes == 7 || this.mes == 8 || this.mes == 10) {
				dia = 1;
				mes = this.mes;
				mes++;
				f3 = new Fecha(dia, mes, this.anyo);
				return f3;
			}
			else if(this.mes == 12) {
				dia = 1;
				mes = 1;
				anyo = this.anyo;
				anyo++;
				f3 = new Fecha(dia, mes, anyo);
				return f3;
			}
			else if (this.mes == 2 || this.mes == 4 || this.mes == 6 || this.mes == 9 || this.mes == 11){
				return null;
			}
		}
		else if(this.dia == 28) {
			if(this.mes == 2) {
				if(this.anyo % 4 == 0) {
					if(this.anyo % 100 == 0) {
						if(this.anyo % 400 == 0) {
							dia = this.dia;
							dia++;
							f3 = new Fecha(dia, this.mes, this.anyo);
							return f3;
						}
					}
				}
				else {
					dia = 1;
					mes = this.mes;
					mes++;
					f3 = new Fecha(dia, mes, this.anyo);
					return f3;
				}
			}
			else {
				dia = this.dia;
				dia++;
				f3 = new Fecha(dia, this.mes, this.anyo);
				return f3;
			}
		}
		else if	(this.dia == 29 && this.mes == 2) {
			if(this.anyo % 4 == 0) {
				if(this.anyo % 100 == 0) {
					if(this.anyo % 400 == 0) {
						dia = 1;
						mes = this.mes;
						mes++;
						f3 = new Fecha(dia, mes, this.anyo);
						return f3;
					}
				}
				
			}
			else {
				return null;
			}
		}
		else if(this.dia >= 1 && (this.dia != 28 || this.dia !=30 || this.dia!=31) && this.dia < 32) {
			dia = this.dia;
			dia++;
			f3 = new Fecha(dia, this.mes, this.anyo);
			return f3;
		}
		
		return f3;
	}
	
	public Fecha anteriorFecha() {
		Fecha f4 = null;
		if(this.dia == 1) {
			if(this.mes == 5 || this.mes == 12 || this.mes == 7 || this.mes == 8 || this.mes == 10) {
				this.dia--;
				this.mes--;
				f4 = new Fecha(this.dia, this.mes, this.anyo);
				return f4;
			}
			else if(this.mes == 3) {
				if(this.anyo % 4 == 0) {
					if(this.anyo % 100 == 0) {
						if(this.anyo % 400 == 0) {
							this.dia = 29;
							this.mes--;
							f4 = new Fecha(this.dia, this.mes, this.anyo);
							return f4;
						}
						else {
							this.dia = 28;
							this.mes--;
							f4 = new Fecha(this.dia, this.mes, this.anyo);
							return f4;
						}
					}
					else {
						this.dia = 28;
						this.mes--;
						f4 = new Fecha(this.dia, this.mes, this.anyo);
						return f4;
					}
				}
				else {
					this.dia = 28;
					this.mes--;
					f4 = new Fecha(this.dia, this.mes, this.anyo);
					return f4;
				}
				
			}
			else if(this.mes == 1) {
				this.dia = 31;
				this.mes = 12;
				this.anyo--;
				f4 = new Fecha(this.dia, this.mes, this.anyo);
				return f4;
			}
			else {
				this.dia = 30;
				this.mes--;
				f4 = new Fecha(this.dia, this.mes, this.anyo);
				return f4;
			}
		}
		
		else if(this.dia > 0 && this.dia < 32) {
			this.dia--;
			f4 = new Fecha(this.dia, this.mes, this.anyo);
			return f4;
		}
		return f4;
	}
	
	public String toString() {
		return this.dia + "/" + this.mes + "/" + this.anyo; 
	}
	
	
}
