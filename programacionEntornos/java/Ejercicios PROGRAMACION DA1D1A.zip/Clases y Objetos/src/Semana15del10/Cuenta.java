package Semana15del10;

public class Cuenta {
	//ID, NIF, SALDO, INTERES, FECHAAPERTURA
	//COMPARAR ANTIGUEDAD DE LAS CUENTAS, VER CUAL MAS ANTIGUA
	//COMPROBAR BISIESTO SI LA CUENTA SE ABRE EN BISIESTO
	// ACTUALIZAR SALDO(aplicar interes), INGRESAR DINERO, RETIRAR DINERO, COMPARAR DUE�OS CON EL NIF, COMPARAR SALDO(dos cuentas)
	private int nif;
	private int id;
	private double saldo;
	private double interes;
	private Fecha fechaapertura;
	
	public Cuenta(int nif, int id, double saldo, double interes, Fecha fechaapertura) {
		this.nif = nif;
		this.id = id;
		this.saldo = saldo;
		this.interes = interes;
		this.fechaapertura = fechaapertura;
	}
	
	public int getNif() {
		return nif;
	}
	public void setNif(int nif) {
		this.nif = nif;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public double getInteres() {
		return interes;
	}
	public void setInteres(double interes) {
		this.interes = interes;
	}
	public Fecha getFechaapertura() {
		return fechaapertura;
	}
	public void setFechaapertura(Fecha fechaapertura) {
		this.fechaapertura = fechaapertura;
	}
	
	public void actualizarSaldo() {
		double saldo = this.saldo;
		double interes = this.interes;
		saldo = saldo * interes;
		this.saldo += saldo;
	}
	
	public void ingresarDinero(double dinero) {
		double saldo = this.saldo;
		this.saldo = saldo + dinero;
	}
	
	public void retirarDinero(double dinero) {
		double saldo = this.saldo;
		this.saldo = saldo - dinero;
	}
	
	public boolean compararDue�os(Cuenta c1) {
		if(this.nif == c1.nif) {
			return true;
		}
		else {
			return false;
		}
	}
	public int compararCuenta(Cuenta c1) {
		int mayor = 1, menor = -1, igual = 0;
		if(this.saldo > c1.saldo) {
			return mayor;
		}
		else if(this.saldo < c1.saldo) {
			return menor;
		}
		else {
			return igual;
		}
	}
	public int compararAntiguedad(Cuenta c1) {
		int mayor = 1, menor = -1, igual = 0;
		if(this.fechaapertura.comparar(c1.fechaapertura) == 1) {
			return mayor;
		}
		else if(this.fechaapertura.comparar(c1.fechaapertura) == -1) {
			return menor;
		}
		else if(this.fechaapertura.comparar(c1.fechaapertura) == 0){
			return igual;
		} 
		else {
			return 2;
		}
	}
	public boolean comprobarFechaApertura() {
		if(this.fechaapertura.bisiesto()) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public String toString() {
		return "NIF: " + this.nif + ", ID: " + this.id + ", SALDO: " + this.saldo + ", INTERES: " + this.interes + ", FECHAAPERTURA: "
				+ this.fechaapertura + "\n";
	}
	
	
}
