package Semana15del10;

public class Rectangulo {
	private int x1, y1, x2, y2;
	private int x3, y3, x4, y4;
	public int a1, a2, a;
	public int b1, b2, b;
	public int a3, a4, m;
	public int b3, b4, n;
	
	// Mas facil seria solo con altura, base, x e y 
	public Rectangulo(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.x3 = x3;
		this.y3 = y3;
		this.x4 = x4;
		this.y4 = y4;
		this.a1 = this.x1 - this.x4;
		this.a2 = this.y1 - this.y4;
		this.a1 *= this.a1;
		this.a2 *= this.a2;
		this.a = (int)Math.sqrt(a1 + a2);
		this.b1 = this.x1 - this.x2;
		this.b2 = this.y1 - this.y2;
		this.b1 *= this.b1;
		this.b2 *= this.b2;
		this.b = (int)Math.sqrt(b1 + b2);
		this.a3 = this.x2 - this.x4;
		this.a4 = this.y2 - this.y4;
		this.a3 *= this.a3;
		this.a4 *= this.a4;
		this.m = (int)Math.sqrt(a3 + a4);
		this.b3 = this.x3 - this.x4;
		this.b4 = this.y3 - this.y4;
		this.b3 *= this.b3;
		this.b4 *= this.b4;
		this.n = (int)Math.sqrt(b3 + b4);
	}

	public int getX1() {
		return x1;
	}

	public void setX1(int x1) {
		this.x1 = x1;
	}

	public int getY1() {
		return y1;
	}

	public void setY1(int y1) {
		this.y1 = y1;
	}

	public int getX2() {
		return x2;
	}

	public void setX2(int x2) {
		this.x2 = x2;
	}

	public int getY2() {
		return y2;
	}

	public void setY2(int y2) {
		this.y2 = y2;
	}

	public int getX3() {
		return x3;
	}

	public void setX3(int x3) {
		this.x3 = x3;
	}

	public int getY3() {
		return y3;
	}

	public void setY3(int y3) {
		this.y3 = y3;
	}

	public int getX4() {
		return x4;
	}

	public void setX4(int x4) {
		this.x4 = x4;
	}

	public int getY4() {
		return y4;
	}

	public void setY4(int y4) {
		this.y4 = y4;
	}

	public void mover(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.x3 = x3;
		this.y3 = y3;
		this.x4 = x4;
		this.y4 = y4;
		this.a1 = this.x1 - this.x4;
		this.a2 = this.y1 - this.y4;
		this.a1 *= this.a1;
		this.a2 *= this.a2;
		this.a = (int)Math.sqrt(a1 + a2);
		this.b1 = this.x1 - this.x2;
		this.b2 = this.y1 - this.y2;
		this.b1 *= this.b1;
		this.b2 *= this.b2;
		this.b = (int)Math.sqrt(b1 + b2);
		this.a3 = this.x2 - this.x4;
		this.a4 = this.y2 - this.y4;
		this.a3 *= this.a3;
		this.a4 *= this.a4;
		this.m = (int)Math.sqrt(a3 + a4);
		this.b3 = this.x3 - this.x4;
		this.b4 = this.y3 - this.y4;
		this.b3 *= this.b3;
		this.b4 *= this.b4;
		this.n = (int)Math.sqrt(b3 + b4);
	}
	public double area() {
		int a1 = this.x1 - this.x4;
		a1 *= a1;
		int a2 = this.y1 - this.y4;
		a2 *= a2;
		int a = (int) Math.sqrt(a1 + a2);
		int b1 = this.x1 - this.x2;
		b1 *= a1;
		int b2 = this.y1 - this.y2;
		b2 *= b2;
		int b = (int) Math.sqrt(b1 + b2);
		double area = 0;
		area = b * a;
		return area;
	}
	public double perimetro() {
		int a1 = this.x1 - this.x4;
		a1 *= a1;
		int a2 = this.y1 - this.y4;
		a2 *= a2;
		int a = (int) Math.sqrt(a1 + a2);
		int b1 = this.x1 - this.x2;
		b1 *= a1;
		int b2 = this.y1 - this.y2;
		b2 *= b2;
		int b = (int) Math.sqrt(b1 + b2);
		double perimetro = 0;
		perimetro = (2 * b) + (2 * a);
		return perimetro;
	}
}
