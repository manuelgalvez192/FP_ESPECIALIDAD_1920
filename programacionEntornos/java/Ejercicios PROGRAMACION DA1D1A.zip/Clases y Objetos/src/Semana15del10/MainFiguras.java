package Semana15del10;

import java.util.Scanner;

public class MainFiguras {

	public static void main(String[] args) {
		// rectangulo y circulo, metodos: moverlos, calcular area, permitro, circulos: distancia entre centros de dos circulos
		
		Circulo c1 = null, c2 = new Circulo(4.2, 3, 5);
		Rectangulo r1 = null;
		int opcion = 0, opcion2 = 0;
		int radio = 0, x=0, y=0, x1=0, y1=0;
		int x2=0, y2=0, x3=0, y3=0, x4=0, y4=0, x5=0, y5=0;
		int x6=0, y6=0, x7=0, y7=0, x8=0, y8=0, x9=0, y9=0;
		
		Scanner teclado = new Scanner(System.in);
		
		while(opcion != 3) {
			System.out.println("Elige opcion: ");
			System.out.println("1. Rectangulo");
			System.out.println("2. Circulo");
			System.out.println("3. Salir");
			opcion = teclado.nextInt();
			switch(opcion) {
			case 1:
				System.out.println("Introduzca la coordenada x de la esquina superior-izquierda del rectangulo");
				x2 = teclado.nextInt();
				System.out.println("Introduzca la coordenada y de la esquina superior-izquierda del rectangulo");
				y2 = teclado.nextInt();
				System.out.println("Introduzca la coordenada x de la esquina superior-derecha del rectangulo");
				x3 = teclado.nextInt();
				System.out.println("Introduzca la coordenada y de la esquina superior-derecha del rectangulo");
				y3 = teclado.nextInt();
				System.out.println("Introduzca la coordenada x de la esquina inferior-derecha del rectangulo");
				x4 = teclado.nextInt();
				System.out.println("Introduzca la coordenada y de la esquina inferior-derecha del rectangulo");
				y4 = teclado.nextInt();
				System.out.println("Introduzca la coordenada x de la esquina inferior-izquierda del rectangulo");
				x5 = teclado.nextInt();
				System.out.println("Introduzca la coordenada y de la esquina inferior-izquierda del rectangulo");
				y5 = teclado.nextInt();
				r1 = new Rectangulo(x2,y2,x3,y3,x4,y4,x5,y5);
				if((r1.a != r1.m) && (r1.b != r1.n) ) {
					System.out.println("No es un rectangulo");
				}
				System.out.println("Coordenadas del rectangulo: " + "\n" 
						+ "(" + r1.getX1() +","+r1.getY1()+ ")" + "(" + r1.getX2() +","+r1.getY2()+ ")" +"\n"
						+ "(" + r1.getX4() +","+r1.getY4()+ ")" + "(" + r1.getX3() +","+r1.getY3()+ ")" +"\n");
				while(opcion2 != 4) {
					System.out.println("Elige opcion: ");
					System.out.println("1. Mover");
					System.out.println("2. Area");
					System.out.println("3. Perimetro");
					System.out.println("4. Salir");
					opcion2 = teclado.nextInt();
					switch(opcion2) {
					case 1:
						System.out.println("Introduzca la coordenada x de la esquina superior-izquierda del rectangulo");
						x6 = teclado.nextInt();
						System.out.println("Introduzca la coordenada y de la esquina superior-izquierda del rectangulo");
						y6 = teclado.nextInt();
						System.out.println("Introduzca la coordenada x de la esquina superior-derecha del rectangulo");
						x7 = teclado.nextInt();
						System.out.println("Introduzca la coordenada y de la esquina superior-derecha del rectangulo");
						y7 = teclado.nextInt();
						System.out.println("Introduzca la coordenada x de la esquina inferior-derecha del rectangulo");
						x8 = teclado.nextInt();
						System.out.println("Introduzca la coordenada y de la esquina inferior-derecha del rectangulo");
						y8 = teclado.nextInt();
						System.out.println("Introduzca la coordenada x de la esquina inferior-izquierda del rectangulo");
						x9 = teclado.nextInt();
						System.out.println("Introduzca la coordenada y de la esquina inferior-izquierda del rectangulo");
						y9= teclado.nextInt();
						r1.mover(x6, y6, x7, y7, x8, y8, x9, y9);
//						if((r1.a != r1.m) && (r1.b != r1.n)) {
//							System.out.println("No es un rectangulo");
//						}
						System.out.println("Nuevas coordenadas del rectangulo: " + "\n" 
								+ "(" + r1.getX1() +","+r1.getY1()+ ")" + "(" + r1.getX2() +","+r1.getY2()+ ")" +"\n"
								+ "(" + r1.getX4() +","+r1.getY4()+ ")" + "(" + r1.getX3() +","+r1.getY3()+ ")" +"\n");
						break;
					case 2:
						System.out.println("Area: " + r1.area() +"\n");
						break;
					case 3:
						System.out.println("Perimetro: " + r1.perimetro() +"\n");
						break;
					}
				}
				break;
			case 2:
				System.out.println("Introduzca la coordenada x del centro del circulo");
				x = teclado.nextInt();
				System.out.println("Introduzca la coordenada y del centro del circulo");
				y = teclado.nextInt();
				System.out.println("Introduzca el radio del circulo");
				radio = teclado.nextInt();
				c1 = new Circulo(radio, x, y);
				while(opcion2 != 5) {
					System.out.println("Elige opcion: ");
					System.out.println("1. Mover");
					System.out.println("2. Area");
					System.out.println("3. Perimetro");
					System.out.println("4. Distancia entre centros");
					System.out.println("5. Salir");
					opcion2 = teclado.nextInt();
					switch(opcion2) {
					case 1:
						System.out.println("Nueva coordenada x");
						x1 = teclado.nextInt();
						System.out.println("Nueva coordenada y");
						y1 = teclado.nextInt();
						c1.mover(x1, y1);
						System.out.println("Nuevas coordenadas del circulo: " + "(" + c1.getX() +","+c1.getY()+ ") \n");
						break;
					case 2:
						System.out.println("Area: " + c1.area() +"\n");
						break;
					case 3:
						System.out.println("Perimetro: " + c1.perimetro()+"\n");
						break;
					case 4:
						System.out.println("Distancia: " + c1.distancia(c2)+"\n");
						break;
					case 5:
						System.out.println("Adios");
						break;
					default:
						System.out.println("Opcion erronea");
					}
				}
				break;
			case 3:
				System.out.println("Adios");
				break;
			default:
				System.out.println("Opcion erronea");
				
			}
		
		}
		
		teclado.close();
	}

}
