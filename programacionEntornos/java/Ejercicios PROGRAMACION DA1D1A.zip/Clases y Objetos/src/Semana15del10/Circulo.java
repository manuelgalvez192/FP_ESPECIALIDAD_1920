package Semana15del10;

public class Circulo {
	private double radio;
	private final double PI = 3.14;
	private int x;
	private int y;
	
	public Circulo(double radio, int x, int y) {
		
		this.radio = radio;
		this.x = x;
		this.y = y;
	}
	
	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}

	public double getPI() {
		return PI;
	}

	public void mover(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public double area() {
		double area = 0;
		area = (this.radio * this.radio) * PI;
		return area;
	}
	
	public double perimetro() {
		double perimetro = 0;
		perimetro = 2 * PI * this.radio;
		return perimetro;
	}
	
	public double distancia(Circulo c1) {
		double distancia = 0, total1 = 0, total2=0;
		
		total1 = this.x - c1.x;
		total1 *= total1;
		total2 = this.y - c1.y;
		total2 *= total2;
		distancia = Math.sqrt(total1+total2);
				
		return distancia;
	}
	
}
