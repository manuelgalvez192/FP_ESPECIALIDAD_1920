package Semana15del10;

public class Calculadora {
	//metodos devuelven int: suma(int,int) y asi con los demas,resta, producto,division,potencia,restodivision
	
	public static int suma (int n1, int n2) {
		int resultado = 0;
		resultado = n1 + n2;
		return resultado;
	}
	public static int resta (int n1, int n2) {
		int resultado = 0;
		resultado = n1-n2;
		return resultado;
	}
	public static int producto(int n1, int n2) {
		int resultado = 0;
		resultado = n1 * n2;
		return resultado;
	}
	public static int division(int n1, int n2) {
		int resultado = 0;
		resultado = n1 / n2;
		return resultado;
	}
	public static int potencia(int n1, int n2) {
		int resultado = 0;
		resultado = (int) Math.pow(n1, n2);
		return resultado;
	}
	public static int restodivision(int n1, int n2) {
		int resultado = 0;
		resultado = n1 % n2;
		return resultado;
	}
}
