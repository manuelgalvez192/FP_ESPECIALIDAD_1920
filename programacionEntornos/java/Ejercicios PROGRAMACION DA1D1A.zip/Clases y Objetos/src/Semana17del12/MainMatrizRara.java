package Semana17del12;

import java.util.Scanner;

public class MainMatrizRara {

	public static void main(String[] args) {
		// Generar matriz nxm donde debes mirar los adyacentes a una posicion pedida, calcular la media de los adyacentes
		// si la media mayor que el numero en esa posicion, sustituyes en una nueva matriz el numero en la posicion por el 
		// mayor de los adyacentes
		Scanner teclado = new Scanner(System.in);
		int[][] tablero;
		int[][] nueva;
		int[] pos;
		int fila = 0, col=0;
		int media = 0;
		
		System.out.println("Introduzca numero de filas de la matriz");
		fila = teclado.nextInt();
		System.out.println("Introduzca numero de columnas de la matriz");
		col = teclado.nextInt();
		
		tablero = new int[fila][col];
		pos = new int[2];
		
		for(int i=0; i<tablero.length;i++) {
			for(int j=0; j<tablero[i].length;j++) {
				tablero[i][j] = (int)(Math.random()*100);
			}
		}
		
		MatrizRara matriz = new MatrizRara(tablero);
		matriz.mostrarTablero();
		System.out.println();
		
		for(int i=0; i<=tablero.length-1;i++) {
			for(int j=0; j<=tablero[i].length-1;j++) {
				media = 0;
				pos[0] = i;
				pos[1] = j;
				media = matriz.calcularMedia(pos);
				nueva = matriz.nuevaMatriz(pos);
				for(int k=0; k<nueva.length;k++) {
					for(int l=0; l<nueva[k].length;l++) {
						System.out.print(nueva[k][l] + " ");
					}
					System.out.println();
				}
				System.out.println();
			}
		}	
		teclado.close();
	}

}
