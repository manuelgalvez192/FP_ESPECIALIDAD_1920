package Semana17del12;

public class MainMatrizLimites {

	public static void main(String[] args) {
		// Pides una posicion en una matriz nxm, y restar el numero en la posicion por el de su izquierda
		// pones en una nueva matriz en esa posicion el valor absoluto de la resta

	}

}
