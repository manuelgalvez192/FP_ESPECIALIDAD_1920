package Semana17del12;

public class MatrizRara {
	private int[][] tablero;
	private int media;

	public MatrizRara(int[][] tablero) {
		this.tablero = tablero;
		this.media = 0;
	}
	
	public int calcularMedia(int[] pos) {
		int media=0, cont=0;
		this.media = 0;
		
		if(pos[1] == this.tablero[0].length-1 && pos[0] == 0) {
			for(int i=0;i<=pos[0]+1;i++) {
				for(int j=pos[1]-1;j<=pos[1];j++) {
					media += tablero[i][j];
					if(j == pos[1] && i==0) {
						media-=tablero[i][j];
						cont--;
					}
					cont++;
				}
			}
		}
		else if(pos[1] == 0 && pos[0] == 0) {
			for(int i=0;i<=pos[0]+1;i++) {
				for(int j=0;j<=pos[1]+1;j++) {
					media += tablero[i][j];
					if(j == pos[1] && i==0) {
						media-=tablero[i][j];
						cont--;
					}
					cont++;
				}
			}
		}
		else if(pos[0] == this.tablero.length-1 && pos[1] == 0) {
			for(int i=pos[0]-1;i<=pos[0];i++) {
				for(int j=pos[1];j<=pos[1]+1;j++) {
					media += tablero[i][j];
					if(j == pos[1] && i==pos[0]) {
						media-=tablero[i][j];
						cont--;
					}
					cont++;
				}
			}
		}
		else if(pos[0] == this.tablero.length-1 && pos[1] == this.tablero[0].length-1) {
			for(int i=pos[0]-1;i<=pos[0];i++) {
				for(int j=pos[1]-1;j<=pos[1];j++) {
					media += tablero[i][j];
					if(j == pos[1] && i==pos[0]) {
						media-=tablero[i][j];
						cont--;
					}
					cont++;
				}
			}
		}
		else if(pos[0] == 0 && pos[1] > 0 && pos[1] <= this.tablero[0].length-2) {
			for(int i=0;i<=pos[0]+1;i++) {
				for(int j=pos[1]-1;j<=pos[1]+1;j++) {
					media += tablero[i][j];
					if(j == pos[1] && i==0) {
						media-=tablero[i][j];
						cont--;
					}
					cont++;
				}
			}
		}
		
		else if(pos[1] == 0 && pos[0] > 0 && pos[0] <= this.tablero.length-2) {
			for(int i=0;i<=pos[0]+1;i++) {
				for(int j=0;j<=pos[1]+1;j++) {
					media += tablero[i][j];
					if(j == pos[1] && i==0) {
						media-=tablero[i][j];
						cont--;
					}
					cont++;
				}
			}
		}
		else if(pos[0] == this.tablero.length-1 && pos[1] > 0 && pos[1] <= this.tablero[0].length-2) {
			for(int i=pos[0]-1;i<=pos[0];i++) {
				for(int j=pos[1]-1;j<=pos[1]+1;j++) {
					media += tablero[i][j];
					if(j == pos[1] && i==0) {
						media-=tablero[i][j];
						cont--;
					}
					cont++;
				}
			}
		}
		else if(pos[1] == this.tablero[0].length-1 && pos[0] > 0 && pos[0] <= this.tablero.length-2) {
			for(int i=0;i<=pos[0]+1;i++) {
				for(int j=pos[1]-1;j<=pos[1];j++) {
					media += tablero[i][j];
					if(j == pos[1] && i==0) {
						media-=tablero[i][j];
						cont--;
					}
					cont++;
				}
			}
		}
		else {
			for(int i=pos[0]-1;i<=pos[0]+1;i++) {
				for(int j=pos[1]-1;j<=pos[1]+1;j++) {
					media += tablero[i][j];
					if(j == pos[1] && i==pos[0]) {
						media-=tablero[i][j];
						cont--;
					}
					cont++;
				}
			}
		}
		
		media = media/cont;
		this.media = media;
		
		return media;
		
		
	}
	
	public int[][] nuevaMatriz(int[]pos){
		int[][] nueva = this.tablero;
		
		for(int i=0; i<nueva.length;i++) {
			for(int j=0; j<nueva[i].length;j++) {
				if(i == pos[0] && j==pos[1]) {
					nueva[i][j] = this.media;
				}
			}
		}
		return nueva;
	}
	
	public void mostrarTablero() {
		for(int i=0; i<this.tablero.length;i++) {
			for(int j=0; j<this.tablero[i].length;j++) {
				System.out.print(this.tablero[i][j] + " ");
			}
			System.out.println();
		}
	}
	
}
