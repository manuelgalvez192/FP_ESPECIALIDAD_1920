package Semana28del10;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

import Semana5del11.Stringclass;

public class EjercicioStrings {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		String lectura = null, lectura2 = null;
		String s1 = null;
		String s2 = null;
		String s3 = new String();
		String s4 = new String();
		String s5 = new String();
		String s6 = new String();
		String s7 = new String();
		String s9 = "";
		int l1 = 0, cont=0, l2=0, cont2=0, contador = 0;
		boolean res=false, espacio = true;
		char y3=0, m=0;
		
		System.out.println("Escribe frase: ");
		lectura = teclado.nextLine();
		l1 = lectura.length();
		l2 = lectura.length()/2;
				
		s1 = lectura.toUpperCase();
		s2 = lectura.toLowerCase();
		
		System.out.println(s1);
		System.out.println(s2);
		
		if(l1 >= 2) {
			char x = lectura.charAt(0);
			char y = lectura.charAt(1);
			System.out.println("Primeros caracteres: "+ x +","+y);
			char x1 = lectura.charAt(l1-2);
			char y1 = lectura.charAt(l1-1);
			System.out.println("Ultimos caracteres: "+ x1 +","+y1);
		}
		else {
			System.out.println("Cadena muy corta");
		}
		try {
			y3 = lectura.charAt(l1-1);
		} catch (StringIndexOutOfBoundsException e) {
			System.out.println("Cadena fuera de rango");
		} 

		for(int i=0; i<l1-1; i++) {
			if(lectura.charAt(i) == y3) {
			  cont++;
			}
		}
		System.out.println("Numero de ocurrencias: " + cont);
		
		try {
			m = lectura.charAt(0);
			m = Character.toLowerCase(m);
		} catch (StringIndexOutOfBoundsException e) {
			System.out.println("Cadena fuera de rango");
		}
		s5 += m;
		s3 += m;
		s5 = s5.toUpperCase();
		s3 = lectura.replace(s3,s5);
		System.out.println("Cadena nueva: " +s3);
//		m = lectura.charAt(0);
//		for(int i=0; i<l1; i++) {
//			if(lectura.charAt(i) == m) {
//			  s5 += Character.toUpperCase(m);
//			}
//			else {
//				s5 += lectura.charAt(i);
//			}
//		}
//		System.out.println("Cadena nueva: " +s5);	
		System.out.println("***" + lectura + "***");
		
		for(int k=l1-1; k>=0; k--) {
			s4 += lectura.charAt(k);
		}
		System.out.println("Cadena invertida: " + s4);
		
		//Palindromos
		for(int i=0, j=l1-1; i<l2 || j>l2; i++, j--) {
			s6 += lectura.charAt(i);
			s7 += lectura.charAt(j);
			if(s6.contentEquals(s7)) {
				res = true;
			}
			else {
				res = false;
			}
		}
		if(res) {
			System.out.println("Cadena palindromo");
		}
		else {
			System.out.println("No palindromo");
		}
		
		//Contar cuantas palabras hay sabiendo que estan separadas por un unico espacio en blanco y contar numero de espacios

		for(int i=0; i<l1; i++) {
			if(lectura.charAt(i) == ' ') {
			  cont2++;
			}
		}
		System.out.println("Numero de espacios: " + cont2);
		
		
		//Pedir una palabra y ver si esta o no en la cadena
		
		System.out.println("Introduzca palabra a buscar:");
		lectura2 = teclado.nextLine();
		
		for(int i=0; i<lectura.length(); i++) {

			if (lectura.charAt(i) != ' ') {
				s9 += lectura.charAt(i);
				espacio = false;
			}

			else if (!espacio) {
				espacio = true;
				if (s9.contentEquals(lectura2)) {
					contador++;
					// System.out.println("Esta la palabra");
				}
				s9 = "";
			}

		}
		System.out.println("Palabras: " + contador);
		
	
		
		teclado.close();
	}
	//metodo: dado una cadena de texto ver si el contenido tiene numeros enteros devolver true o false
}
