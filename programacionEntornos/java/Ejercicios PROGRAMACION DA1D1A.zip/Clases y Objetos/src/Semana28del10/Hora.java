package Semana28del10;

public class Hora {
	//hora minutos y segundos, validarhora, comparardoshoras, mayor menor o igual
	//, diferencia en segundos de dos horas, siguiente hora con suma de un segundo
	//, anterior hora con suma de un segundo
	private int seg;
	private int min;
	private int hora;
	
	public Hora(int hora, int min, int seg) {
		this.seg = seg;
		this.min = min;
		this.hora = hora;
	}

	public int getSeg() {
		return seg;
	}

	public void setSeg(int seg) {
		this.seg = seg;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getHora() {
		return hora;
	}

	public void setHora(int hora) {
		this.hora = hora;
	}
	
	public void validarHora() {
		int hora=0, min=0;
		
		if(this.seg >= 60) {
			min = this.min;
			this.min = seg/60 + min;
			this.seg = this.seg%60;
		}
		
		if(this.min >= 60) {
			hora = this.hora;
			this.hora = this.min/60 + hora;
			this.min = this.min%60;
		}
				
	}
	public int compararHoras(Hora h1) {
		int mayor = 1, menor = -1, igual = 0, error=2;
		if(h1 == null) {
			return error;
		}
		if(this.seg < h1.seg) {
			if(this.min < h1.min) {
				if(this.hora < h1.hora) {
					return menor;
				}
				else if(this.hora > h1.hora) {
					return mayor;
				}
				else {
					return menor;
				}
			}
			else if(this.min > h1.min) {
				if(this.hora < h1.hora) {
					return menor;
				}
				else if(this.hora > h1.hora) {
					return mayor;
				}
				else {
					return mayor;
				}
			}
			else if(this.min == h1.min) {
				if(this.hora < h1.hora) {
					return menor;
				}
				else if(this.hora > h1.hora) {
					return mayor;
				}
				else {
					return menor;
				}
			}
		}
		else if(this.seg > h1.seg) {
			if(this.min < h1.min) {
				if(this.hora < h1.hora) {
					return menor;
				}
				else if(this.hora > h1.hora) {
					return mayor;
				}
				else {
					return menor;
				}
			}
			else if(this.min > h1.min) {
				if(this.hora < h1.hora) {
					return menor;
				}
				else if(this.hora > h1.hora) {
					return mayor;
				}
				else {
					return mayor;
				}
			}
			else if(this.min == h1.min) {
				if(this.hora < h1.hora) {
					return menor;
				}
				else if(this.hora > h1.hora) {
					return mayor;
				}
				else {
					return mayor;
				}
			}
		}
		else if(this.seg == h1.seg) {
			if(this.min < h1.min) {
				if(this.hora < h1.hora) {
					return menor;
				}
				else if(this.hora > h1.hora) {
					return mayor;
				}
				else {
					return menor;
				}
			}
			else if(this.min > h1.min) {
				if(this.hora < h1.hora) {
					return menor;
				}
				else if(this.hora > h1.hora) {
					return mayor;
				}
				else {
					return mayor;
				}
			}
			else if(this.min == h1.min) {
				if(this.hora < h1.hora) {
					return menor;
				}
				else if(this.hora > h1.hora) {
					return mayor;
				}
				else {
					return igual;
				}
			}
		}
		return error;
	}
	public int diferenciaHoras(Hora h1) {
		int seg1=0, seg2=0, min1=0, min2=0,dif=0;
		min1 = this.min * 60;
		min2 = h1.min *60;
		seg1 = this.hora*3600 + min1 + this.seg;
		seg2 = h1.hora*3600 + min2 + h1.seg;
		if(this.compararHoras(h1) == 1) {
			dif = seg1 - seg2;
			return dif;
		}
		else if(this.compararHoras(h1) == -1) {
			dif = seg2 - seg1;
			return dif;
		}
		else if(this.compararHoras(h1) == 0) {
			dif = 0;
			return dif;
		}
		return dif;
	}
	
	public Hora siguienteHora() {
		Hora h1 = null;
		int hora=0, min=0, seg=0;
		if(this.seg >= 0 && this.seg <=58) {
			seg = this.seg;
			hora = this.hora;
			min = this.min;
			h1 = new Hora(hora, min, seg+1);
		}
		else if(this.seg == 59) {
			seg = this.seg;
			min = this.min;
			hora = this.hora;
			if(this.min >=0 && this.min <= 58) {
				h1 = new Hora(hora, min+1, 0);
			}
			
			else if(this.min == 59) {
				hora = this.hora;
				h1 = new Hora(hora+1, 0, 0);
			}
		}
		
		return h1;
	}
	
	public Hora anteriorHora() {
		Hora h1 = null;
		int hora=0, min=0, seg=0;
		if(this.seg >= 1 && this.seg <=59) {
			seg = this.seg;
			h1 = new Hora(this.hora, this.min, seg-1);
		}
		else if(this.seg == 0) {
			seg = this.seg;
			min = this.min;
			if(this.min >=1 && this.min <= 59) {
				h1 = new Hora(this.hora, min-1, 59);
			}
			
			else if(this.min == 0) {
				hora = this.hora;
				h1 = new Hora(hora-1, 59, 59);
			}
		}
		
		return h1;
	}
	
	public String toString() {
		return "Horas: " +this.hora+" Min: "+this.min+" Seg: "+ this.seg;
	}
}
