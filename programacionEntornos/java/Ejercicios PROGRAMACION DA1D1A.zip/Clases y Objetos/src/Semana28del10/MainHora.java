package Semana28del10;

import java.util.Scanner;

public class MainHora {

	public static void main(String[] args) {
		//hora minutos y segundos, validarhora, comparardoshoras, mayor menor o igual
		//, diferencia en segundos de dos horas, siguiente hora con suma de un segundo
		//, anterior hora con suma de un segundo
		int seg=0, hora=0, min = 0;
		int seg2=0, hora2=0, min2 = 0;
		Hora h3=null, h4=null, h5=null, h6=null;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduce una hora");
		hora = teclado.nextInt();
		System.out.println("Introduce unos minutos");
		min = teclado.nextInt();
		System.out.println("Introduce unos segundos");
		seg = teclado.nextInt();
		Hora h1 = new Hora(hora, min, seg);
		
		System.out.println("Introduce otra hora");
		hora2 = teclado.nextInt();
		System.out.println("Introduce otros minutos");
		min2 = teclado.nextInt();
		System.out.println("Introduce otros segundos");
		seg2 = teclado.nextInt();
		Hora h2 = new Hora(hora2, min2, seg2);
		
		System.out.println("Hora1 antes de validar: " + h1.toString());
		h1.validarHora();
		System.out.println("Hora1 tras validar: " + h1.toString() +"\n");
		
		System.out.println("Hora2 antes de validar: " + h2.toString());
		h2.validarHora();
		System.out.println("Hora2 tras validar: " + h2.toString()+"\n");
		
		if(h1.compararHoras(h2) == 1) {
			System.out.println("Hora1 mayor que hora2");
		}
		else if(h1.compararHoras(h2) == -1) {
			System.out.println("Hora1 menor que hora2");
		}
		else if(h1.compararHoras(h2) == 0) {
			System.out.println("Hora1 igual que hora2");
		}
		else {
			System.out.println("Error");
		}
		
		System.out.println("Diferencia horaria en segundos: " + h1.diferenciaHoras(h2)+ "\n");
		
		h3 = h1.siguienteHora();
		System.out.println("Hora1 m�s un segundo--> " + h3.toString());
		h4 = h2.siguienteHora();
		System.out.println("Hora2 m�s un segundo--> " + h4.toString());
		System.out.println();
		h5 = h1.anteriorHora();
		System.out.println("Hora1 menos un segundo--> " + h5.toString());
		h6 = h2.anteriorHora();
		System.out.println("Hora2 menos un segundo--> " + h6.toString());
		
		teclado.close();
	}

}
