package Semana28del10;

import java.util.Scanner;

public class EjemploString {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		char c;
		int longitud;
		String s1 = "hola";
		String s2 = new String("hola");
		String leer, leer2;
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s1 + " " +s2);
		c = 'x';
		c = s1.charAt(2);
		System.out.println("El caracter en la posicion 2 es: " + c);
		longitud = s1.length();
		c = s1.charAt(longitud-1);
		System.out.println("El ultimo caracter es: " +c);
		if(s1.compareTo(s2) == 0) {
			System.out.println("Son iguales");
		}
		else {
			System.out.println("Distintos");
		}
		leer = teclado.nextLine();
		System.out.println(leer); //probar con dos palabras
		leer2 = teclado.next();
		System.out.println(leer2); //probar con dos palabras para ver la diferencia con nextline
	}

}
