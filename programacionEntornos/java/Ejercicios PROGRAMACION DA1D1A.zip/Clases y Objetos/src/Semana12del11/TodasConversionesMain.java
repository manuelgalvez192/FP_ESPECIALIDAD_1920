package Semana12del11;

public class TodasConversionesMain {

	public static void main(String[] args) {
		//programa con todas las conversiones posibles
		

	}

}
