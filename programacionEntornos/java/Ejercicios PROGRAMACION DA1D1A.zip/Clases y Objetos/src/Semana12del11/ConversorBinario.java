package Semana12del11;

public class ConversorBinario {
	private String s;

	public ConversorBinario(String s) {
		this.s = s;
	}
	
	public int convertirAHex() {
		int suma=0, j=0, num=0;
		
		for(int k=this.s.length()-1; k>=0;k--) {
			if(this.s.charAt(k) == '0') {
				num = 0*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == '1') {
				num = 1*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == '2') {
				num = 2*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == '3') {
				num = 3*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == '4') {
				num = 4*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == '5') {
				num = 5*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == '6') {
				num = 6*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == '7') {
				num = 7*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == '8') {
				num = 8*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == '9') {
				num = 9*(int) Math.pow(16, j);
				suma += num; 
			}
			else if(this.s.charAt(k) == 'A') {
				num = 10*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == 'B') {
				num = 11*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == 'C') {
				num = 12*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == 'D') {
				num = 13*(int) Math.pow(16, j);
				suma += num; 
			}
			else if(this.s.charAt(k) == 'E') {
				num = 14*(int) Math.pow(16, j);
				suma += num;
			}
			else if(this.s.charAt(k) == 'F') {
				num = 15*(int) Math.pow(16, j);
				suma += num;
			}
			
			j++;
		}
		
		return suma;
	}
	/*public int convertirAHex() {
		String t = "";
		int suma=0, j=0, num=0;
		for(int k=0; k<this.s.length();k++) {
			if(this.s.charAt(k) == '0') {
				t += "0000"; 
			}
			else if(this.s.charAt(k) == '1') {
				t += "0001"; 
			}
			else if(this.s.charAt(k) == '2') {
				t += "0010"; 
			}
			else if(this.s.charAt(k) == '3') {
				t += "0011"; 
			}
			else if(this.s.charAt(k) == '4') {
				t += "0100"; 
			}
			else if(this.s.charAt(k) == '5') {
				t += "0101"; 
			}
			else if(this.s.charAt(k) == '6') {
				t += "0110"; 
			}
			else if(this.s.charAt(k) == '7') {
				t += "0111"; 
			}
			else if(this.s.charAt(k) == '8') {
				t += "1000"; 
			}
			else if(this.s.charAt(k) == '9') {
				t += "1001"; 
			}
			else if(this.s.charAt(k) == 'A') {
				t += "1010"; 
			}
			else if(this.s.charAt(k) == 'B') {
				t += "1011"; 
			}
			else if(this.s.charAt(k) == 'C') {
				t += "1100"; 
			}
			else if(this.s.charAt(k) == 'D') {
				t += "1101"; 
			}
			else if(this.s.charAt(k) == 'E') {
				t += "1110"; 
			}
			else if(this.s.charAt(k) == 'F') {
				t += "1111"; 
			}
			
		}
		
		for(int i=t.length()-1; i>=0;i--) {
			if(t.charAt(i) == '1') {
				num = (int) Math.pow(2, j);
				suma += num;
			}
			j++;
		}
		return suma;
	}*/
	
	public boolean validar() {
		boolean res = true;
		int i=0;
		while(i< this.s.length() && res) {
			if(this.s.charAt(i) >= '0' && this.s.charAt(i) <= '9') {
				res = true; 
			}
			else if(this.s.charAt(i) >= 'A' && this.s.charAt(i) <= 'F' ) {
				res = true;
			}
			else {
				res = false;
			}
			i++;
		}
		
		
		return res;
	}
}
