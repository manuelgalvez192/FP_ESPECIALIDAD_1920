package Semana12del11;

import java.util.Scanner;

public class ConversorBinarioMain {

	public static void main(String[] args) {
		// Convertir hex a decimal, validar si es hex o no
		String s = "";
		int suma = 0;
		boolean res = false;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introducir HEX: ");
		s = teclado.nextLine();
		ConversorBinario c = new ConversorBinario(s);
		
		res = c.validar();
		
		if(!res) {
			System.out.println("Cadena no valida");
		}
		else {
			System.out.println("Cadena valida");
			suma = c.convertirAHex();
			System.out.println("Suma: "+suma);
		}
		
		
		teclado.close();
	}

}
