package Semana22del10;

public class Profesor {
	
	public static void ponerNotas(Alumno a1) {
		double nota=0, nota2 = 0, nota3 = 0;
		nota = Math.random();
		nota2 = Math.random();
		nota3 = Math.random();
		a1.getAsig1().setCalif(nota);
		a1.getAsig2().setCalif(nota2);
		a1.getAsig3().setCalif(nota3);
	}
	public static double calcularMedia(Alumno a1) {
		double media=0, nota1=0, nota2=0, nota3=0;
		nota1 = a1.getAsig1().getCalif();
		nota2 = a1.getAsig2().getCalif();
		nota3 = a1.getAsig3().getCalif();
		media = nota1 + nota2 + nota3;
		media = media/3;
		return media;
	}
}
