package Semana22del10;

public class MainEscuela {

	public static void main(String[] args) {
		Asignatura a1 = new Asignatura(3);
		Asignatura a2 = new Asignatura(5);
		Asignatura a3 = new Asignatura(7);
		double media = 0;
		Alumno al1 = new Alumno(a1,a2,a3);
		
		Profesor.ponerNotas(al1);
		media = Profesor.calcularMedia(al1);
		System.out.println("Media: " + media*10);
	}

}
