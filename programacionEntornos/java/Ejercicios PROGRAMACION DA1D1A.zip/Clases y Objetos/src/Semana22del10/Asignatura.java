package Semana22del10;

public class Asignatura {
	private int id;
	private double calif;
	
	public Asignatura(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}
	public double getCalif() {
		return calif;
	}

	public void setCalif(double calif) {
		this.calif = calif;
	}
	
	
	
}
