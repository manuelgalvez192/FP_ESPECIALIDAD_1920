package Prueba29del10;

public class Hora {
	private int hora;
	private int min;
	private int seg;
	
	public Hora(int hora, int min, int seg) {
		this.hora = hora;
		this.min = min;
		this.seg = seg;
	}
	
	
	public int getHora() {
		return hora;
	}

	public void setHora(int hora) {
		this.hora = hora;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getSeg() {
		return seg;
	}

	public void setSeg(int seg) {
		this.seg = seg;
	}
	
	public boolean validarHora() {
		//int resultado = 0;
		boolean esValida;
		
		if(this.getHora() < 0 || this.getHora() > 24) {
			esValida = false;
			//resultado = 0;
		}
//		else {
//			esValida = true;
//			//resultado = 1;
//		}
		else if(this.getMin() < 0 || this.getMin()>60) {
			esValida = false;
			//resultado = 0;
		}
//		else {
//			esValida = true;
//			//resultado = 0;
//		}
		else if(this.getSeg() < 0 || this.getSeg()>60) {
			esValida = false;
			//resultado = 0;
		}
		else {
			esValida = true;
			//resultado = 1;
		}
		return esValida;
	}
	
	public void/*int*/ avanzarHora() {
		int segundos =0;
		int minutos = 0;
		int horas = 0;
		
		segundos = this.seg + 1;
		if(this.getSeg() == 60) {
			minutos = this.getMin() +1;
		}
		else {
			if(this.getSeg() > 60) {
				this.min++;
				this.seg = this.seg - this.getSeg();
			}
		}
		if(this.getMin() == 60) {
			horas = this.getHora()+1;
			minutos = 0;
		}
		else {
			if(this.getHora() > 24) {
				this.hora = 1;
			}
		}
	}
	
	public int diferenciaHoras(Hora h1) {
		int seg1=0, seg2=0, min1=0, min2=0,dif=0;
		min1 = this.min * 60 + this.seg;
		min2 = h1.min *60+ h1.seg;
		seg1 = this.hora*3600 + min1;
		seg2 = h1.hora*3600 + min2 ;
		
		dif = seg1 - seg2;
		if(dif < 0) {
			dif = dif *(-1);
		}
				
		return dif;
	}
	
	
	
	
	
	
	
}
