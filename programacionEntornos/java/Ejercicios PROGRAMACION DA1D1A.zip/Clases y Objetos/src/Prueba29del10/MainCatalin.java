package Prueba29del10;

import java.util.Scanner;

public class MainCatalin {

	public static void main(String[] args) {
		Hora h = null;
		Hora h2 = null;
		int opcion=0, hora,min,seg, dif=0;
		int hora2=0,min2=0,seg2=0;
		boolean res = false;
		Scanner teclado = new Scanner(System.in);
		while(opcion != 4) {
			System.out.println("Introduce una hora");
			hora = teclado.nextInt();
			System.out.println("Introduce unos minutos");
			min = teclado.nextInt();
			System.out.println("Introduce unos segundos");
			seg = teclado.nextInt();
			h = new Hora(hora, min, seg);
			
			System.out.println("1. ValidarHora");
			System.out.println("2. Diferencia en segundos");
			System.out.println("3. Hora siguiente");
			System.out.println("4. Salir");
			opcion = teclado.nextInt();
			switch(opcion) {
			case 1:
				res = h.validarHora();
				System.out.println("Res: " + res);
				break;
			case 2:
				System.out.println("Introduce una hora");
				hora2 = teclado.nextInt();
				System.out.println("Introduce unos minutos");
				min2 = teclado.nextInt();
				System.out.println("Introduce unos segundos");
				seg2 = teclado.nextInt();
				h2 = new Hora(hora2, min2, seg2);
				dif = h.diferenciaHoras(h2);
				System.out.println("Diferencia: " +dif);
				break;
			case 3: 
				h.avanzarHora();
				System.out.println("Hora: " + h.getHora() + "Min: " + h.getMin() + "Seg: " + h.getSeg());
				break;
			case 4:
				System.out.println("Salir");
				break;
			default:
				System.out.println("Opcion err�nea");
			}
		}
		
		

	}

}
