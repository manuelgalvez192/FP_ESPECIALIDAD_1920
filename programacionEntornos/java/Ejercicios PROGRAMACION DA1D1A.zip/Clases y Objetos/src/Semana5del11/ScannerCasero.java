package Semana5del11;

public class ScannerCasero {
	private String s;
	private int longitud = 0;
	private int pos = 0;
	private int posanterior=0; //Comienzo de un numero

	public ScannerCasero(String s) {
		this.s = s;
		this.longitud = this.s.length()-1;
	}
	
	public boolean hayMasNumeros() {
		boolean res=true;
		if(this.posanterior != this.longitud) {
			res = false;
		}
		return res;
	}
	
	public int siguienteNumero() {
		int n=0;
		String cadena = ""; //Numeros a devolver en forma de cadena
		
		this.pos = this.s.indexOf(':', this.posanterior);
		if(this.pos == -1) {
			cadena = this.s.substring(this.posanterior);
			n = Integer.parseInt(cadena);
		}
		else {
			cadena = this.s.substring(this.posanterior, this.pos);
			n = Integer.parseInt(cadena);
			this.posanterior = this.pos+1;
		}
		
	
		return n;
	}
}
