package Semana5del11;

public class ScannerCaseroMain {

	public static void main(String[] args) {
		ScannerCasero scc = new ScannerCasero("34:56:11:546:1");
		while (!scc.hayMasNumeros()) {
			System.out.println(scc.siguienteNumero());
		}

	}
	

}
