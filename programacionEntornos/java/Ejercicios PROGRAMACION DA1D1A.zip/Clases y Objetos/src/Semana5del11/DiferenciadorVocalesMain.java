package Semana5del11;

import java.util.Scanner;

public class DiferenciadorVocalesMain {

	public static void main(String[] args) {
		//Dada una palabra que devuelva el numero de vocales distintas en la misma palabra(Ej: patata-> 1, cosa->2)
		String palabra = "";
		String palabra2 = "";
		String vocales = "AEIOU";
		int num=0;
		boolean letraA = false, letraE= false, letraI= false, letraO=false, letraU=false;
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca palabra: ");
		palabra2 = teclado.nextLine();
		palabra = palabra2.toUpperCase();
//		DiferenciadorVocales dv= new DiferenciadorVocales(palabra);
//		num = dv.diferenciar();
//		System.out.println("Numero de vocales: "+num);
		for(int i=0; i<palabra.length();i++) {
			if((!letraA)&&(palabra.charAt(i) == 'A')) {
				letraA = true;
				num++;
			}
			else if((!letraE)&&(palabra.charAt(i) == 'E')) {
				letraE = true;
				num++;
			}
			else if((!letraI)&&(palabra.charAt(i) == 'I')) {
				letraI = true;
				num++;
			}
			else if((!letraO)&&(palabra.charAt(i) == 'O')) {
				letraO = true;
				num++;
			}
			else if((!letraU)&&(palabra.charAt(i) == 'U')) {
				letraU = true;
				num++;
			}
		}
		System.out.println("Contador: "+num);
	}

}
