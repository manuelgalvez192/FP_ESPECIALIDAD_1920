package Semana5del11;

public class Stringclass {
	
	public boolean tieneEntero(String s) {
		boolean res = true;
		int i=1;
		if(s.charAt(0) == '-' || s.charAt(0) >= '0' && s.charAt(0) <= '9') {
			while(i<s.length()-1 && res) {
				if(s.charAt(i) >= '0' && s.charAt(i) <= '9') {
					res = true;
				}
				else {
					res = false;
				}
				i++;
			}
		}
		else {
			res = false;
		}
		return res;
	}
	public double convertirTexto(String s) {
		double num=0;
		
		num = Double.parseDouble(s);
		
		return num;
	}
	
	public String convertirNumero(double num) {
		String res = "";
		
		res = Double.toString(num);
		
		return res;
	}
	/*public boolean validarDNI(String s) {
		boolean res = false;
		int i =0;
		int dni = 0;
		int resto = 0;
		String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
		
		if(s.length() == 9) {
			while((i<s.length()-1) && (res)) {
				if(s.charAt(i)<'0' || s.charAt(i)>'9') {
					res = false;
				}
				
				i++;
			}
		}
		if(res) {
			dni = Integer.parseInt(s.substring(0, 8));
			resto = dni % 23;
			if(s.charAt(s.length()-1) != letras.charAt(resto)) {
				res = false;
			}
		}
		return res;
	}*/
	public boolean validarDNI(String s) {
		
		String mayus = "";
		
		if(s.length()!=9 || Character.isLetter(s.charAt(8)) == false) {
			return false;
		}
		mayus = s.substring(8).toUpperCase();
		if(soloNumeros(s) == true && letraDNI(s).equals(mayus)) {
			return true;
		}
		else {
			return false;
		}
		
		
	}
	public boolean soloNumeros(String s) {
		int i, j=0;
		String numero = "";
		String DNI = "";
		String[] unoNueve = {"0","1","2","3","4","5","6","7","8","9"};
		
		for(i = 0;i < s.length()-1; i++) {
			numero = s.substring(i, i+1);
			for(j=0; j<unoNueve.length;j++) {
				if(numero.equals(unoNueve[j])) {
					DNI += unoNueve[j];
				}
			}
		}
		if(DNI.length() != 8) {
			return false;
		}
		else {
			return true;
		}
	}
	public String letraDNI(String s) {
		int dni = Integer.parseInt(s.substring(0, 8));
		int resto = 0;
		String letra = "";
		String[] asigletra = {"T","R","W","A","G","M","Y","F","P","D","X","B","N","J","Z","S","Q","V","H","L","C","K","E"};
		resto = dni % 23;
		letra = asigletra[resto];
		return letra;
	}
}
