package Semana5del11;

import java.util.Scanner;

public class CodificadorMain {

	public static void main(String[] args) {
		//Codificar y decodificar un mensaje mediante la codificacion Cesar
		//(desplazar tres caracteres a la derecha cada letra del mensaje)
		
		String s = "";
		String s2;
		String s3;
		String codificado = "";
		String decodificado = "";
		char cod = 0;
		Scanner teclado = new Scanner(System.in);
			
		System.out.println("Introduzca frase: ");
		s = teclado.nextLine();
		//Codificador c = new Codificador(s);
		
		for(int i=0; i<s.length();i++) {
			if(s.charAt(i) >= 'A' && s.charAt(i) <= 'W') {
				cod = s.charAt(i);
				cod+=3;
			}
			else {
				if(s.charAt(i) == 'X') {
					cod = 'A';
				}
				else {
					if(s.charAt(i) == 'Y') {
						cod = 'B';
					}
					else {
						if(s.charAt(i) == 'Z') {
							cod = 'C';
						}
						else {
							cod = s.charAt(i);
						}
					}
				}
			}
			codificado += cod;
		}
		
		System.out.println(codificado);
		
		// Falta decodificar
		
		
		
		
		
		/*s2 = c.codificarMensaje();
		System.out.println(s2);
		
		s3 = c.decodificarMensaje();
		System.out.println(s3);*/
		
		
	}

}
