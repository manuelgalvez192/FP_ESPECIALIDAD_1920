package Semana5del11;

public class DiferenciadorVocales {
	private String s;

	public DiferenciadorVocales(String s) {
		this.s = s;
	}
	
	public int diferenciar() {
		int num = 0;
		//char vocal;
		
		for(int i=0; i<this.s.length();i++) {
			if(this.s.charAt(i) == 'a') {
				num++;
			}
			else if(this.s.charAt(i) == 'e') {
				num++;
			}
			else if(this.s.charAt(i) == 'i') {
				num++;
			}
			else if(this.s.charAt(i) == 'o') {
				num++;
			}
			else if(this.s.charAt(i) == 'u') {
				num++;
			}
		}
		
		
		return num;
	}
}
