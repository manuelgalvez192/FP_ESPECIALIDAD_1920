package Semana5del11;

import java.util.Scanner;

public class StringClassMain {

	public static void main(String[] args) {
		String s10 = "";
		String s1 = "12.56";
		String s2 = "";
		String DNI = "";
		double num = 23.56;
		Stringclass metodo= new Stringclass();
		boolean res2 = false, res = false;
		Scanner teclado = new Scanner(System.in);
		
		/*System.out.println("Introduzca nueva cadena: ");
		s10 = teclado.nextLine();
		
		res2 = metodo.tieneEntero(s10);
		if(res2) {
			System.out.println("Cadena de enteros");
		}
		else {
			System.out.println("Cadena no compatible");
		}*/
		
		metodo.convertirTexto(s1);
		System.out.println("Valor: "+ s1);
		
		s2 = metodo.convertirNumero(num);
		System.out.println("String: " + s2);
		
		System.out.println("Introduzca DNI: ");
		DNI = teclado.nextLine();
		
		res = metodo.validarDNI(DNI);
		if(res) {
			System.out.println("DNI correcto");
		}
		else {
			System.out.println("DNI incorrecto");
		}
		
		
		teclado.close();
	}
	//convertir cadena de texto a numero, convertir numero a tipo String, comprobar si DNI correcto o no
}
