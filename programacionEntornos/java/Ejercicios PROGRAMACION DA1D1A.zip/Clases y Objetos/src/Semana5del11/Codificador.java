package Semana5del11;

public class Codificador {
	//Codificar y decodificar un mensaje mediante la codificacion Cesar
	//(desplazar tres caracteres a la derecha cada letra del mensaje)
	private String s;

	public Codificador(String s) {
		this.s = s;
	}
	
	
	/*public String codificarMensaje() {
		String st = new String(); //Cadena a devolver 
		String sr = new String(); //Cadena usada de convertor a String
		
		for(int i=0; i<this.s.length(); i++) {
			if(this.s.charAt(i) == 'x') {
				st += 'a'; 
			}
			else if(this.s.charAt(i) == 'y') {
				st += 'b';
			}
			else if(this.s.charAt(i) == 'z') {
				st += 'c';
			}
			else{
				st = Integer.toString(this.s.charAt(i)+3);
				st += sr;
			}
			
		}
		return st;
	}
	
	public String decodificarMensaje() {
		String sn = new String(); //Cadena a devolver 
		String sm = new String(); //Cadena usada de convertor a String
		
		for(int i=0; i<this.s.length(); i++) {
			sm = Integer.toString(this.s.charAt(i)-3);
			sn += sm;
		}
		return sn;
	}*/
}
