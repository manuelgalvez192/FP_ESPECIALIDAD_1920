package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		double cateto1 = 0, cateto2 = 0;
		double hipotenusa = 0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca cateto 1: ");
		cateto1 = teclado.nextDouble();
		System.out.println("Introduzca cateto 2: ");
		cateto2 = teclado.nextDouble();
		
		cateto1 *= cateto1;
		cateto2 *= cateto2;
		
		hipotenusa = Math.sqrt(cateto1 + cateto2);
		System.out.println("Hipotenusa: " + hipotenusa);
		teclado.close();
	}

}
