package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio8 {

	public static void main(String[] args) {
		int min = 0,cont = 3;
		int precio = 0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Minutos consumidos: ");
		min = teclado.nextInt();
		
		if(min <= 3) {
			precio = 10;
		}
		if(min > 3) {
			precio = 10;
			while(cont != min) {
				cont++;
				precio+=5;
			}
			
		}
		System.out.println("Precio: " + precio + " pts");
		
		
		
		teclado.close();

	}

}
