package EjerciciosAulaVirtual;

public class Ejercicio19 {

	public static void main(String[] args) {
		int num=100,cuadrado=1;
		
		for(int i=1; i <= num; i++) {
			cuadrado = i*i;
			System.out.println("Cuadrado de "+i+ " es: " + cuadrado);
		}

	}

}
