package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		int hamb=0,cerveza=0,cocacola=0,ensalada=0,salchichas=0,refrescos=0,sopa=0,pastel=0;
		final double IMPUESTO = 0.12;
		double ventas=0;
		int opcion=0;
		Scanner teclado = new Scanner(System.in);
		
		while(opcion != 9) {
			System.out.println("1. Hamburguesas");
			System.out.println("2. Cerveza");
			System.out.println("3. Cocacola");
			System.out.println("4. Ensalada");
			System.out.println("5. Salchichas");
			System.out.println("6. Refrescos");
			System.out.println("7. Sopa");
			System.out.println("8. Pastel");
			System.out.println("9. Salir");
			opcion = teclado.nextInt();
			
			switch(opcion) {
				case 1:
					System.out.println("Introduzca el n�mero de hamburguesas");
					hamb = teclado.nextInt();
					hamb = hamb * 500;
					ventas+=hamb;
					break;
				case 2:
					System.out.println("Introduzca el n�mero de cervezas");
					cerveza = teclado.nextInt();
					cerveza = cerveza * 150;
					ventas+=cerveza;
					break;
				case 3:
					System.out.println("Introduzca el n�mero de coca-colas");
					cocacola = teclado.nextInt();
					cocacola = cocacola * 175;
					ventas+=cocacola;
					break;
				case 4: 
					System.out.println("Introduzca el n�mero de ensaladas");
					ensalada = teclado.nextInt();
					ensalada = ensalada * 200;
					ventas+=ensalada;
					break;
				case 5:
					System.out.println("Introduzca el n�mero de salchichas");
					salchichas = teclado.nextInt();
					salchichas = salchichas * 275;
					ventas+= salchichas;
					break;
				case 6:
					System.out.println("Introduzca el n�mero de refrescos");
					refrescos = teclado.nextInt();
					refrescos = refrescos * 200;
					ventas+=refrescos;
					break;
				case 7:
					System.out.println("Introduzca el n�mero de sopas");
					sopa = teclado.nextInt();
					sopa*=260;
					ventas+=sopa;
					break;
				case 8: 
					System.out.println("Introduzca el n�mero de pasteles");
					pastel = teclado.nextInt();
					pastel*=300;
					ventas+=pastel;
					break;					
				case 9:
					System.out.println("Hasta luego\n");
					break;
				default:
					System.out.println("Opcion err�nea");
				
				
				
				
			}
		}
		System.out.println("Ventas totales: " + ventas +" pts");
		System.out.println("Impuestos totales: " + ventas*IMPUESTO +" pts");
		teclado.close();
	}

}
