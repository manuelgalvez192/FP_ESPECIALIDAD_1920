package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio33 {

	public static void main(String[] args) {
		// Cuadrados de numero por teclado hasta que metan 0 y contador
		int num=1, cont=0;
		double cuadrado=0;
		Scanner teclado = new Scanner(System.in);
		while(num !=0) {
			System.out.println("Introduzca numero: ");
			num = teclado.nextInt();
			cuadrado = num * num;
			System.out.println("Cuadrado del numero: " + cuadrado);
			cont++;
		}
		System.out.println("Contador de numeros: " + cont);
		teclado.close();
		

	}

}
