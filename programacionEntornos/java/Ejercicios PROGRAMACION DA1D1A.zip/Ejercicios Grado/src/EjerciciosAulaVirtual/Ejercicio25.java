package EjerciciosAulaVirtual;

public class Ejercicio25 {

	public static void main(String[] args) {
		// 30 primeras potencias de 4
		int num=4;
		double potencia=1;
		
		for(int i=1; i<=30; i++) {
			potencia *= num;
			System.out.println("Potencias: " + potencia);
		}

	}

}
