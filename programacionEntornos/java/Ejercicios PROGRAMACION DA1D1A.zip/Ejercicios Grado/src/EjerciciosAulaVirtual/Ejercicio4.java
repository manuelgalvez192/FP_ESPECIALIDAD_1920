package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) {
		double chelines=0, dracmas=0, dolares=0, liras=0, francos=0;
		double pesetas=0;
		int opcion=0, opcion2=0;
		
		Scanner teclado = new Scanner(System.in);
			
		while(opcion != 4) {
			System.out.println("1. Chelines");
			System.out.println("2. Dracmas");
			System.out.println("3. Pesetas");
			System.out.println("4. Salir");
			opcion = teclado.nextInt();
			switch(opcion) {
			case 1: 
				System.out.println("Introduzca cantidad de chelines: ");
				chelines = teclado.nextDouble();
				pesetas = chelines * 9.56871;
				System.out.println("Pesetas: " + pesetas);
				break;
			
			case 2: 
				System.out.println("Introduzca cantidad de dracmas: ");
				dracmas = teclado.nextDouble();
				pesetas = dracmas * 0.88607;
				francos = pesetas * 1/20.110;
				System.out.println("Francos: " + francos);
				break;
				
			case 3:
				opcion2 = 0;
				while(opcion2 != 3) {
					System.out.println("1. Dolares");
					System.out.println("2. Liras");
					System.out.println("3. Salir");
					opcion2 = teclado.nextInt();
					switch(opcion2) {
						case 1: 
							System.out.println("Introduzca cantidad de pesetas: ");
							pesetas = teclado.nextDouble();
							dolares = pesetas * 1 / 122.499;
							System.out.println("Dolares: " + dolares);
							break;
						case 2:
							System.out.println("Introduzca cantidad de pesetas: ");
							pesetas = teclado.nextDouble();
							liras = pesetas * 1 / 0.09289;
							System.out.println("Liras: " + liras);
							break;
						case 3: 
							System.out.println("Vuelva a elegir del primer men� \n");
							break;
						default:
							System.out.println("Has elegido mal");
						}
				
				}
				break;
			case 4:
				System.out.println("Hasta luego");
				break;
			default:
				System.out.println("Has elegido mal");
			}
		}
		teclado.close();
	}
			
			
		
		
	}

