package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio9 {

	public static void main(String[] args) {
		int articulo = 0;
		final double IVA = 0.12;
		double precio = 0, precioarticulo=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca el numero de productos: ");
		articulo = teclado.nextInt();
		System.out.println("Introduzca el precio del articulo: ");
		precioarticulo = teclado.nextDouble();
		
		
		precio = articulo * precioarticulo; 
		if(precio > 50000) {
			precio = precio * 0.95;
		}
		precio = precio + (precio * IVA); 
		
		System.out.println("Precio: " +precio);
		
		teclado.close();

	}

}
