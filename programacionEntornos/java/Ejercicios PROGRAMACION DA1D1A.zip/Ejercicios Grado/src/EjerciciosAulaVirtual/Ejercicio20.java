package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio20 {

	public static void main(String[] args) {
		int num=0, mult=0, cont=0;
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();
		
		for(int i=1; cont<=num; i++) {
			if(i % 4 == 0) {
				mult = i;
				System.out.println("Multiplos: " + mult);
				cont++;
			}
		}
		teclado.close();
	}

}
