package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio7 {

	public static void main(String[] args) {
		double km = 0, millasm = 0, millast=0;
		final double MILLAS_MARINAS = 1.852;
		final double MILLAS_TERRESTRES = 1.609;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca kilometros a convertir");
		km = teclado.nextDouble();
		
		millasm = km * MILLAS_MARINAS;
		millast = km * MILLAS_TERRESTRES;
		
		System.out.println("Millas marinas: " + millasm);
		System.out.println("Millas terrestres: " + millast);
		teclado.close();
	}

}
