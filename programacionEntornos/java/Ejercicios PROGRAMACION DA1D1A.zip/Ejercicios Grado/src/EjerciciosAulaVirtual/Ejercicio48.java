package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio48 {

	public static void main(String[] args) {
		// Turnos calcular salario
		final int DIAS = 5, TURNO = 8;
		int opcion=0, salario=0;
		Scanner teclado = new Scanner(System.in);
		
		while(opcion != 4) {
			System.out.println("1. Turno de Ma�ana");
			System.out.println("2. Turno de Tarde");
			System.out.println("3. Turno de Noche");
			System.out.println("4. Salir");
			opcion = teclado.nextInt();
			
			switch(opcion) {
			
			case 1:
				System.out.println("Ha elegido turno de ma�ana");
				salario = (TURNO * 600) * DIAS;
				System.out.println("Su salario es: " +salario+"\n");
				break;
			case 2:
				System.out.println("Ha elegido turno de tarde");
				salario = (TURNO * 800) * DIAS;
				System.out.println("Su salario es: " +salario +"\n");
				break;
			case 3:
				System.out.println("Ha elegido turno de noche");
				salario = (TURNO * 1000) * DIAS;
				System.out.println("Su salario es: " +salario+"\n");
				break;
			case 4:
				System.out.println("Hasta luego");
				break;
			default:
				System.out.println("Opcion erronea");
			}
		}
		teclado.close();
	}

}
