package EjerciciosAulaVirtual;

public class Ejercicio39 {

	public static void main(String[] args) {
		// Suma multiples 5 entre 1-100
		int suma=0, cont=0;
		
		for(int i=1; i<=100; i++) {
			if(i%5 == 0) {
				suma += i;
				cont++;
				System.out.println("Multiplos: " + i);
			}
		}
		System.out.print("Contador: " +cont);
		System.out.print(" Suma: " +suma);
	}

}
