package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio46 {

	public static void main(String[] args) {
		// Realizar un programa Java que permita introducir un n�mero desde teclado y decir si es positivo,negativo o nulo.
		int num=0;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introducir numero: ");
		num = teclado.nextInt();
		if(num == 0) {
			System.out.println("El numero es nulo");
		}
		else if(num > 0) {
			System.out.println("El numero es positivo");
		}
		else {
			System.out.println("El numero es negativo");
		}
		
		teclado.close();
	}

}
