package EjerciciosAulaVirtual;

import java.util.Scanner;

public class Ejercicio10 {

	public static void main(String[] args) {
		int a=0,b=0,c=0, raiz=0;
		int x=0,y=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca a: ");
		a = teclado.nextInt();
		System.out.println("Introduzca b: ");
		b = teclado.nextInt();
		System.out.println("Introduzca c: ");
		c = teclado.nextInt();
		
		
		raiz = (int) Math.sqrt((b*b) - 4 * a * c);
		
		x = (-b + raiz)/2*a;
		y = (-b - raiz)/2*a;
		
		System.out.println("Los valores de la ecuacion son:" + x + " " + y);
		teclado.close();
	}

}
