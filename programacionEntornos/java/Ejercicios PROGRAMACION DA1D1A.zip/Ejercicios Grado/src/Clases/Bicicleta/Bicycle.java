package Clases.Bicicleta;

public class Bicycle {

    private int cadence;
    private int speed;
    private int gear;
    
    public Bicycle(int startCadence, int startSpeed, int startGear) {
        gear = startGear;
        cadence = startCadence;
        speed = startSpeed;
    }
    
    public Bicycle() {
        gear = 1;
        cadence = 0;
        speed = 0;
    }
    
    public int getCadence() {
		return cadence;
	}


	public void setCadence(int cadence) {
		this.cadence = cadence;
	}


	public int getSpeed() {
		return speed;
	}


	public void setSpeed(int speed) {
		this.speed = speed;
	}


	public int getGear() {
		return gear;
	}


	public void setGear(int gear) {
		this.gear = gear;
	}


	void changeCadence(int newValue) {
         cadence = newValue;
    }

    void changeGear(int newValue) {
         if(newValue < 1) {
        	 gear = 1;
         }
         else if(newValue > 6) {
        	 gear = 6;
         }
         else {
        	 gear = newValue;
         }
         
    }

    void speedUp(int increment) {
    	if(increment < 0) {
    		speed = 0;
    	}
    	else {
    		speed = speed + increment;
    	}
            
    }

    void applyBrakes(int decrement) {
    
		speed = speed - decrement;
		if (speed < 0) {
			speed = 0;
		}
         
    }

    void printStates() {
         System.out.println("cadence:" +
             cadence + " speed:" + 
             speed + " gear:" + gear);
    }
}
