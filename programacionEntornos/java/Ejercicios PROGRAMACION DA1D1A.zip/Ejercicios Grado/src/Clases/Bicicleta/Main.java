package Clases.Bicicleta;

public class Main {

	public static void main(String[] args) {
		 // Create two different 
        // Bicycle objects
        Bicycle bike1 = new Bicycle(4,5,6);
        Bicycle bike2 = new Bicycle();
//        Bicycle bike3 = new Bicycle(3,4,2);
//        Bicycle bike4 = new Bicycle(1,30,4);
//        Bicycle bike5 = new Bicycle(30,30,3);
//        Bicycle bike6 = new Bicycle(34,4,2);
//        Bicycle bike7 = new Bicycle(2,3,4);
                
        // Invoke methods on 
        // those objects
        bike1.changeCadence(50);
        bike1.speedUp(10);
        bike1.changeGear(2);
        bike1.printStates();

        bike2.changeCadence(50);
        bike2.speedUp(10);
        bike2.changeGear(2);
        bike2.changeCadence(40);
        bike2.speedUp(10);
        bike2.changeGear(3);
        bike2.printStates();
//        
//        bike3.changeCadence(80);
//        bike3.speedUp(10);
//        bike3.changeGear(5);
//        bike3.applyBrakes(30);
//        bike3.printStates();
//        
//        bike4.changeCadence(50);
//        bike4.speedUp(10);
//        bike4.changeGear(2);
//        bike4.printStates();
//        
//        bike5.changeCadence(20);
//        bike5.speedUp(-10);
//        bike5.changeGear(5);
//        bike5.printStates();
//        
//        bike6.changeCadence(50);
//        bike6.speedUp(10);
//        bike6.changeGear(0);
//        bike6.printStates();
//       
//        bike7.changeCadence(40);
//        bike7.speedUp(50);
//        bike7.changeGear(8);
//        bike7.printStates();
        
        
	}

}
