package Ejercicios2;

import java.util.Scanner;

public class DoWhileFactorial {

	public static void main(String[] args) {
		int num=1,resultado=1;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca n�mero");
		num = teclado.nextInt();
		while(num <=0) {
			System.out.println("Introduzca n�mero mayor que 0");
			num = teclado.nextInt();
		}
		
		do{
			resultado *= num;
			num--;
		}while(num > 1);
		System.out.println("Factorial total: " + resultado);
		
		teclado.close();

	}

}
