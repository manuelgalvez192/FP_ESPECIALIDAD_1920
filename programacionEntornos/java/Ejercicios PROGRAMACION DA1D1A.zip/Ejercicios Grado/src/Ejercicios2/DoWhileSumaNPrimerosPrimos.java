package Ejercicios2;

import java.util.Scanner;

public class DoWhileSumaNPrimerosPrimos {

	public static void main(String[] args) {
		int num=2, div=2, suma=0, contador_primo=1, cantidad_primo=0;
		int primo = 1;
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		cantidad_primo = teclado.nextInt();
		
		do{
			div=2;
			primo=1;
			while(div < num && primo == 1){
				if(num % div == 0) {
					primo = 0;
				}
				div++;
			}
			
			if(primo == 1) {
				suma+=num;
				contador_primo++;
			}
			num++;
			
			teclado.close();
			
			
		}while(contador_primo <= cantidad_primo);
		
		System.out.println("Suma: " + suma);

	}

}
