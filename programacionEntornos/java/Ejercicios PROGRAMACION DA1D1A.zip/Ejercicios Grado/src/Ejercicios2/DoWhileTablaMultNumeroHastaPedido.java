package Ejercicios2;

import java.util.Scanner;

public class DoWhileTablaMultNumeroHastaPedido {

	public static void main(String[] args) {
		int i=1, cont=1, num=0, res=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un n�mero: ");
		num = teclado.nextInt();
		//while(num!=10){ Para el ejercicio que pide mientras que no sea 10
				do{
					do{
						res = i*cont;
						System.out.println("Resultado: " + res);
						i++;
					}while(i<=10);
					System.out.println("\n");
					i=1;
					cont++;
				}while(cont<=num); 
				//}
				teclado.close();

	}

}
