package Ejercicios2;

import java.util.Scanner;

public class DoWhileElevado {

	public static void main(String[] args) {
		int num=0, num2=0, cont=0,res=1;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca n�mero 1: ");
		num = teclado.nextInt();
		
		System.out.println("Introduzca n�mero 2: ");
		num2 = teclado.nextInt();
		
		do{
			res *= num;
			cont++;
		}while(cont != num2);
		System.out.println("Resultado: " + res);
		
		teclado.close();

	}

}
