package Ejercicios2;

import java.util.Scanner;

public class DoWhileTablaMult1Numero {

	public static void main(String[] args) {
		int i=1, num=0, res=0;
		
		Scanner teclado = new Scanner(System.in);
		
		
			System.out.println("Introduzca un n�mero: ");
			num = teclado.nextInt();
			do{
				res = i*num;
				System.out.println("Resultado: " + res);
				i++;
			}while(i<=10); 
		
		teclado.close();

	}

}
