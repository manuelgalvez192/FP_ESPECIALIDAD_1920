package Ejercicios2;

import java.util.Scanner;

public class DoWhileSacarNumerosUnoxUnoHastaPedido {

	public static void main(String[] args) {
		int cont=1, num=0, i=1;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();
		
		do{
			do{
				System.out.println(i);
				i++;
			}while(i<=cont);
			i=1;
			cont++;
			System.out.println("\t");
			
		}while(cont<=num); 
		teclado.close();
	}

}
