package Ejercicios2;

import java.util.Scanner;

public class DoWhileMeterMasNumeros {

	public static void main(String[] args) {
		int res=1;
		int num=0, suma=0;
		
		Scanner teclado = new Scanner(System.in);

		do{
			
			System.out.println("Introduzca n�mero");
			num = teclado.nextInt();
			
			suma+=num;
			System.out.println("�Quiere seguir?(0 salir/1 seguir)");
			res = teclado.nextInt();
			
		}while(res!=0);
		
		System.out.println("Resultado suma: " + suma);
		teclado.close();

	}

}
