package Ejercicios2;

public class DoWhileVerSiPrimoEntre2y100 {

	public static void main(String[] args) {
		int num=0, cont=0;
		boolean primo = true;
		num = 2;
		do{
			
			cont = 2;
			while(cont < num) {
				if(num % cont == 0) {
					primo = false;
				}
				cont++;
			}
			if(primo) {
				System.out.println("Primo: " +  num);
			}
			num++;
			primo = true;
		}while(num <= 100); 

	}

}
