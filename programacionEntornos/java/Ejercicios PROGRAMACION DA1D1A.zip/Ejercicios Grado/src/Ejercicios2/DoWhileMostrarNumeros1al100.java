package Ejercicios2;

public class DoWhileMostrarNumeros1al100 {

	public static void main(String[] args) {
		int numero=100;
		do {
			System.out.println(numero);
			numero--;
		}while(numero>0);
	}

}
