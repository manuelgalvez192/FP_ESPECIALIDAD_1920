package Ejercicios2;

public class DoWhileSuma100Naturales {

	public static void main(String[] args) {
		int numero=1, resultado=0;
		
		do {
			resultado+=numero;
			numero++;
		}while(numero<=100);
		
		System.out.println(resultado);

	}

}
