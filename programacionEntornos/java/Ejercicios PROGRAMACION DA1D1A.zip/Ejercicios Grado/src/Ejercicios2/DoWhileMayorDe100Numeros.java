package Ejercicios2;

import java.util.Scanner;

public class DoWhileMayorDe100Numeros {

	public static void main(String[] args) {
		int num=0, cont=1, mayor=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un n�mero: ");
		num = teclado.nextInt();
		
		mayor = num;
		do{
			System.out.println("Introduzca un nuevo n�mero: ");
			num = teclado.nextInt();
			if(num > mayor) {
				mayor = num;
			}
			cont++;
		}while(cont!=99); 
		System.out.println("Mayor: " + mayor);
		teclado.close();

	}

}
