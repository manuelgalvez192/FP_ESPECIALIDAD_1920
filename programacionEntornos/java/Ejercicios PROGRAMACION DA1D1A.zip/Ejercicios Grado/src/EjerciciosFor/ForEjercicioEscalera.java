package EjerciciosFor;

import java.util.Scanner;

public class ForEjercicioEscalera {

	public static void main(String[] args) {
		Scanner teclado=new Scanner(System.in);
		int num=0,i=1;
		System.out.println("Introduzca un numero");
		num=teclado.nextInt();
	
		for(int cont=1;cont<=num;cont++) {
			i=1;
			while(i<=cont) {
				System.out.print(i + " ");
				i++;
			}	
			System.out.println();
		}
		teclado.close();

	}

}
