package EjerciciosFor;

public class ForVerSiPrimoEntre2y100 {

	public static void main(String[] args) {
		int cont=0;
		boolean primo = true;
		
		for(int num=2;num<=100;num++){
			cont = 2;
			while(cont < num) {
				if(num % cont == 0) {
					primo = false;
				}
				cont++;
			}
			if(primo) {
				System.out.println("Primo: " +  num);
			}
			
			primo = true;
		} 


	}

}
