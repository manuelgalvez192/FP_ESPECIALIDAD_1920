package EjerciciosFor;

import java.util.Scanner;

public class ForTablaMult1Numero {

	public static void main(String[] args) {
		int num = 0, res = 0;

		Scanner teclado = new Scanner(System.in);

		System.out.println("Introduzca un n�mero: ");
		num = teclado.nextInt();
		
		for(int i=1;i<=10;i++) {
			res = i * num;
			System.out.println("Resultado: " + res);
		}

		teclado.close();
	}

}
