package EjerciciosFor;

import java.util.Scanner;

public class ForEjercicioAsteriscos {

	public static void main(String[] args) {
		int num=0;
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca numero");
		num = teclado.nextInt();
		
		for(int i=1;i<=num;i++) {
			for(int j=1; j<=i; j++) {
				System.out.print(j);
			}
			for(int k=num; k>i;k--) {
				System.out.print("*");
				
			}
			System.out.println();
		}
		teclado.close();
	}

}
