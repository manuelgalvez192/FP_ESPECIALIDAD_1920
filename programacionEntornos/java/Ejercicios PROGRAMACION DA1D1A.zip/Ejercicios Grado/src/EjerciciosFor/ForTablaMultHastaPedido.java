package EjerciciosFor;

import java.util.Scanner;

public class ForTablaMultHastaPedido {

	public static void main(String[] args) {
		int num=0, res=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un n�mero: ");
		num = teclado.nextInt();
		
		for(int cont=1;cont<=num;cont++) {
			for(int i=1;i<=10;i++) {
				res = i*cont;
				System.out.println("Resultado: " + res);
			}
			System.out.println("\n");
		}
			
				
		teclado.close();

	}

}
