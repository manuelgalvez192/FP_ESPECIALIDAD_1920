package EjerciciosFor;

import java.util.Scanner;

public class ForEjercicioPiramide {

	public static void main(String[] args) {
		Scanner teclado=new Scanner(System.in);
		int num=0,i, j=1;
		i=1;
		System.out.println("Introduzca un numero");
		num=teclado.nextInt();
	
		for(int cont=1, k=num;cont<=num;cont++) {
			j=1;
			while(j < k) {
				System.out.print("  ");
				j++;
			}
			while(i!=1) {
				System.out.print(i + " ");
				i--;
			}
			i=1;
			while(i<=cont) {
				System.out.print(i + " ");
				i++;
			}	
			k--;
			System.out.println();
		}
		teclado.close();
	}

	}


