package EjerciciosFor;

import java.util.Scanner;

public class ForFactorial {

	public static void main(String[] args) {
		int num=1, res = 1;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca n�mero");
		num = teclado.nextInt();
		
		
		while(num <=0) {
			System.out.println("Introduzca n�mero mayor que 0");
			num = teclado.nextInt();
		}
		for(;num>1; num--) {
			res *= num;
			
		}
		
		System.out.println("Factorial total: " + res);
		
		teclado.close();

	}

}
