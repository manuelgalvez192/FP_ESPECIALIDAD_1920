package EjerciciosFor;

import java.util.Scanner;

public class ForVerSiPrimo {

	public static void main(String[] args) {
		int num = 0;
		boolean primo = true;

		Scanner teclado = new Scanner(System.in);

		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();

		while (num < 0) {
			System.out.println("Introduzca un numero mayor que 0");
			num = teclado.nextInt();
		}
		for (int cont = 2; cont < num && primo; cont++) {

			if (num % cont == 0) {
				primo = false;
			}
		}

		if (primo) {
			System.out.println("Es primo");
		} else {
			System.out.println("No es primo");
		}

		teclado.close();
	}

}
