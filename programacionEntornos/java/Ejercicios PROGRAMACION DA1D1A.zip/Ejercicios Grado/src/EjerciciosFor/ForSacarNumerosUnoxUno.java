package EjerciciosFor;

import java.util.Scanner;

public class ForSacarNumerosUnoxUno {

	public static void main(String[] args) {
		int num=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();
		
		for(int cont=1;cont<=num;cont++) {
			for(int i=1;i<=cont;i++) {
				System.out.println(i);
			}
			System.out.println("\t");
		}

		teclado.close();
	}

}
