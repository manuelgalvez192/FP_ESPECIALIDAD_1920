package EjerciciosFor;

import java.util.Scanner;

public class ForMayorMenor100Numeros {

	public static void main(String[] args) {
		int num = 0, mayor = 0, menor = 1;

		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un n�mero: ");
		num = teclado.nextInt();

		mayor = num;
		for(int cont=1;cont!=99;cont++) {
			System.out.println("Introduzca un nuevo n�mero: ");
			num = teclado.nextInt();
			if (num > mayor) {
				mayor = num;

			} else {
				if (num < menor) {
					menor = num;
				}
			}
			
		} 
		System.out.println("Mayor: " + mayor);
		System.out.println("Menor: " + menor);
		teclado.close();

	}

}
