package EjerciciosFor;

import java.util.Scanner;

public class ForMeterMasNumeros {

	public static void main(String[] args) {
		
		int num=0, suma=0;
		
		Scanner teclado = new Scanner(System.in);

		for(int res=1;res!=0;) {
			
			System.out.println("Introduzca n�mero");
			num = teclado.nextInt();
			
			suma+=num;
			System.out.println("�Quiere seguir?(0 salir/1 seguir)");
			res = teclado.nextInt();
			
		}
		
		System.out.println("Resultado suma: " + suma);
		teclado.close();

	}

}
