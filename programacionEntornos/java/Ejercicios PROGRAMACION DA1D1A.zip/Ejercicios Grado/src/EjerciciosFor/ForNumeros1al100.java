package EjerciciosFor;

public class ForNumeros1al100 {

	public static void main(String[] args) {
		
		for(int numero=100;numero>0;numero--) {
			System.out.println(numero);
		}
	
	}

}
