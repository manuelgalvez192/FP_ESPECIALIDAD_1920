package EjerciciosFor;

import java.util.Scanner;

public class ForDividirSinSimbolo {

	public static void main(String[] args) {
		int num, num2, cont=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();
		
		System.out.println("Introduzca otro numero: ");
		num2 = teclado.nextInt();
			if(num2 == 0) {
				System.out.println("Error");
			}
			
			for(int div = num - num2;div>=0;div-=num2){
				cont++;
			} 
		
		System.out.println("Resto: " + cont);
		teclado.close();

	}

}
