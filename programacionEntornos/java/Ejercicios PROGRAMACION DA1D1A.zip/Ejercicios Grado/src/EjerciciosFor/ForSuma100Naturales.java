package EjerciciosFor;

public class ForSuma100Naturales {

	public static void main(String[] args) {
		int resultado=0;
		
		for(int numero=1;numero<=100;numero++){
			resultado+=numero;
		}
		
		System.out.println(resultado);

	}

}
