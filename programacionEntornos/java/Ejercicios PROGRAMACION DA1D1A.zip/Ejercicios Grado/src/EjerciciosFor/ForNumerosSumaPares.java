package EjerciciosFor;

import java.util.Scanner;

public class ForNumerosSumaPares {

	public static void main(String[] args) {
		int num=0, cont=0, j=0;
		double suma=0, media=0, res=0;
		
		Scanner teclado = new Scanner(System.in);
		for(int i=0;i<=99;i++) {
			
			System.out.println("Introduzca n�mero");
			num = teclado.nextInt();
			
			if(num % 2 == 0) {
				suma += num;
				j++;
			}
			else {
				media += num;
				cont++;
			}
			
			
		}
		res = media/cont;
		System.out.println("Suma: " + suma);
		System.out.println("Numero pares: " + j);
		System.out.println("Resultado: " + res);
		
		teclado.close();

	}

}
