package Prueba8del10;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		int hijos=0, edad=0;
		double ingresos=0, pagar = 0, ingresos2=0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca sus ingresos: ");
		ingresos=teclado.nextDouble();
		while(ingresos < 0) {
			System.out.println("Introduzca sus ingresos: ");
			ingresos=teclado.nextDouble();
		}
		System.out.println("Introduzca el numero de hijos: ");
		hijos = teclado.nextInt();
		
		while(hijos < 0) {
			System.out.println("Introduzca el numero de hijos: ");
			hijos = teclado.nextInt();
		}
		
		for(int i=1; i<=hijos;i++) {
			ingresos-=1000;
		}
		
		/*
		 if(hijos>0){
		 	ingresos -= hijos * 1000;
		 	
		 if(ingresos <0){
		 	ingresos = 0; por si al restarle dinero de impuestos, se queda en 0
		 }*/
		
		System.out.println("Introduzca la edad: ");
		edad = teclado.nextInt();
		
		while(edad < 0) {
			System.out.println("Introduzca la edad: ");
			edad = teclado.nextInt();
		}
		
		if(edad > 75) {
			ingresos-=3000;
		}
		
		if (ingresos > 0 && ingresos <= 12450) {
			pagar = ingresos * 0.19;
			ingresos2 = ingresos - 12450;
			if (ingresos2 < 0) {

				System.out.println("Cantidad a pagar: " + pagar);

			}

		} else if (ingresos > 12450 && ingresos <= 20200) {
			pagar = (ingresos - 12450) * 0.24;
			ingresos2 = 12450;
			pagar = pagar + (ingresos2 * 0.19);
			ingresos2 = ingresos2 - 12450;
			if (ingresos2 <= 0) {

				System.out.println("Cantidad a pagar: " + pagar);

			}

		}

		else if (ingresos > 20200 && ingresos <= 35200) {
			pagar = (ingresos - 20200) * 0.3;
			ingresos2 = 20200-12450;
			pagar = (ingresos2 * 0.24) + pagar;
			ingresos2 = 12450;
			pagar = (ingresos2 * 0.19) + pagar;
			ingresos2 = ingresos2 - 12450;
			if (ingresos2 <= 0) {

				System.out.println("Cantidad a pagar: " + pagar);

			}
		} else if (ingresos > 35200 && ingresos < 60000) {
			pagar = (ingresos - 30200) * 0.37;
			ingresos2 = 35200-20200;
			pagar = pagar + (ingresos2 * 0.3);
			ingresos2 = 20200-12450;
			pagar = (ingresos2 * 0.24) + pagar;
			ingresos2 = 12450;
			pagar = (ingresos2 * 0.19) + pagar;
			ingresos2 = ingresos2 - 12450;
			if (ingresos2 <= 0) {

				System.out.println("Cantidad a pagar: " + pagar);

			}

		} else if (ingresos > 60000) {
			pagar = (ingresos - 60000) * 0.45;
			ingresos2 = 60000-35200;
			pagar = pagar + (ingresos2 * 0.37);
			ingresos2 = 35200-20200;
			pagar = pagar + (ingresos2 * 0.3);
			ingresos2 = 20200-12450;
			pagar = (ingresos2 * 0.24) + pagar;
			ingresos2 = 12450;
			pagar = (ingresos2 * 0.19) + pagar;
			ingresos2 = ingresos2 - 12450;
			if (ingresos2 <= 0) {

				System.out.println("Cantidad a pagar: " + pagar);

			}

		}
		
		teclado.close();	
		}
		

}
