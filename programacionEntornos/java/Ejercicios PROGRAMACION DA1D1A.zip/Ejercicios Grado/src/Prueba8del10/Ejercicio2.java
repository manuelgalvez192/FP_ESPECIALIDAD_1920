package Prueba8del10;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		int seg=0, horas=0, min = 0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduce unos segundos");
		seg = teclado.nextInt();
		
		min = seg/60;
		seg = seg - (min*60);
		horas = min/60;
		min = min - (horas*60);
		
//		horas=seg/3600;
//		min=(seg%3600)/60;
//		seg=seg%60;
		
		System.out.println("Horas: " +horas+" Min: "+min+" Seg: "+seg);
		teclado.close();

	}

}
