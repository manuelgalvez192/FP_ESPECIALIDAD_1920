package Prueba8del10;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		int num =0, mag=0, cociente = 1, resto = 0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca numero: ");
		num = teclado.nextInt();
		
		while (cociente != 0) {
			cociente = num / 10;
			resto = num % 10;
			mag += resto;
			num = cociente;
		}
		num = mag;
		cociente = 1;
		if(mag > 9) {
			mag=0;
			while (cociente != 0) {
				cociente = num / 10;
				resto = num % 10;
				mag += resto;
				num = cociente;
			}
		}
		
		System.out.println("El numero magico es: " + mag);
		teclado.close();
	}

}
