package Ejercicios;

import java.util.Scanner;

public class KMydias {
	public static void main(String[] args) {
		int km=0, dias=0;
		double precio=0;
		final double KM = 8.5, DESC = 0.3;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca unos km: ");
		km = teclado.nextInt();

		System.out.println("Introduzca unos dias: ");
		dias = teclado.nextInt();
		
		if(km > 1000 && dias > 7) {
			precio = (km *KM) *(1-DESC);
			System.out.println("Precio descuento: " + precio);
		}
		else {
			precio = km * KM;
			System.out.println("Precio final: " + precio);
		}
		
		teclado.close();
		
	}
}
