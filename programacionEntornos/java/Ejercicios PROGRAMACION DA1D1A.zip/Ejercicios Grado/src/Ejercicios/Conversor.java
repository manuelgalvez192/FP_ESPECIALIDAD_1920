package Ejercicios;

import java.util.Scanner;

public class Conversor{
	public static void main(String[] args) {
		double pulgadas;
		final double CONVERSOR = 2.54;
		double res;
		
		Scanner teclado = new Scanner(System.in);
		
		
		System.out.println("Pulgadas:");
		pulgadas = teclado.nextDouble();
		res = pulgadas * CONVERSOR;
		System.out.println("CM: " + res);
		
		
		teclado.close();
	}
}


	