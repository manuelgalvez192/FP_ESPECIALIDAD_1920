package Ejercicios;

import java.util.Scanner;

public class MayorMenor100Numeros {

	public static void main(String[] args) {
		int num=0, cont=1, mayor=0, menor=1;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un n�mero: ");
		num = teclado.nextInt();
		
		mayor = num;
		while(cont!=9) {
			System.out.println("Introduzca un nuevo n�mero: ");
			num = teclado.nextInt();
			if(num > mayor) {
				mayor = num;
					
			}
			else {
				if(num < menor) {
					menor = num;
				}
			}
			cont++;
		}
		System.out.println("Mayor: " + mayor);
		System.out.println("Menor: " + menor);
		teclado.close();

	}

}
