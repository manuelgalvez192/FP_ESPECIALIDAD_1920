package Ejercicios;

import java.util.Scanner;

public class ComparadorNumeros {

	public static void main(String[] args) {
		int num1=0, num2=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca primer n�mero: ");
		num1 = teclado.nextInt();
		System.out.println("Introduzca segundo n�mero: ");
		num2 = teclado.nextInt();
		
		if(num1 < num2) {
			System.out.println("Primero menor que el Segundo");
		}
		else if(num1 > num2) {
			System.out.println("Primero mayor que el Segundo");
		}
		else {
			System.out.println("Primero igual que el Segundo");
		}
		
		teclado.close();
	}

}
