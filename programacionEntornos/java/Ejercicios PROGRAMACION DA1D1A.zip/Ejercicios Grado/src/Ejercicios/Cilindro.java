package Ejercicios;

import java.util.Scanner;

public class Cilindro {

	public static void main(String[] args) {
		double altura = 0 , radio = 0;
		final double PI = 3.14;
		double superficie=0, volumen=0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca una altura: ");
		altura = teclado.nextDouble();
		System.out.println("Introduzca un radio: ");
		radio = teclado.nextDouble();
		
		superficie = 2 * PI * radio * (altura + radio);
		System.out.println("La superficie es: " + superficie);
		
		volumen = PI * (radio*radio) * altura;
		System.out.println("El volumen es: " + volumen);
		
		teclado.close();
		
	}

}
