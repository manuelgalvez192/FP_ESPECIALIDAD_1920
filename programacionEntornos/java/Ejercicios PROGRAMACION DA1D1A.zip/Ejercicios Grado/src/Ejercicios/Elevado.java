package Ejercicios;

import java.util.Scanner;

public class Elevado {

	public static void main(String[] args) {
		int num=0, num2=0, cont=0,res=1;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca n�mero 1: ");
		num = teclado.nextInt();
		
		System.out.println("Introduzca n�mero 2: ");
		num2 = teclado.nextInt();
		
		while(cont != num2) {
			res *= num;
			cont++;
		}
		System.out.println("Resultado: " + res);
		
		teclado.close();
	}

}
