package Ejercicios;

import java.util.Scanner;

public class SumaNPrimerosPrimos {

	public static void main(String[] args) {
		int num=2, div=2, suma=0, contador_primo=1, cantidad_primo=0;
		int primo = 1;
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		cantidad_primo = teclado.nextInt();
		
		while(contador_primo <= cantidad_primo) {
			div=2;
			primo=1;
			while(div < num && primo == 1){
				if(num % div == 0) {
					primo = 0;
				}
				div++;
			}
			
			if(primo == 1) {
				suma+=num;
				contador_primo++;
			}
			num++;
			
			teclado.close();
			
			
		}
		
		System.out.println("Suma: " + suma);
		
	}

}
