package Ejercicios;

import java.util.Scanner;

public class TablasMultNumeroHastaPedido {

	public static void main(String[] args) {
		int i=1, cont=1, num=0, res=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un n�mero: ");
		num = teclado.nextInt();
		
		//while(num!=10){ Para el ejercicio que pide mientras que no sea 10
		while(cont<=num) {
			while(i<=10) {
				res = i*cont;
				System.out.println("Resultado: " + res);
				i++;
			}
			System.out.println("\n");
			i=1;
			cont++;
		}
		//}
		teclado.close();
	}

}
