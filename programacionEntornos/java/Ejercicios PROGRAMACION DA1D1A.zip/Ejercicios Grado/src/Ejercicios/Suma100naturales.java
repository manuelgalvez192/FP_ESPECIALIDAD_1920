package Ejercicios;

public class Suma100naturales {

	public static void main(String[] args) {
		int numero=1, resultado=0;
		
		while(numero<=100) {
			resultado +=numero;
			numero++;
		}
		System.out.println(resultado);
	}

}
