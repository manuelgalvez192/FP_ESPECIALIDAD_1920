package Ejercicios;

import java.util.Scanner;

public class TablaMult1Numero {

	public static void main(String[] args) {
		int i=1, num=0, res=0;
		
		Scanner teclado = new Scanner(System.in);
		
		while(num!=0){ 
			System.out.println("Introduzca un n�mero: ");
			num = teclado.nextInt();
			while(i<=10) {
				res = i*num;
				System.out.println("Resultado: " + res);
				i++;
			}
		}
		teclado.close();
		
	}

}
