package Ejercicios;

public class Escribir100al1 {

	public static void main(String[] args) {
		int numero=100;
		while(numero>0) {
			System.out.println(numero);
			numero--;
		}
	}

}
