package Ejercicios;

import java.util.Scanner;

public class Lector1a100 {

	public static void main(String[] args) {
		int numero=0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca un numero: ");
		numero = teclado.nextInt();
		if(numero >= 1 && numero<=100) {
			System.out.println("Dentro del rango");
		}
		else {
			System.out.println("Fuera de rango");
		}
		
		teclado.close();
		
	}

}
