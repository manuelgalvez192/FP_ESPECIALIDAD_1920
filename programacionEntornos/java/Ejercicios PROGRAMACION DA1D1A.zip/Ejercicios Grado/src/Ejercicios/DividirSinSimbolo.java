package Ejercicios;

import java.util.Scanner;

public class DividirSinSimbolo {

	public static void main(String[] args) {
		int num, num2, div=0, cont=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();
		
		System.out.println("Introduzca otro numero: ");
		num2 = teclado.nextInt();
			if(num2 == 0) {
				System.out.println("Error");
			}
			div = num - num2;
			while(div >= 0) {
				cont++;
				div -= num2;
			}
		
		System.out.println("Resto: " + cont);
		teclado.close();
	}

}
