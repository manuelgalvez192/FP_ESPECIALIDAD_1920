package Ejercicios;

import java.util.Scanner;

public class MayorDe100Numeros {

	public static void main(String[] args) {
		int num=0, cont=1, mayor=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un n�mero: ");
		num = teclado.nextInt();
		
		mayor = num;
		while(cont!=99) {
			System.out.println("Introduzca un nuevo n�mero: ");
			num = teclado.nextInt();
			if(num > mayor) {
				mayor = num;
			}
			cont++;
		}
		System.out.println("Mayor: " + mayor);
		teclado.close();
	}
	
}
