package Ejercicios;

public class VerSiPrimoEntre2y100 {

	public static void main(String[] args) {
		int num=0, cont=0;
		boolean primo = true;
		num = 2;
		while(num <= 100) {
			
			cont = 2;
			while(cont < num) {
				if(num % cont == 0) {
					primo = false;
				}
				cont++;
			}
			if(primo) {
				System.out.println("Primo: " +  num);
			}
			num++;
			primo = true;
		}

	}

}
