package Ejercicios;

import java.util.Scanner;

public class ComprobarOrdenCreciente {

	public static void main(String[] args) {
		int num1=0,num2=0,num3=0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca primer n�mero: ");
		num1 = teclado.nextInt();
		System.out.println("Introduzca segundo n�mero: ");
		num2 = teclado.nextInt();
		System.out.println("Introduzca tercer n�mero: ");
		num3 = teclado.nextInt();
		
		if(num1 < num2) {
			if(num2 < num3) {
				System.out.println("Orden creciente");
			}
			else {
				System.out.println("Orden incorrecto");
			}
		}
		else {
			System.out.println("Orden incorrecto");
		}
		
		
		teclado.close();

	}

}
