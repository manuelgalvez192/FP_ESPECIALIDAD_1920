package Ejercicios;

import java.util.Scanner;

public class N�merosSumaPares {

	public static void main(String[] args) {
		int num=0, cont=0, i=0, j=0;
		double suma=0, media=0, res=0;
		
		Scanner teclado = new Scanner(System.in);
		while(i <= 99) {
			System.out.println("Introduzca n�mero");
			num = teclado.nextInt();
			
			if(num % 2 == 0) {
				suma += num;
				j++;
			}
			else {
				media += num;
				cont++;
			}
			i++;
			
		}
		res = media/cont;
		System.out.println("Suma: " + suma);
		System.out.println("Numero pares: " + j);
		System.out.println("Resultado: " + res);
		
		teclado.close();
	}

}
