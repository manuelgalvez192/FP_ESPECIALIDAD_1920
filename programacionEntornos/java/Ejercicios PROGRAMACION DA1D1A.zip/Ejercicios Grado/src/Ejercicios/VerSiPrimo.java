package Ejercicios;

import java.util.Scanner;

public class VerSiPrimo {

	public static void main(String[] args) {
		int num=0, cont=2;
		boolean primo = true; 
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();
		
		while(num<0) {
			System.out.println("Introduzca un numero mayor que 0");
			num = teclado.nextInt();
		}
		
		while(cont < num && primo) {
			if(num % cont == 0) {
				primo = false;
			}
			cont++;
		}
		if(primo) {
			System.out.println("Es primo");
		}
		else {
			System.out.println("No es primo");
		}
		
		teclado.close();
	}

}
