package Ejercicios;

import java.util.Scanner;

public class CalcularDigitos {

	public static void main(String[] args) {
		int cociente=1, num=0, suma=0, cont=0, div = 10, resto = 0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();
		
		while(cociente!=0) {
			cociente = num/div;
			resto = num%div;
			cont++;
			suma+=resto;
			num = cociente;
		}
		suma+=cociente;
		System.out.println("La suma de los digitos es: " + suma + " y el numero de digitos es: "+ cont);
		teclado.close();
	}

}
