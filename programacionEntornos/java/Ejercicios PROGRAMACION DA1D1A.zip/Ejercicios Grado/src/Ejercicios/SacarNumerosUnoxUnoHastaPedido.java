package Ejercicios;

import java.util.Scanner;

public class SacarNumerosUnoxUnoHastaPedido {

	public static void main(String[] args) {
		int cont=1, num=0, i=1;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();
		
		while(cont<=num) {
			while(i<=cont) {
				System.out.println(i);
				i++;
			}
			i=1;
			cont++;
			System.out.println("\t");
			teclado.close();
		}
		
		
		

	}

}
