package Ejemplos;

import java.util.Scanner;

public class EjemploFechaDiferencia {

	public static void main(String[] args) {
		//pedir fechas y mostrar diferencia, meses de 30
		
		int dia1 = 0, dia2 = 0, mes1 = 0, mes2 = 0, anyo1 = 0, anyo2 = 0;
		int difdias = 0, difmes = 0, difanyo = 0, diftotal = 0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca dia1: ");
		dia1 = teclado.nextInt();
		System.out.println("Introduzca mes1: ");
		mes1 = teclado.nextInt();
		System.out.println("Introduzca anyo1: ");
		anyo1 = teclado.nextInt();
		
		if(dia1 > 31 || dia1 < 0) {
			System.out.println("Error de dia");
		}
		if(mes1<0 || mes1 > 12) {
			 System.out.println("Error de mes");
		}
		if(anyo1 < 0) {
			System.out.println("No existen a�os negativos");
		}
		
		while(dia1 > 30 || dia1 < 0 || mes1 < 0 || mes1 > 12 ) {
			
			System.out.println("Introduzca dia1: ");
			dia1 = teclado.nextInt();
			System.out.println("Introduzca mes1: ");
			mes1 = teclado.nextInt();
			System.out.println("Introduzca anyo1: ");
			anyo1 = teclado.nextInt();
			
		}
		System.out.println("Fecha1: " + dia1 + "/" + mes1 + "/" + anyo1 + "\n");
		
		System.out.println("Introduzca dia2: ");
		dia2 = teclado.nextInt();
		System.out.println("Introduzca mes2: ");
		mes2 = teclado.nextInt();
		System.out.println("Introduzca anyo2: ");
		anyo2 = teclado.nextInt();
		
		if(dia2 > 30 || dia2 < 0) {
			System.out.println("Error de dia");
		}
		if(mes2<0 || mes2 > 12) {
			 System.out.println("Error de mes");
		}
		if(anyo2 < 0) {
			System.out.println("No existen a�os negativos");
		}
		
		while(dia2 > 30 || dia2 < 0 || mes2 < 0 || mes2 > 12 ) {
			
			System.out.println("Introduzca dia2: ");
			dia2 = teclado.nextInt();
			System.out.println("Introduzca mes2: ");
			mes2 = teclado.nextInt();
			System.out.println("Introduzca anyo2: ");
			anyo2 = teclado.nextInt();
		}
		
		System.out.println("Fecha2: " + dia2 + "/" + mes2 + "/" + anyo2 + "\n");
		
		difdias = dia1 - dia2;
		difmes = mes1 - mes2;
		difmes *= 30;
		difanyo = anyo1 - anyo2;
		difanyo *= 365;
		diftotal = difdias + difmes + difanyo;
		System.out.println("Diferencia de dias: " + diftotal);
		
		teclado.close();
	}

}
