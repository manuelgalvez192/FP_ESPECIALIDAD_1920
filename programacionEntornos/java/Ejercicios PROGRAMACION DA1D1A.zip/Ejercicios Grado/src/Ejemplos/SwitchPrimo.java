package Ejemplos;

import java.util.Scanner;

public class SwitchPrimo {

	public static void main(String[] args) {
		int opcion=0, num=0, cont=0, i=0, res=0, num3=0;
		boolean primo = true;
		
		Scanner teclado = new Scanner(System.in);
		
		while(opcion != 4) {
				System.out.println("Elige opcion: ");
				System.out.println("1. Comprobar primo");
				System.out.println("2. Primos entre 2 y 100");
				System.out.println("3. Tabla Multiplicar");
				System.out.println("4. Salir");
				opcion = teclado.nextInt();
				
				switch(opcion) {
				case 1:
					System.out.println("Introduzca n�mero 1: ");
					num = teclado.nextInt();
		
					cont = 2;					
					while(cont < num && primo) {
						if(num % cont == 0) {
							primo = false;
						}
						cont++;
					}
					if(primo) {
						System.out.println("Es primo\n");
					}
					else {
						System.out.println("No es primo\n");
					}
					break;
				case 2:
					num3 = 2;
					while(num3 <= 100) {
						
						cont = 2;
						while(cont < num3) {
							if(num3 % cont == 0) {
								primo = false;
							}
							cont++;
						}
						if(primo) {
							System.out.println("Primo: " +  num3);
						}
						num3++;
						primo = true;
					}
					break;
				case 3:
					System.out.println("Introduzca n�mero 1: ");
					num = teclado.nextInt();
				
					i=1;
					while(i<=10) {
						res = i*num;
						System.out.println("Resultado: " + res);
						i++;
					}
					System.out.println("\n");
					break;
				case 4:
					System.out.println("Ha pulsado salir\n");
					
					break;
				default: 
					System.out.println("Opcion incorrecta\n");
			}
		
			
		}
		teclado.close();

	}

}
