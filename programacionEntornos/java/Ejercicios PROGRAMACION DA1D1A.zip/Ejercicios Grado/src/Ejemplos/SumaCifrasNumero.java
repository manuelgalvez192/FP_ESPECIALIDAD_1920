package Ejemplos;

import java.util.Scanner;

public class SumaCifrasNumero {

	public static void main(String[] args) {
		int num=0, cociente=1, resto=0, cont=0, suma=0;
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduzca un numero: ");
		num = teclado.nextInt();
		
		while(cociente!=0) {
			cociente = num/10;
			cont++;
			resto = num%10;
			suma+=resto;
			num = cociente;
		}
		
		System.out.println("El resultado de la suma es: " + suma + " y el numero de digitos es: " + cont);
		teclado.close();

	}

}
