package Ejemplos;

import java.util.Scanner;

public class PruebaIntercambio2 {

	public static void main(String[] args) {
		int numero, contador = 1, contador2 = 1;
		
		Scanner teclado = new Scanner(System.in); //Falta
		System.out.println("Dame numero");
		numero = teclado.nextInt();
		
		while(contador <= numero) {
			while(contador2 <= contador) {
				//resultado ++;
				//System.out.println(resultado);
				System.out.print(contador2);
				contador2++;
			}
			//resultado = 0;
			contador2 = 1;
			contador++;
			System.out.println(); 
		}
		teclado.close();//Falta
	}

}
