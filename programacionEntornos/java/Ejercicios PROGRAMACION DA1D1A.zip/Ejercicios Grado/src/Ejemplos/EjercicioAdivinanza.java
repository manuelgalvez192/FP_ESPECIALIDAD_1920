package Ejemplos;

import java.util.*;

public class EjercicioAdivinanza {

	public static void main(String[] args) {
		int num1 = 0, num2 = 0, intento = 0, n = 10;
		
		Random rand = new Random();
		num1 = rand.nextInt(n+1);
		
		Scanner teclado = new Scanner(System.in);
		
		while(intento != 7 && num1 != num2) {
			System.out.println("Introduce numero");
			num2 = teclado.nextInt();
			if(num1 < num2) {
				System.out.println("Numero mayor que el pedido");
				intento++;
			}
			else if(num1 > num2) {
				System.out.println("Numero menor que el pedido");
				intento++;
			}
			else {
				System.out.println("Enhorabuena el numero es correcto: " + num1);
				num2 = num1;
			}
		}
		if(intento == 7) {
			System.out.println("No has conseguido adivinarlo");
		}
		teclado.close();
	}

}
