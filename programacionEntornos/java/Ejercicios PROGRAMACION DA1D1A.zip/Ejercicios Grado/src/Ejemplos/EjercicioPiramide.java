package Ejemplos;

import java.util.Scanner;

public class EjercicioPiramide {

	public static void main(String[] args) {
		Scanner teclado=new Scanner(System.in);
		int num=0,cont,i, j=1, k= 1;
		cont=1;
		i=1;
		System.out.println("Introduzca un numero");
		num=teclado.nextInt();
		k = num;
		while(cont<=num) {
			j=1;
			while(j < k) {
				System.out.print("  ");
				j++;
			}
			while(i!=1) {
				System.out.print(i + " ");
				i--;
			}
			i=1;
			while(i<=cont) {
				System.out.print(i + " ");
				i++;
			}	
			cont++;
			k--;
			System.out.println();
		}
		teclado.close();
	}

	}


