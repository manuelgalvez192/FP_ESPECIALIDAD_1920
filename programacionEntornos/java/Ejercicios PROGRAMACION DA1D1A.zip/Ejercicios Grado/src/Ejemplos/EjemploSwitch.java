package Ejemplos;

//import java.util.Scanner;

public class EjemploSwitch {

	public static void main(String[] args) {
		int opcion=0;
		
		//Scanner teclado = new Scanner(System.in);
		
		System.out.println("1. Sumar");
		System.out.println("2. Restar");
		System.out.println("3. Multiplicar");
		System.out.println("4. Dividir");
		//opcion = teclado.nextInt();
		
		switch(opcion) {
		
		case 1: //sumar
			break;
		case 2: //restar
			break;
		case 3: //multiplicar
			break;
		case 4: //dividir
			break;
		default: //otro caso
			
			
		
		
		
		}
		
		
		
		
		
		
	}

}
