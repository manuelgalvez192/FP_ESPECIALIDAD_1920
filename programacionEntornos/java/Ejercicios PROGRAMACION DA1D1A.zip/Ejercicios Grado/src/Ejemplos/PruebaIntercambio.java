package Ejemplos;

import java.util.Scanner;

public class PruebaIntercambio {

	public static void main(String[] args) {
		int numero, resultado=0;
		
		Scanner teclado = new Scanner(System.in);//Falta 
		
		System.out.println("Dame un numero");
		numero = teclado.nextInt();
		
		while(resultado < numero && numero != 0) {
			if(numero > resultado) {
				resultado = numero;
			}
			System.out.println("Dame un numero");
			numero = teclado.nextInt();
		}
		teclado.close();//Falta
	}

}
