package Ejemplos;

import java.util.Scanner;

public class EjemploFechaValida {

	public static void main(String[] args) {
		//dada una fecha ver si es correcta
		int dia=0;
		int mes=0;
		int anyo=0;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca dia: ");
		dia = teclado.nextInt();
		System.out.println("Introduzca mes: ");
		mes = teclado.nextInt();
		System.out.println("Introduzca anyo: ");
		anyo = teclado.nextInt();
		
		if(dia > 31 || dia < 0) {
			System.out.println("Error de dia");
		}
		if(mes<0 || mes > 12) {
			 System.out.println("Error de mes");
		}
		if(anyo < 0) {
			System.out.println("No existen a�os negativos");
		}
		
		if(dia == 31) {
			if(mes == 2 || mes == 4 || mes == 6 || mes == 9 || mes == 11) {
				System.out.println("Fecha err�nea");
			}
			else {
				System.out.println("Fecha introducida: " + dia + "/" + mes + "/" + anyo);
			}
		}
		else if(dia == 30) {
			if(mes == 2) {
				System.out.println("Fecha err�nea");
			}
			else {
				System.out.println("Fecha introducida: " + dia + "/" + mes + "/" + anyo);
			}
		}
		else if(dia == 29 && mes == 2) {
			if(anyo % 4 == 0) {
				if(anyo % 100 == 0) {
					if(anyo % 400 == 0) {
						System.out.println("Fecha introducida: " + dia + "/" + mes + "/" + anyo);
					}
					else {
						System.out.println("Fecha err�nea");
					}
				}
				else {
					System.out.println("Fecha err�nea");
				}
				
			}
			else {
				System.out.println("A�o no bisiesto, fecha err�nea");
			}
		}
		else{
			System.out.println("Fecha introducida: " + dia + "/" + mes + "/" + anyo);
		}
		teclado.close();
		
	}

}
