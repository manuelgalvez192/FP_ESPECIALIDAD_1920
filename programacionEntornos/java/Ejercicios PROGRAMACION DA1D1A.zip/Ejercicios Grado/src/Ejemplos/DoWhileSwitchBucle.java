package Ejemplos;

import java.util.Scanner;

public class DoWhileSwitchBucle {

	public static void main(String[] args) {
		int num=0, num2=0;
		int suma=0, resta=0, mult=0, div=0, pot=1;
		int opcion=0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca n�mero 1: ");
		num = teclado.nextInt();
		
		System.out.println("Introduzca n�mero 2: ");
		num2 = teclado.nextInt();
		
			do {
				System.out.println("Elige opcion: ");
				System.out.println("1. Sumar");
				System.out.println("2. Restar");
				System.out.println("3. Multiplicar");
				System.out.println("4. Dividir");
				System.out.println("5. Potencia");
				System.out.println("6. Salir");
				opcion = teclado.nextInt();
				
				switch(opcion) {
				case 1:
					suma = num + num2;
					System.out.println("Suma: " + suma + "\n");
					break;
				case 2:
					resta = num - num2;
					System.out.println("Resta: " + resta + "\n");
					break;
				case 3:
					mult = num * num2;
					System.out.println("Multiplicacion: " + mult + "\n");
					break;
				case 4: 
					if(num2 != 0) {
						div = num / num2;
					}
					else {
						System.out.println("Error");
					}
					System.out.println("Division: " + div + "\n");
					break;
				case 5:
		//			while(cont != num2) {
		//				pot *= num;
		//				cont++;
		//			}
					pot = (int) Math.pow(num, num2);
					System.out.println("Resultado: " + pot + "\n");
					break;
				case 6:
					System.out.println("Ha pulsado salir");
					
					break;
				default: 
					System.out.println("Opcion erronea");
			}
		
			
		}while(opcion != 6);
		
				
		
		
		teclado.close();

	}

}
