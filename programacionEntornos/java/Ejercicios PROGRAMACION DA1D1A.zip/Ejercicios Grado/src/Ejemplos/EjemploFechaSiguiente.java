package Ejemplos;

import java.util.Scanner;

public class EjemploFechaSiguiente {

	public static void main(String[] args) {
		// pedir fecha y mostrar fecha siguiente
		int dia=0,mes=0,anyo=0;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Introduzca dia: ");
		dia = teclado.nextInt();
		System.out.println("Introduzca mes: ");
		mes = teclado.nextInt();
		System.out.println("Introduzca anyo: ");
		anyo = teclado.nextInt();
		
		if(dia > 31 || dia < 0) {
			System.out.println("Error de dia");
		}
		if(mes<0 || mes > 12) {
			 System.out.println("Error de mes");
		}
		if(anyo < 0) {
			System.out.println("No existen a�os negativos");
		}
		
		if(dia == 30) {
			if(mes == 1 || mes == 3 || mes == 5 || mes == 12 || mes == 7 || mes == 8 || mes == 10) {
				dia++;
				System.out.println("Fecha siguiente a la introducida: " + dia + "/" + mes + "/" + anyo);
			}
			else if(mes == 2) {
				System.out.println("Mes sin 30 dias");
			}
			else {
				dia = 1;
				mes++;
				System.out.println("Fecha introducida: " + dia + "/" + mes + "/" + anyo);
			}
		}
		else if(dia == 31) {
			if(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10) {
				dia = 1;
				mes++;
				System.out.println("Fecha siguiente a la introducida: " + dia + "/" + mes + "/" + anyo);
			}
			else if(mes == 12) {
				dia = 1;
				mes = 1;
				anyo++;
				System.out.println("Fecha siguiente a la introducida: " + dia + "/" + mes + "/" + anyo);
			}
			else if (mes == 2 || mes == 4 || mes == 6 || mes == 9 || mes == 11){
				System.out.println("Mes sin 31 dias");
			}
		}
		else if(dia == 28) {
			if(mes == 2) {
				if(anyo % 4 == 0) {
					if(anyo % 100 == 0) {
						if(anyo % 400 == 0) {
							dia++;
							System.out.println("Fecha siguiente a la introducida: " + dia + "/" + mes + "/" + anyo);
						}
					}
				}
				else {
					dia = 1;
					mes++;
					System.out.println("Fecha siguiente a la introducida: " + dia + "/" + mes + "/" + anyo);
				}
			}
			else {
				dia++;
				System.out.println("Fecha siguiente a la introducida: " + dia + "/" + mes + "/" + anyo);
			}
		}
		else if	(dia == 29 && mes == 2) {
			if(anyo % 4 == 0) {
				if(anyo % 100 == 0) {
					if(anyo % 400 == 0) {
						dia = 1;
						mes++;
						System.out.println("Fecha siguiente a la introducida: " + dia + "/" + mes + "/" + anyo);
					}
				}
				
			}
			else {
				System.out.println("A�o no bisiesto, fecha err�nea");
			}
		}
		else if(dia > 1 && (dia != 28 || dia !=30 || dia!=31) && dia < 32) {
			dia++;
			System.out.println("Fecha siguiente a la introducida: " + dia + "/" + mes + "/" + anyo);
		}
		
		teclado.close();
	}

}
