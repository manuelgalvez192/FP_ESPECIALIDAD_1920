package EjercicioFicheroCSV;

import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

public class MainCSV {

	public static void main(String[] args) throws IOException{
		
		Scanner teclado = new Scanner(System.in);
		String nombre = "", apellido = "";
		int telefono = 0,tlf=0;
		String persona = "";
	    BufferedWriter out = null;
	    File fl = new File("src/EjercicioFicheroCSV/EjercicioCSV.txt");
	    File temp = new File(fl.getAbsolutePath() + ".tmp");
	    BufferedReader inputStream = null;
		int opcion = 0;
		PrintWriter pw = null;
		while(opcion != 4) {
			System.out.println("Elija opcion: ");
		    System.out.println("1. A�adir persona");
		    System.out.println("2. Buscar nombre dado telefono");
		    System.out.println("3. Borrar persona/s dado telefono");
		    System.out.println("4. Salir");
		    opcion = teclado.nextInt();
		    
		    switch (opcion) {
		    
		    case 1:
		    	try {
		    		teclado.nextLine();
			    	System.out.println("Introduzca nombre: ");
				    nombre = teclado.nextLine();
				    System.out.println("Introduzca apellido: ");
				    apellido = teclado.nextLine();
				    System.out.println("Introduzca telefono: ");
				    telefono = teclado.nextInt();
				    persona = nombre +"," + apellido + "," +telefono;
				   
				    out = new BufferedWriter(new FileWriter(fl.getAbsoluteFile(), true));
				  
				    out.write(persona);
				    out.write("\n");
		    	}finally{
		    		out.close();
		    	}
	
			    break;
		    case 2:
		    	System.out.println("Introduzca telefono: ");
		    	tlf = teclado.nextInt();
		    	 try {
		             inputStream = new BufferedReader(new FileReader("src/EjercicioFicheroCSV/EjercicioCSV.txt"));
		            
		             String l;
		            
		             while ((l = inputStream.readLine()) != null) {
		            	StringTokenizer tok = new StringTokenizer(l, ",");
		            	nombre = tok.nextToken();
		            	apellido = tok.nextToken();
		            	telefono = Integer.parseInt(tok.nextToken());
		            	if(tlf == telefono) {
		            		System.out.println("Nombre: "+nombre);
		            	}
		            	
		             }
		         } finally {
		             if (inputStream != null) {
		                 inputStream.close();
		             }
		             
		         }
		    	break;
		    case 3:
		    	System.out.println("Introduzca telefono: ");
		    	tlf = teclado.nextInt();
		    	 try {
		             inputStream = new BufferedReader(new FileReader("src/EjercicioFicheroCSV/EjercicioCSV.txt"));
		             pw = new PrintWriter(new FileWriter(temp));
		             String l;
		            
		             while ((l = inputStream.readLine()) != null) {
		            	 	StringTokenizer tok = new StringTokenizer(l, ",");
			            	nombre = tok.nextToken();
			            	apellido = tok.nextToken();
			            	telefono = Integer.parseInt(tok.nextToken());
			            	if(tlf != telefono) {
			                     pw.println(l);
			                     pw.flush();
			            	}
		            		 
		                 }
		         } finally {
		             if (inputStream != null) {
		                 inputStream.close();
		             }
		             pw.close();
		      
		             //Delete the original file
		             if (!fl.delete()) {
		                 System.out.println("Could not delete file");
		                 return;
		             }
		      
		             //Rename the new file to the filename the original file had.
		             if (!temp.renameTo(fl)){
		                 System.out.println("Could not rename file");
		      
		             }
		             
		         }
		    	
		    	break;
		    	
		    case 4:
		    	System.out.println("Adios");
		    	break;
		    default:
		    	System.out.println("Opcion erronea");
		    	teclado.close();
			}
		 }    
	}
}
