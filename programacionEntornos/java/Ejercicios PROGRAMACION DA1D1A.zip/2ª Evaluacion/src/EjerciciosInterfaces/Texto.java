package EjerciciosInterfaces;

public class Texto implements CharSequence{
	private int id;
	private char[] texto;
	
	public Texto(int id, char[]c) {
		this.id = id;
		texto = new char[c.length];
		for(int i=0; i<texto.length;i++) {
			texto[i] = c[i];
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	@Override
	public char charAt(int index) {
		
		return texto[index];
	}

	@Override
	public int length() {
		return texto.length;
	}

	@Override
	public CharSequence subSequence(int start, int end) {
		CharSequence res = null;
		char[] c = new char[end-start];
		int pos = 0;
		for(int i=start; i<end;i++) {
			c[pos] = texto[i];
			pos++;
		}
		res = new Texto(0,c);		
		return res;
	}
	public int compareTo(Object o) {
		return ((Texto)this).texto.length - ((Texto)o).texto.length;
	}

}
