package EjerciciosInterfaces;

import java.util.Comparator;

public class ComparadorId implements Comparator<Texto>{

	@Override
	public int compare(Texto arg0, Texto arg1) {
		
		return arg0.getId() - arg1.getId();
	}

}
