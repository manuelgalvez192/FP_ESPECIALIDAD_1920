package Ejercicio2Ficheros;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main2Ficheros {

	public static void main(String[] args) {

//			5. Borrar departamento (se pide nombre). El borrado se har� en cascada
//			6. Salir
		//-Aumentar un 10% el salario de los empleados que ganen menos que la media
		//-Crear un fichero con todos los datos de empleados y departamentos.
		//En cada l�nea aparecer�n los datos de un empleado y a continuaci�n los de su departamento. 
		//El id de departamento aparece s�lo una vez. 
		Scanner teclado = new Scanner(System.in);
		String nombre = "", apellido = "", nombre_dep="";
		double salario=0, presupuesto = 0;
		int id_dep=0;
		int opcion = 0;
		Sistema sis = new Sistema();
		Empleado emp = null;
		Departamento dep = null;
		while(opcion != 8) {
			System.out.println("Elija opcion: ");
		    System.out.println("1. A�adir empleado (el departamento debe existir, si no existe se a�adir� el departamento).");
		    System.out.println("2. A�adir departamento.");
		    System.out.println("3. Mostrar datos de empleados de un departamento (se pide el nombre del departamento).");
		    System.out.println("4. Mostrar el nombre del departamento con el trabajador que m�s gana (se supone que ser� solo 1).");
		    System.out.println("5. Borrar departamento (se pide nombre). El borrado se har� en cascada.");
		    System.out.println("6. Aumentar un 10% el salario de los empleados que ganen menos que la media.");
		    System.out.println("7. Crear un fichero con todos los datos de empleados y departamentos.");
		    System.out.println("8. Salir.");

		    opcion = teclado.nextInt();
		    
		    switch (opcion) {
		    
		    case 1:
		    	teclado.nextLine();
			    System.out.println("Introduzca nombre: ");
				nombre = teclado.nextLine();
				System.out.println("Introduzca apellido: ");
				apellido = teclado.nextLine();
				System.out.println("Introduzca salario: ");
				salario = teclado.nextDouble();
				System.out.println("Introduzca id del dep: ");  
				id_dep = teclado.nextInt();
				emp = new Empleado(nombre, apellido, salario, id_dep);
				//comprobar si existe id_dep
				try{
					if(sis.comprobarIdDep(id_dep)) {
						
						try {
							sis.anyadirEmpleadoaFichero(emp);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					//si no existe, crearlo
					else {
						teclado.nextLine();
						System.out.println("Departamento no existente, crealo");
						System.out.println("Introduzca id del departamento: ");
						id_dep = teclado.nextInt();
						teclado.nextLine();
						System.out.println("Introduzca nombre del departamento: ");
						nombre_dep = teclado.nextLine();
						System.out.println("Introduzca el presupuesto del departamento: ");
						presupuesto = teclado.nextDouble();
						dep = new Departamento(id_dep,nombre_dep, presupuesto);
						sis.anyadirDepartamentoaFichero(dep);
						sis.anyadirEmpleadoaFichero(emp);
					}
				}
				catch(IOException a) {
					a.printStackTrace();
				}
				
			    break;
		    case 2:
		    	teclado.nextLine();
		    	System.out.println("Introduzca id del departamento: ");
				id_dep = teclado.nextInt();
				teclado.nextLine();
				System.out.println("Introduzca nombre del departamento: ");
				nombre_dep = teclado.nextLine();
				System.out.println("Introduzca el presupuesto del departamento: ");
				presupuesto = teclado.nextDouble();
				dep = new Departamento(id_dep,nombre_dep, presupuesto);
				try {
					sis.anyadirDepartamentoaFichero(dep);
				} catch (IOException e) {
					e.printStackTrace();
				}
		    	break;
		    	
		    case 3:
		    	teclado.nextLine();
		    	System.out.println("Introduzca nombre del departamento: ");
				nombre_dep = teclado.nextLine();
				try {
					sis.mostrarDatosDepartamento(nombre_dep);
				} catch (IOException e) {
					e.printStackTrace();
				}
		    	break;
		    case 4:
		    	try {
					sis.mostrarNombreTrabajadorMejorPagado();
					//coje mal el nombre del departamento
				} catch (IOException e) {
					e.printStackTrace();
				}
		    	break;
		    case 5:
		    	teclado.nextLine();
		    	System.out.println("Introduzca nombre departamento a borrar: ");
		    	nombre = teclado.nextLine();
		    	try {
					sis.borrarDepartamento(nombre);
				} catch (IOException e) {
					e.printStackTrace();
				}
		    	break;	
		    case 6:
		    	try {
					sis.aumentarSalario();
					//no guardan los datos bien
				} catch (IOException e) {
					e.printStackTrace();
				}
		    	break;
		    case 7:
		    	//crear fichero conjunto
		    	break;
		    case 8:
		    	System.out.println("Adios.");
		    	break;
		    default:
		    	System.out.println("Opcion erronea");
		    	
		    	
		    }



		}
	}
}
