package Ejercicio2Ficheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class Sistema {
	public void anyadirEmpleadoaFichero(Empleado e) throws IOException{
		File f = new File("src/Ejercicio2Ficheros/Empleados.txt");
		BufferedWriter out = null;
		String empleado="";
		try {
    		
		    empleado = Empleado.getId() + "," + e.getNombre() +"," + e.getApellido() + "," +e.getSalario() + "," +e.getId_dep();
		   
		    out = new BufferedWriter(new FileWriter(f.getAbsoluteFile(), true));
		  
		    out.write(empleado);
		    out.write("\n");
    	}catch(IOException a) {
    		a.printStackTrace();
    	}
    	out.close();
	}
	public boolean comprobarIdDep(int id_dep) throws IOException {
		FileReader f = new FileReader("src/Ejercicio2Ficheros/Departamentos.txt");
		BufferedReader in = null;
		int id=0;
		try {
			in = new BufferedReader(f);

            String l;
           
            while ((l = in.readLine()) != null) {
            	/*String id = l.substring(0,l.indexOf((","),0):
            	 * */
	           	StringTokenizer tok = new StringTokenizer(l, ",");
	            id = Integer.parseInt(tok.nextToken());
	           	if(id == id_dep) {
	           		return true;
	           	}
            }
       
		} catch (Exception e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			in.close();
            
        }
		
		return false;
	}
	public void anyadirDepartamentoaFichero(Departamento d) throws IOException {
		File f = new File("src/Ejercicio2Ficheros/Departamentos.txt");
		BufferedWriter out = null;
		String departamento="";
		try {
    		
		    departamento = d.getId() + "," + d.getNombre() +"," +d.getPresupuesto();
		   
		    out = new BufferedWriter(new FileWriter(f.getAbsoluteFile(), true));
		  
		    out.write(departamento);
		    out.write("\n");
    	}catch(IOException a) {
    		a.printStackTrace();
    	}finally{
    		out.close();
    	}
	}
	
	public void mostrarDatosDepartamento(String nombre) throws IOException{
		File f = new File("src/Ejercicio2Ficheros/Departamentos.txt");
		File fl = new File("src/Ejercicio2Ficheros/Empleados.txt");
		BufferedReader in=null, in2 = null;
		String l="", s="", nombre2 = "", nombre3="", apellido = "";
		double salario = 0;
		int id=0, id_dep=0, id_emp=0;
		try {
    		
		    in = new BufferedReader(new FileReader(f.getAbsoluteFile()));
		    in2 = new BufferedReader(new FileReader(fl.getAbsoluteFile()));
		    
		    while((l = in.readLine()) != null) {
		    	StringTokenizer tok = new StringTokenizer(l, ",");
		    	id = Integer.parseInt(tok.nextToken());
		    	nombre2 = tok.nextToken();
		    	if(nombre.equals(nombre2)) {
		    		while((s = in2.readLine()) != null) {
		    			StringTokenizer tk = new StringTokenizer(s, ",");
		    			id_emp = Integer.parseInt(tk.nextToken());
		    			nombre3 = tk.nextToken();
		    			apellido = tk.nextToken();
		    			salario = Double.parseDouble(tk.nextToken());
		    			id_dep = Integer.parseInt(tk.nextToken());
		    			if(id == id_dep) {
		    				System.out.println("Id: " +id_emp +" Nombre: "+nombre3 + " Apellido: "+ apellido + " Salario: " + salario + " Id_dep: " +id_dep);
		    			}
		    		}
		    	}
		    }
		
    	}catch(IOException a) {
    		a.printStackTrace();
    	}finally{
    		in.close();
    		in2.close();
    	}
	}
	
	public void mostrarNombreTrabajadorMejorPagado() throws IOException{
		File f = new File("src/Ejercicio2Ficheros/Departamentos.txt");
		File fl = new File("src/Ejercicio2Ficheros/Empleados.txt");
		BufferedReader in=null, in2 = null;
		String l="", s="", nombre2 = "", nombre3="", apellido = "", res = "";
		double salario = 0, mayor = 0;
		int id=0, id_dep=0, id_emp=0;
		try {
    		
		    in = new BufferedReader(new FileReader(f.getAbsoluteFile()));
		    in2 = new BufferedReader(new FileReader(fl.getAbsoluteFile()));
			s = in2.readLine();
    		StringTokenizer tk2 = new StringTokenizer(s, ",");
    		id_emp = Integer.parseInt(tk2.nextToken());
    		nombre3 = tk2.nextToken();
    		apellido = tk2.nextToken();
    		salario = Double.parseDouble(tk2.nextToken());
    		id_dep = Integer.parseInt(tk2.nextToken());
    		mayor = salario;
    		
		    while((l = in.readLine()) != null) {
		    	StringTokenizer tok = new StringTokenizer(l, ",");
		    	id = Integer.parseInt(tok.nextToken());
		    	nombre2 = tok.nextToken();
		    	while((s = in2.readLine()) != null) {
		    			StringTokenizer tk = new StringTokenizer(s, ",");
		    			id_emp = Integer.parseInt(tk.nextToken());
		    			nombre3 = tk.nextToken();
		    			apellido = tk.nextToken();
		    			salario = Double.parseDouble(tk.nextToken());
		    			id_dep = Integer.parseInt(tk.nextToken());
		    			if(salario >= mayor) {
		    				mayor = salario;
		    				res = nombre2;
		    			}
		    		}
		    	 in2 = new BufferedReader(new FileReader(fl.getAbsoluteFile()));
		    	}
		    
    	}catch(IOException a) {
    		a.printStackTrace();
    	}finally{
    		System.out.println("Nombre Departamento: " +res + " Salario: " + mayor);
    		in.close();
    		in2.close();
    	}
	}
	public void borrarDepartamento(String nombre) throws IOException{
		PrintWriter pw = null;
		File fl = new File("src/Ejercicio2Ficheros/Departamentos.txt");
		BufferedReader in=null;
		File temp = new File(fl.getAbsolutePath() + ".tmp");
		int id=0;
		String nom="";
		try {
			in = new BufferedReader(new FileReader("src/Ejercicio2Ficheros/Departamentos.txt"));
			pw = new PrintWriter(new FileWriter(temp));
			String l;

			while ((l = in.readLine()) != null) {
				StringTokenizer tok = new StringTokenizer(l, ",");
				id = Integer.parseInt(tok.nextToken());
				nom = tok.nextToken();
				if (!nombre.equals(nom)) {
					pw.println(l);
					pw.flush();
				}
//falta borrar los empleados con ese mismo id del departamento
			}
		} finally {
			if (in != null) {
				in.close();
			}
			pw.close();

			if (!fl.delete()) {
				System.out.println("No se ha podido eliminar");
				return;
			}

			if (!temp.renameTo(fl)) {
				System.out.println("No se ha podido renombrar");

			}

		}
	}
	public void aumentarSalario() throws IOException {
		File f = new File("src/Ejercicio2Ficheros/Empleados.txt");
		File temp = new File(f.getAbsolutePath() + ".tmp");
		PrintWriter out = null;
		BufferedReader in=null;
		int id_emp=0, id_dep=0, cont=0;
		String nombre="", apellido = "";
		double salario=0, suma=0, media=0;
		String empleado = "";
		try {
			in = new BufferedReader(new FileReader(f.getAbsoluteFile()));
			out =  new PrintWriter(new FileWriter(temp));
			  
			String s;
			while((s = in.readLine()) != null) {
    			StringTokenizer tk = new StringTokenizer(s, ",");
    			id_emp = Integer.parseInt(tk.nextToken());
    			nombre = tk.nextToken();
    			apellido = tk.nextToken();
    			salario = Double.parseDouble(tk.nextToken());
    			id_dep = Integer.parseInt(tk.nextToken());
    			suma+=salario;
    			cont++;
			}
			media = suma / cont;
			in = new BufferedReader(new FileReader(f.getAbsoluteFile()));
			
			String l;
			while((l = in.readLine()) != null) {
    			StringTokenizer tk = new StringTokenizer(l, ",");
    			id_emp = Integer.parseInt(tk.nextToken());
    			nombre = tk.nextToken();
    			apellido = tk.nextToken();
    			salario = Double.parseDouble(tk.nextToken());
    			id_dep = Integer.parseInt(tk.nextToken());
    			if(salario < media) {
    				salario = salario + (salario*0.1);
    			}
    			empleado = id_emp + "," + nombre +"," + apellido + "," +salario + "," +id_dep;
    			
    			out.println(empleado);
				out.flush();
			}
			
		}finally {
			if (in != null) {
				in.close();
			}
			if(out != null) {
				out.close();
			}
			if (!f.delete()) {
				System.out.println("No se ha podido eliminar");
				return;
			}

			if (!temp.renameTo(f)) {
				System.out.println("No se ha podido renombrar");

			}
		}
	
	}
}
