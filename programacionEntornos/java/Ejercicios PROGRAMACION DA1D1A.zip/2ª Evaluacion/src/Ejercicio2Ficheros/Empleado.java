package Ejercicio2Ficheros;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Empleado {
	//id,nombre,apellido,salario, id_dep
	private static int id=1;
	private String nombre;
	private String apellido;
	private double salario;
	private int id_dep;
	
	public Empleado(String nombre, String apellido, double salario, int id_dep) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.salario = salario;
		this.id_dep = id_dep;
		id++;
	}

	public static int getId() {
		return id;
	}

	public static void setId(int id) {
		Empleado.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getId_dep() {
		return id_dep;
	}

	public void setId_dep(int id_dep) {
		this.id_dep = id_dep;
	}
	
	
	
}
