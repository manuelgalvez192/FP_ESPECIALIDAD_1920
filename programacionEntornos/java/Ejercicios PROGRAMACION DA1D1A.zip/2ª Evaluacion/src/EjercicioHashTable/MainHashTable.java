package EjercicioHashTable;

import java.util.Hashtable;

public class MainHashTable {

	public static void main(String[] args) {
		//1. A partir de un array de palabras, crear un HashTable con todas las palabras diferentes y 
		//cu�ntas veces aparece cada una.
		String[] palabras = {"Juan", "Luis", "Pablo", "Juan", "Luis", "Carlos", "Antonio", "David", "Iv�n", "Juan"};
		
		Hashtable<String, Integer> res = new Hashtable<>();
		int rep=0;
		
		
		for(int j=0; j<palabras.length; j++) {
			if(res.containsKey(palabras[j])) {
				
				res.put(palabras[j], res.get(palabras[j])+1);
				
				
			}
			else {
				res.put(palabras[j],1);
			}
			 
		}
				
		System.out.println(res.toString());
	}

}
