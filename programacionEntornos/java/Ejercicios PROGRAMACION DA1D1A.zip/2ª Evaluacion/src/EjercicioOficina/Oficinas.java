package EjercicioOficina;

import java.util.ArrayList;

/*Crear una aplicaci�n que permita trabajar con datos de empleados de una empresa que tiene distintas oficinas. 
 * Para ello se usar� un ArrayList de ArrayList de Empleado. 
 * Las oficinas quedar�n identificadas por un n�mero que coincidir� con el �ndice del ArrayList usado. 
 * Cada elemento de ese ArrayList ser� un ArrayList de empleados. As� sabremos dentro de una oficina qui�n trabaja.
 * Datos de los empleados: nombre, apellidos, salario. 



Operaciones: 

1. A�adir empleado a oficina

2. Borrar empleado de una oficina

3. Cambiar a empleado de oficina

4. Listar empleados de una oficina

5. A�adir oficina (sin empleados)

6. Borrar oficina*/

public class Oficinas {
	private int id;
	private static int i=0;
	private ArrayList<Empleado> empleados = new ArrayList<>();
	
	public Oficinas(ArrayList<Empleado> empleados) {
		this.id = i;
		this.empleados = empleados;
		i++;
	}

	public ArrayList<Empleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(ArrayList<Empleado> empleados) {
		this.empleados = empleados;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void addEmpleado(Empleado e1) {
		int pos = 0;
		for(Empleado e2: this.empleados) {
			if(e2 == null) {
				this.empleados.set(pos,e1);
				return;
			}
			pos++;
		}
		
	}
	
	public void removeEmpleado(String nombre, String apellido) {
		int pos = 0;
		for(Empleado e2: this.empleados) {
			if(e2.getNombre().equals(nombre)) {
				if(e2.getApellidos().equals(apellido)) {
					this.empleados.set(pos,null);
					return;
				}
				pos++;
			}
			pos++;
		}
	}
	
	public void listarEmpleados() {
		for(Empleado e1: this.empleados) {
			if(e1 != null) {
				System.out.println(e1.toString());
			}
		}
	}
	
}


