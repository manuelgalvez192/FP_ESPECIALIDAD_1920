package EjercicioOficina;

import java.util.ArrayList;

public class SistemaOficinas {
	private ArrayList<Oficinas> oficinas = new ArrayList<>();

	public SistemaOficinas(ArrayList<Oficinas> oficinas) {
		this.oficinas = oficinas;
	}

	public ArrayList<Oficinas> getOficinas() {
		return oficinas;
	}

	public void setOficinas(ArrayList<Oficinas> oficinas) {
		this.oficinas = oficinas;
	}
	
	public void crearOficina() {
		oficinas.add(new Oficinas(null));
	}
	
	public void addOficina(Oficinas of) {
		oficinas.add(of);
	}
	
	public void cambiarEmpleado(Empleado e1, int id) {
		for(Oficinas o2: this.oficinas) {
			if(id == o2.getId()) {
				o2.addEmpleado(e1);
			}
			for(Empleado e2: o2.getEmpleados()) {
				if(e2.equals(e1)) {
					o2.removeEmpleado(e2.getNombre(), e2.getApellidos());
				}
			}
			
		}
	}
	public void eliminarOficina(int id) {
		for(Oficinas of: this.oficinas) {
			if(of.getId() == id) {
				this.oficinas.set(id, null);
				return;
			}
		}
	}
	
}
