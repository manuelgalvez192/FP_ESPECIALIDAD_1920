package EjercicioOficina;

import java.util.ArrayList;

//Ejemplo con ArrayList de ArrayList en vez de Oficinas
public class Empresa {
	private ArrayList<ArrayList<Empleado>> lista;

	public Empresa() {
		this.lista = new ArrayList<>();
	}
	
	public void crearOficina() {
		lista.add(new ArrayList<Empleado>());
	}
	
	public boolean a�adirEmpleado(int id, Empleado e) {
		boolean res=false;
		if((id>=0)&&(id<lista.size())) {
			lista.get(id).add(e);
			res = true;
		}
		return res;
	}
	
}
