package EjercicioOficina;

import java.util.ArrayList;
import java.util.Scanner;

public class MainOficinas {
	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		
		ArrayList<Empleado> empleados = new ArrayList<>();
		for(int i=0; i<200;i++) {
			empleados.add(i, null);
		}
		SistemaOficinas sis = new SistemaOficinas(new ArrayList<Oficinas>());
		Oficinas of = new Oficinas(empleados);
		sis.addOficina(of);
		int opcion=0, id=0;
		String nombre, apellido;
		double salario=0;
		Empleado e1 = null;
		
		while(opcion != 7) {
			System.out.println("Elija opcion: ");
			System.out.println("1. A�adir Empleado");
			System.out.println("2. Eliminar Empleado");
			System.out.println("3. Cambiar a empleado de oficina");
			System.out.println("4. Listar empleados de una oficina");
			System.out.println("5. A�adir oficina (sin empleados)");
			System.out.println("6. Borrar oficina");
			System.out.println("7. Salir");
			opcion = teclado.nextInt();
			
			switch(opcion) {
			
			case 1:
				teclado.nextLine();
				System.out.println("Introduzca el nombre del empleado: ");
				nombre = teclado.nextLine();
				System.out.println("Introduzca el apellido del empleado: ");
				apellido = teclado.nextLine();
				System.out.println("Introduzca el salario del empleado: ");
				salario = teclado.nextDouble();
				
				e1 = new Empleado(nombre, apellido, salario);
				System.out.println("Introduzca id de la oficina donde a�adirlo: ");
				id = teclado.nextInt();
				sis.getOficinas().get(id).addEmpleado(e1);
				break;
			case 2:
				teclado.nextLine();
				System.out.println("Introduzca el nombre del empleado: ");
				nombre = teclado.nextLine();
				System.out.println("Introduzca el apellido del empleado: ");
				apellido = teclado.nextLine();
				
				System.out.println("Introduzca id de la oficina de donde eliminarlo: ");
				id = teclado.nextInt();
				sis.getOficinas().get(id).removeEmpleado(nombre, apellido);
				break;
			case 3:
				teclado.nextLine();
				System.out.println("Introduzca el nombre del empleado: ");
				nombre = teclado.nextLine();
				System.out.println("Introduzca el apellido del empleado: ");
				apellido = teclado.nextLine();
				System.out.println("Introduzca el salario del empleado: ");
				salario = teclado.nextDouble();
				
				e1 = new Empleado(nombre, apellido, salario);
				System.out.println("Id de la oficina donde desea cambiarlo: ");
				id = teclado.nextInt();
				sis.cambiarEmpleado(e1, id);
				
				break;
			case 4:
				System.out.println("Id de la oficina a listar sus empleados: ");
				id = teclado.nextInt();
				
				sis.getOficinas().get(id).listarEmpleados();
				break;
			case 5:
				sis.crearOficina();
				break;
			case 6:
				System.out.println("Introduzca id de la oficina a eliminar: ");
				id = teclado.nextInt();
				
				sis.eliminarOficina(id);
				break;
			case 7:
				System.out.println("Adios");
				break;
			default:
				System.out.println("Error de numero");
				
			}
		
		}

		teclado.close();
	}
}
