package EjerciciosPila;

import java.util.*;

public class PilaObject {
	//Pila a�adir sacar y ver si esta vacia
		//Interfaz
	public static void main(String[] args) {
		
		 Stack<String> pila = new Stack<String>();
		 Scanner teclado = new Scanner(System.in);
		 pila.push("Adios");
		 int opcion = 0;
		 String palabra = "";
		 
		 while(opcion != 4) {
			 System.out.println("Elija opcion: ");
			 System.out.println("1. A�adir a la pila");
			 System.out.println("2. Sacar de la pila");
			 System.out.println("3. Ver si esta vacia");
			 System.out.println("4. Salir");
			 opcion = teclado.nextInt();
			 
			 switch(opcion) {
			 
			 case 1:
				 teclado.nextLine();
				 System.out.println("Introduzca palabra a introducir: ");
				 palabra = teclado.nextLine();
				 pila.push(palabra);
				 System.out.println("Pila: "+ pila.toString());
				 break;
				 
			 case 2:
				 palabra = pila.pop();
				 System.out.println("Ultimo elemento de la pila: " + palabra);
				 break;
			 case 3:
				 if(pila.empty()) {
					 System.out.println("Esta vacia");
				 }
				 else {
					 System.out.println("No esta vacia");
				 }
				 break;
			 case 4:
				 System.out.println("Hasta luego");
				 break;
			 }
		 }
		
		teclado.close();
	}

}
