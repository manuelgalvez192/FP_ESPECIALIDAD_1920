package EjerciciosPila;

import java.util.ArrayList;

public class Pila {
	private int pos;
	private ArrayList<String> stack;
	
	public Pila() {
		this.pos = -1;
		this.stack = new ArrayList<>();
		for(int i=0; i<20; i++) {
			this.stack.add(i, " ");
		}
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public ArrayList<String> getStack() {
		return stack;
	}

	public void setStack(ArrayList<String> stack) {
		this.stack = stack;
	}
	
	public void push(String palabra) {
		this.pos++;
		this.stack.set(pos, palabra);
	}
	
	public String pop() {
		String palabra;
		
		if(isEmpty()) {
			return "Vacia";
		}
				
		palabra = this.stack.get(pos);
		this.pos--;
		
		return palabra;
	}
	
	public boolean isEmpty() {
		if(this.pos == -1) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public String toString() {
		return " Pos: " + pos + " Elementos: " + stack;
	}
	
}
