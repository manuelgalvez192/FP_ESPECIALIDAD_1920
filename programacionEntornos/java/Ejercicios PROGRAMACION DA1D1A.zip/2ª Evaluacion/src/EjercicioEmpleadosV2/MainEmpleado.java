package EjercicioEmpleadosV2;

import java.util.ArrayList;
import java.util.Scanner;


//-Para cada valor de n�mero de acciones existentes en la lista de empleados, mostrar cu�ntos empleados hay.Por ejemplo:
//     N�mero de acciones     Cantidad de empleados con esas acciones
//			2							1				
//			3							25	
//			7							10
//			10							12
public class MainEmpleado {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		ArrayList<Empleado> empleados = new ArrayList<>();
		ArrayList<Empleado> aux = new ArrayList<>();
		Sistema sis = new Sistema(empleados);
		int opcion=0, opcion2 = 0;
		String nombre, apellido;
		String email1, email2;
		int tfno=0, tfno2=0;
		int id=0,i=0, acciones=0;
		int[][] res2 = new int[1000][1000];
		double salario=0, productividad=0;
		boolean res=false;
		Empleado e1 = null, e2=null, e3=null;
		
		for(int k=0;k<1000;k++) {
			empleados.set(k,null);
		}
		
		for(int k=0;k<1000;k++) {
			aux.set(k,null);
		}
		
		while(opcion != 16) {
			System.out.println("Elija su opcion: ");
			System.out.println("1. A�adir Empleado");
			System.out.println("2. Modificar Tfno");
			System.out.println("3. Modificar Email");
			System.out.println("4. Modificar Salario");
			System.out.println("5. Borrar Empleado");
			System.out.println("6. Listar Empleados ordenados alfabeticamente por Apellido");
			System.out.println("7. Listar Empleados ordenados alfabeticamente por Apellido y Nombre");
			System.out.println("8. Listar Empleados ordenados de menor a mayor por Salario");
			System.out.println("9. Ver Empleados");
			System.out.println("10. Listar Empleados ordenados por n�mero de acciones de menor a mayor");
			System.out.println("11. Listar Empleados ordenados por productividad de mayor a menor");
			System.out.println("12. Mostrar el Empleado con menor productividad");
			System.out.println("13. Mostrar el Empleado con mayor n�mero de acciones");
			System.out.println("14. Mostrar los Empleados con una productividad entre 1000 y 2000");
			System.out.println("15. N�mero de acciones existentes en la lista de empleados, mostrar cu�ntos empleados hay");
			System.out.println("16. Salir");
			opcion = teclado.nextInt();
			
			switch(opcion) {
			
			case 1:
				while(opcion2 != 3) {
					System.out.println("Elija opcion: ");
					System.out.println("1. Nuevo Gerente");
					System.out.println("2. Nuevo Comercial");
					System.out.println("3. Salir");
					opcion2 = teclado.nextInt();
					
					switch(opcion2) {
					
					case 1:
						int[] tfnos = new int[3];
						String[] emails = new String[5];
						teclado.nextLine();
						System.out.println("Introduzca el nombre del empleado: ");
						nombre = teclado.nextLine();
						System.out.println("Introduzca el apellido del empleado: ");
						apellido = teclado.nextLine();
						System.out.println("Introduzca un telefono del empleado: ");
						tfnos[i] = teclado.nextInt();
						teclado.nextLine();
						System.out.println("Introduzca un email del empleado: ");
						emails[i] = teclado.nextLine();
						System.out.println("Introduzca el salario del empleado: ");
						salario = teclado.nextDouble();
						System.out.println("Introduzca numero de acciones del Gerente: ");
						acciones = teclado.nextInt();
						e1 = new Gerente(nombre, apellido, tfnos, emails, salario, acciones);
						res = sis.anyadirEmpleado(e1);
						if(res) {
							System.out.println("Empleado a�adido con exito");
						}
						break;
					case 2:
						int[] tfnoss = new int[3];
						String[] emailss = new String[5];
						teclado.nextLine();
						System.out.println("Introduzca el nombre del empleado: ");
						nombre = teclado.nextLine();
						System.out.println("Introduzca el apellido del empleado: ");
						apellido = teclado.nextLine();
						System.out.println("Introduzca un telefono del empleado: ");
						tfnoss[i] = teclado.nextInt();
						teclado.nextLine();
						System.out.println("Introduzca un email del empleado: ");
						emailss[i] = teclado.nextLine();
						System.out.println("Introduzca el salario del empleado: ");
						salario = teclado.nextDouble();
						System.out.println("Introduzca productividad del Comercial: ");
						productividad = teclado.nextInt();
						e1 = new Comercial(nombre, apellido, tfnoss, emailss, salario, productividad);
						res = sis.anyadirEmpleado(e1);
						if(res) {
							System.out.println("Empleado a�adido con exito");
						}
						break;
						
					case 3:
						System.out.println("Vuelve al men� principal");
						break;
					default:
						System.out.println("Opcion erronea");
					}
				}
				opcion2 = 0;
				break;
			case 2:
				System.out.println("Introduzca id del empleado");
				id = teclado.nextInt();
				System.out.println("Introduzca telefono a modificar: ");			
				tfno = teclado.nextInt();
				System.out.println("Introduzca nuevo telefono");
				tfno2 = teclado.nextInt();
							
				e2 = sis.buscarEmpleado(id);
				if(e2 == null) {
					System.out.println("Empleado no encontrado");
				}
				else {
					e2.modificarTfno(sis, id, tfno, tfno2);
				}
				
				System.out.println(e2.toString());
				break;
			case 3:
				System.out.println("Introduzca id del empleado");
				id = teclado.nextInt();
				teclado.nextLine();
				System.out.println("Introduzca email a modificar: ");			
				email1 = teclado.nextLine();
				System.out.println("Introduzca nuevo email");
				email2 = teclado.nextLine();
							
				e2 = sis.buscarEmpleado(id);
				if(e2 == null) {
					System.out.println("Empleado no encontrado");
				}
				else {
					e2.modificarEmail(sis, id, email1, email2);
				}
				
				System.out.println(e2.toString());
				break;
			case 4:
				System.out.println("Introduzca id del empleado");
				id = teclado.nextInt();
				System.out.println("Introduzca nuevo salario");
				salario = teclado.nextDouble();		
				e2 = sis.buscarEmpleado(id);
				if(e2 == null) {
					System.out.println("Empleado no encontrado");
				}
				else {
					e2.modificarSalario(sis, id, salario);
				}
				break;
			case 5:
				System.out.println("Introduzca id del empleado");
				id = teclado.nextInt();
				res = sis.borrarEmpleado(id);
				if(res) {
					System.out.println("Empleado borrado con exito");
				}
				break;
			case 6:	
				sis.ordenarApellido();
				break;
			case 7:
				sis.ordenarApellidoNombre();
				break;
			case 8:
				sis.ordenarSalario();
				break;
			case 9:
				sis.listarEmpleados();
				break;
			case 10:
				sis.ordenarAcciones();
				break;
			case 11:
				sis.ordenarProduc();
				break;
			case 12:
				e3 = sis.menorProductividad();
				System.out.println("Empleado con menos productividad: " + e3.toString());
				break;
			case 13:
				e3 = sis.mayorAcciones();
				System.out.println("Empleado con m�s acciones: " + e3.toString());
				break;
			case 14:
				aux = sis.rangoProductividad();
				for(Empleado e5: aux) {
					if(e5 != null) {
						System.out.println(e5.toString());
					}
				}
				break;
			case 15:
				res2 = sis.numAccionesPorEmpleado();
				for(int j=0; j<res2.length;j++) {
					for(int k=0; k<res2[i].length;k++) {
						System.out.print(res2[i][j] + " ");
					}
					System.out.println();
				}
				break;
			case 16:
				System.out.println("Adios");
				break;
			default:
				System.out.println("Opci�n erronea");
				
			}
		}
		
		
		teclado.close();

	}

}
