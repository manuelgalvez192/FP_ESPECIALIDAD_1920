package EjercicioEmpleadosV2;

import java.util.ArrayList;
import java.util.Arrays;

public class Sistema {
	private ArrayList<Empleado> empleados;
	private int numEmple;
	
	public Sistema(ArrayList<Empleado> empleados) {
		
		this.empleados = empleados;
		this.numEmple = 0;
	}

	public ArrayList<Empleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(ArrayList<Empleado> empleados) {
		this.empleados = empleados;
	}

	public int getNumEmple() {
		return numEmple;
	}

	public void setNumEmple(int numEmple) {
		this.numEmple = numEmple;
	}
	
	public boolean anyadirEmpleado(Empleado e1) {
		if(this.numEmple != this.empleados.size()) {
			for(Empleado e2: this.getEmpleados()) {
				if(e2 == null) {
					this.empleados.set(numEmple, e1 );
					numEmple++;
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean borrarEmpleado(int id) {
		int pos=0;
		for(Empleado e1: this.getEmpleados()) {
			if(e1 != null) {
				if(e1.getId() == id) {
					this.empleados.set(pos, null);
					this.numEmple--;
					return true;
				}
			}
			
		}
		return false;
	}
	
	public Empleado buscarEmpleado(int id) {
		Empleado e2 = null;
		for(Empleado e1: this.getEmpleados()) {
			if(e1.getId() == id) {
				e2 = e1;
				return e2;
			}
		}
		return e2;
	}
	public void ordenarApellido() {
		Empleado[] aux = new Empleado[1000];
		System.arraycopy(this.empleados, 0, aux, 0, 999);
		Arrays.sort(aux, new ComparadorEmpleadoApellido());
		for(Empleado e1: aux) {
			if(e1 != null) {
				System.out.println(e1.toString());
			}
			
		}
	}
	
	public void ordenarApellidoNombre() {
		Empleado[] aux = new Empleado[1000];
		System.arraycopy(this.empleados, 0, aux, 0, 999);
		Arrays.sort(aux, new ComparadorEmpleadoNombre());
		for(Empleado e1: aux) {
			if(e1 != null) {
				System.out.println(e1.toString());
			}
			
		}
	}
	
	public void ordenarSalario() {
		Empleado[] aux = new Empleado[1000];
		System.arraycopy(this.empleados, 0, aux, 0, 999);
		Arrays.sort(aux, new ComparadorEmpleadoSalario());
		for(Empleado e1: aux) {
			if(e1 != null) {
				System.out.println(e1.toString());
			}
			
		}
	}
		
	public void ordenarAcciones() {
		Empleado[] aux = new Empleado[1000];
		System.arraycopy(this.empleados, 0, aux, 0, 999);
		Arrays.sort(aux, new ComparadorEmpleadoAcciones());
		for(Empleado e1: aux) {
			if(e1 != null) {
				System.out.println(e1.toString());
			}
			
		}
	}
	
	public void ordenarProduc() {
		Empleado[] aux = new Empleado[1000];
		System.arraycopy(this.empleados, 0, aux, 0, 999);
		Arrays.sort(aux, new ComparadorEmpleadoProduc());
		for(Empleado e1: aux) {
			if(e1 != null) {
				System.out.println(e1.toString());
			}
			
		}
	}
	
	public Empleado menorProductividad() {
		Empleado aux = null;
		aux = this.empleados.get(0);
		
		for(Empleado e1: this.empleados) {
			if(e1 instanceof Comercial) {
				if(aux instanceof Comercial) {
					if(((Comercial)aux).getProductividad() > ((Comercial)e1).getProductividad()) {
						aux = e1;
					}
				}
				else {
					aux = e1;
				}
			}
		}
		
		return aux;
	}
	
	public Empleado mayorAcciones() {
		Empleado aux = null;
		aux = this.empleados.get(0);
		
		for(Empleado e1: this.empleados) {
			if(e1 instanceof Gerente) {
				if(aux instanceof Gerente) {
					if(((Gerente)aux).getNumAcciones() < ((Gerente)e1).getNumAcciones()) {
						aux = e1;
					}
				}
				else {
					aux = e1;
				}
			}
		}
		
		return aux;
	}
	
	public ArrayList<Empleado> rangoProductividad() {
		ArrayList<Empleado> aux = new ArrayList<>();
		int pos = 0;
		for(int k=0;k<1000;k++) {
			aux.set(k,null);
		}
		
		for(Empleado e1: this.empleados) {
			if(e1 instanceof Comercial) {
				if(((Comercial)e1).getProductividad() >= 1000 && ((Comercial)e1).getProductividad() <= 2000) {
					aux.set(pos, e1);
					pos++;
				}
			}
		}
		
		return aux;
	}
	
	public int[][] numAccionesPorEmpleado(){
		int pos = 0, cont=0;
		int acciones=0;
		int[][]res = new int[1000][2];
		
		for(int i=0; i<this.empleados.size();i++) {
			if(this.empleados.get(i) instanceof Gerente) {
				res[pos][i] = ((Gerente)this.empleados.get(pos)).getNumAcciones();
				acciones = ((Gerente)this.empleados.get(pos)).getNumAcciones();
				for(int j=1; j<this.empleados.size();j++) {
					if(this.empleados.get(j) instanceof Gerente) {
						if(acciones == ((Gerente)this.empleados.get(j)).getNumAcciones()) {
							cont++;
							
						}
						res[pos][j] = cont;
					}
					
				}
				
				pos++;
			}
			
		}
		return res;
	}
	
	public void listarEmpleados() {
		for(Empleado e1: this.getEmpleados()) {
			if(e1 != null) {
				System.out.println(e1.toString());
			}
			
		}
	}
	
}
