package EjercicioEmpleadosV2;

import java.util.Comparator;

public class ComparadorEmpleadoAcciones implements Comparator<Empleado>{

	@Override
	public int compare(Empleado o1, Empleado o2) {
		if(o1 != null && o2 != null) {
			if(o1 instanceof Gerente && o2 instanceof Gerente) {
				if(((Gerente) o1).getNumAcciones() < ((Gerente) o2).getNumAcciones()) {
					return -1;
				}
				if(((Gerente) o1).getNumAcciones() > ((Gerente) o2).getNumAcciones()) {
					return 1;
				}
			}
		}
		return 0;
	}

}
