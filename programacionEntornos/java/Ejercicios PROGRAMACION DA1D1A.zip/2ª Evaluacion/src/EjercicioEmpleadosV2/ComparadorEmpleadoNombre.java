package EjercicioEmpleadosV2;

import java.util.Comparator;

public class ComparadorEmpleadoNombre implements Comparator<Empleado>{

	@Override
	public int compare(Empleado o1, Empleado o2) {
		if(o1 != null && o2 != null) {
			if(o1.getApellido().compareTo(o2.getApellido()) < 0) {
				return -1;						
			}
			else if(o1.getApellido().compareTo(o2.getApellido()) > 0) {
				return 1;
			}
			else {
				if(o1.getNombre().compareTo(o2.getNombre()) < 0) {
					return -1;
				}
				else if(o1.getNombre().compareTo(o2.getNombre()) > 0) {
					return 1;
				}
				else {
					return 0;
				}
			}
				
		}
		return 0;
	}

}
