package EjerciciosArrayList;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Lista {
	
	/*Lo mismo que en EjemploArrayList pero hecho por el profesor con Iterator en algunos sitios*/
	
	public static void main(String[] args) {
		ArrayList<Integer> lista = new ArrayList<>();
		Scanner teclado = new Scanner(System.in);
		int numero =0, suma=0;
		
		for(int i=0;i<10;i++) {
			System.out.println("Numero: ");
			numero = teclado.nextInt();
			lista.add(new Integer(numero));
		}
		Iterator<Integer> i = lista.iterator();
		while(i.hasNext()) {
			System.out.println(i.next().intValue());
		}
		
		for(Integer entero: lista) {
			numero = entero.intValue();
			if(numero < 0) {
				System.out.println(numero);
			}
		}
		
		for(int j=0; j<lista.size();j++) {
			numero = lista.get(j);
			if(numero > 0) {
				System.out.println(numero);
			}
		}
		
		for(int j=0;j<lista.size();j++) {
			numero = lista.get(j).intValue();
			suma += numero;
		}
		System.out.println("Suma:  "+suma);
		teclado.close();
	}

}