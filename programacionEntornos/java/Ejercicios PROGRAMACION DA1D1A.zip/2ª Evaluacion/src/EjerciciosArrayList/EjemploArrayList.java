package EjerciciosArrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class EjemploArrayList{

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		 // declares an array of integers
        ArrayList<Integer> anArray = new ArrayList<>();
        int suma = 0, cont=0, num=0, pos=0, num2=0;
        ArrayList<Integer> array2 = new ArrayList<>(); 
        // initialize first element
        anArray.add(100);
        anArray.add(200);
        anArray.add(300);
        anArray.add(400);
        anArray.add(-500);
        anArray.add(600);
        anArray.add(700);
        anArray.add(-800);
        anArray.add(900);
        anArray.add(1000);
        
        System.out.println("Contenido ArrayList: " +anArray.toString());
        
        for(Integer i1: anArray) {
        	if(i1 < 0) {
        		cont++;
        	}
        }

        System.out.println("Negativos: " +cont);
        
        for(int i=0;i<anArray.size();i++) {
        	suma += anArray.get(i);
        }
        System.out.println("Suma: " + suma);
        
        for(int i=anArray.size()-1;i>-1;i--) {
        	System.out.println("Elementos at index "+i+" reverse: "+ anArray.get(i));
        }
        
        int mayor = anArray.get(0);
        for(int i=0;i<anArray.size();i++) {
        	if(anArray.get(i) > mayor) {
        		mayor = anArray.get(i);
        	}
        }
        System.out.println("Mayor: "+mayor);
        
        int j=0;
        for(int i=0;i<anArray.size();i++) {
        	if(anArray.get(i) > 0) {
        		array2.add(j,anArray.get(i));
        		j++;
        	}
        }
        System.out.println("Elementos positivos: "+array2.toString());
        
        System.out.println("Introduzca una posicion del array: ");
        pos = teclado.nextInt();
        
        if(pos < anArray.size()) {
        	 System.out.println("Introduzca un valor para esa posicion del array: ");
             num = teclado.nextInt();
              
              anArray.set(pos, num);
              System.out.println("Valores: " + anArray.toString());
           
        }
        else {
        	System.out.println("Posicion err�nea");
        }
        
        boolean res = false;
        System.out.println("Introduzca un valor a comprobar: ");
        num2 = teclado.nextInt();
        
        res = anArray.contains(num2);
        if(res) {
        	System.out.println("Numero est�");
        }
        else {
        	System.out.println("Numero no est�");
        }
        
        //Ver cuantas veces est� un numero en el array
        int cont2=0, aux=0;
        for(int i=0;i<anArray.size();i++) {
        	for(int k=0; k<anArray.size();k++) {
        		if(anArray.get(i).equals(anArray.get(k))) {
        			cont2++;
        			aux = i;
        			if(cont2 > 1) {
        				i++;
        			}
        		}
        	}
        	if(i<=10) {
        		i=aux;
        	}
        	
        	System.out.println("El valor "+anArray.get(i)+ " se repite: "+cont2);
        	cont2=0;
        }
        
        //Rotar a la derecha
        Collections.rotate(anArray, 1);
        /*//Rotar a la derecha de otra forma
        num = anArray.remove(anArray.size()-1);
        anArray.add(0, num);*/

        teclado.close();
	}
}

