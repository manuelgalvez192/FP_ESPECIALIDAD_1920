package EjerciciosFicheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class CopiarMitadaMitadFichero {

	public static void main(String[] args) throws IOException {

        BufferedReader inputStream = null;
        PrintWriter outputStream = null;
        PrintWriter outputStream2 = null;
        int cont=0, cont2=0;

        try {
        	inputStream = new BufferedReader(new FileReader("src/EjerciciosFicheros/xanadu.txt"));
            outputStream = new PrintWriter(new BufferedWriter(new FileWriter("src/EjerciciosFicheros/Ejercicio4a.txt")));
            outputStream2 = new PrintWriter(new BufferedWriter(new FileWriter("src/EjerciciosFicheros/Ejercicio4b.txt")));

            String l;
            while ((l = inputStream.readLine()) != null){
                 cont++;
            }
            String s;
            inputStream = new BufferedReader(new FileReader("src/EjerciciosFicheros/xanadu.txt"));
            while ((s = inputStream.readLine()) != null){
               if(cont2>=(cont/2)){
            	   outputStream2.println(s);
               }else {
            	   cont2++;
                   outputStream.println(s);
               }
               
           }
            

        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
            if (outputStream2 != null) {
                outputStream2.close();
            }
        }
    }
}
