package EjerciciosFicheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.Scanner;

public class CadenaTextoFichero {

	public static void main(String[] args) throws IOException{
		Scanner teclado = new Scanner(System.in);
		String s = "";
		StringReader in = null;
	    PrintWriter out = null;
		
	    System.out.println("Introduzca cadena de caracteres: ");
	    s = teclado.nextLine();
	    try {
	    	in = new StringReader(s);
	    	out = new PrintWriter(new BufferedWriter(new FileWriter("src/EjerciciosFicheros/Ejercicio1.txt")));
	    	
	    	int data = in.read();
	    	while(data != -1) {
	    	  out.write(data);

	    	  data = in.read();
	    	}
	    	
	    }finally {
	    	 if (in != null) {
	             in.close();
	         }
	         if (out != null) {
	             out.close();
	         }
	    }

	}

}
