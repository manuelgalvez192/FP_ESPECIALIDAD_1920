package EjerciciosFicheros;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MostrasFicheroYLineas {

	public static void main(String[] args) throws IOException {

        BufferedReader inputStream = null;
        
        int cont=0;
        try {
            inputStream = new BufferedReader(new FileReader("src/EjerciciosFicheros/xanadu.txt"));
           
            String l;
            while ((l = inputStream.readLine()) != null) {
            	cont++;
            	System.out.println(l);
            }
        } finally {
        	System.out.println("\nNumero de lineas: "+ cont);
            if (inputStream != null) {
                inputStream.close();
            }
            
        }
    }
}
