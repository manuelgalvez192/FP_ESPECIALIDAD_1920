package EjercicioMagosyDragonesV2;

import java.util.Comparator;

public class ComparadorAlfabetico implements Comparator<Personajes>{

	@Override
	public int compare(Personajes p1, Personajes p2) {
		
		return p1.getNombre().compareTo(p2.getNombre());
	}

}
