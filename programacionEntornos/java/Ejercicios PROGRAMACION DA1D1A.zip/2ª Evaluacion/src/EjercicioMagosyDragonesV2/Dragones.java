package EjercicioMagosyDragonesV2;

public class Dragones extends Personajes {

	private String color;
	private int contadorAtaques=0;
	private int contadorBajas=0;

	public Dragones(int id, int ataque, int pv) {
		super(id, ataque, pv);
		this.color = "Verde";
	}

	public int atacar(Personajes p) {
		if (p.getPv() > 0) {
			p.setPv(p.getPv() - this.getAtaque());	
			
			if (p.getPv()<=0) {
				this.contadorBajas++;
			}
			
			this.contadorAtaques++;
		}

		return p.getPv();
	}

	public void promocionar() {
		this.setColor("Rojo");
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void informe() {
		System.out.println("Numero de ataques: " + this.getContadorAtaques());
		System.out.println("Numero de bajas: " + this.getContadorBajas());
	}

	public int getContadorAtaques() {
		return contadorAtaques;
	}

	public void setContadorAtaques(int contadorAtaques) {
		this.contadorAtaques = contadorAtaques;
	}

	public int getContadorBajas() {
		return contadorBajas;
	}

	public void setContadorBajas(int contadorBajas) {
		this.contadorBajas = contadorBajas;
	}

	public String getColor() {
		return color;
	}
	
}
