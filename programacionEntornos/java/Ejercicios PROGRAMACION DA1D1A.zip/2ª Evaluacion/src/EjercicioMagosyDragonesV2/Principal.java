package EjercicioMagosyDragonesV2;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		ArrayList<Personajes> personajes = new ArrayList<>();
		for(int i=0; i<200;i++) {
			personajes.add(i, null);
		}

		int opcion1 = 0, opcion2 = 0, promocion = 0;
		int id = 1, ataque = 0, pv = 0, atacante = 0, atacado = 0;
		Personajes p1 = null, p2 = null, pers = null;

		System.out.println("1. A�adir personaje");
		System.out.println("2. Atacar");
		System.out.println("3. Promocionar");
		System.out.println("4. Informe");
		System.out.println("5. Salir");
		opcion1 = teclado.nextInt();

		do {
			switch (opcion1) {
			case 1:
				System.out.println("1. Introducir mago");
				System.out.println("2. Introducir dragon");
				opcion2 = teclado.nextInt();

				switch (opcion2) {
				case 1:
					System.out.println("Introduce un mago ");
					System.out.print("Introduce el ataque: ");
					ataque=teclado.nextInt();
					System.out.print("Introduce los puntos de vida: ");
					pv=teclado.nextInt();
					
					p1 = new Magos(id, ataque, pv);
					
					personajes.set(id, p1);
					personajes.add(p1);
					id++;
					System.out.println();
					break;
				case 2:
					System.out.println("Introduce un dragon ");
					System.out.print("Introduce el ataque: ");
					ataque=teclado.nextInt();
					System.out.print("Introduce los puntos de vida: ");
					pv=teclado.nextInt();
					
					p2 = new Dragones(id, ataque, pv);
					
					personajes.set(id, p2);
					id++;
					System.out.println();
					break;
				}

				break;
			case 2:
				System.out.print("Atacante: ");
				atacante = teclado.nextInt();
				System.out.print("Atacado: ");
				atacado = teclado.nextInt();
				
				pers=personajes.get(atacante);
				
				pers.atacar(personajes.get(atacante));
				
				System.out.println("Vida restante: " + personajes.get(atacado).getPv());
				
				break;
			case 3:
				System.out.println("Personaje a promocionar:");
				promocion=teclado.nextInt();
				pers=personajes.get(promocion);
				
				pers.promocionar();
				
				break;
			case 4:
				System.out.println("Informe del personaje:");
				promocion=teclado.nextInt();
				pers=personajes.get(promocion);
				
				pers.informe();
				
				break;
			}

			System.out.println("1. A�adir personaje");
			System.out.println("2. Atacar");
			System.out.println("3. Promocionar");
			System.out.println("4. Informe");
			System.out.println("5. Salir");
			opcion1 = teclado.nextInt();
		} while (opcion1 != 5);

		teclado.close();
	}

}
