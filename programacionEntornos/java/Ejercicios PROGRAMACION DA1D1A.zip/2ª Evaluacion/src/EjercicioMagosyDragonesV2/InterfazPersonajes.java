package EjercicioMagosyDragonesV2;

public interface InterfazPersonajes {
	String[] nombres = {"Doraemon", "Harlock", "Lucas"};
	
}
