package EjercicioMagosyDragonesV2;


public abstract class Personajes implements InterfazPersonajes{

	private int id;
	private int ataque;
	private int pv;
	private String nombre;

	private static int contadorAtaques=0;
	private static int contadorBajas=0;


	public Personajes(int id, int ataque, int pv) {
		this.id = id;
		this.ataque = ataque;
		this.pv = pv;
	}

	public abstract int atacar(Personajes p);
	
	public abstract void promocionar();
	
	public abstract void informe();


	public int getId() {
		return id;
	}


	public int getAtaque() {
		return ataque;
	}

	
	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}


	public int getPv() {
		return pv;
	}
	

	public void setPv(int pv) {
		this.pv = pv;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void asignarNombre() {
		int pos = 0;
		pos = (int)(Math.random() *InterfazPersonajes.nombres.length);
		this.nombre = InterfazPersonajes.nombres[pos];
	}
	
}
