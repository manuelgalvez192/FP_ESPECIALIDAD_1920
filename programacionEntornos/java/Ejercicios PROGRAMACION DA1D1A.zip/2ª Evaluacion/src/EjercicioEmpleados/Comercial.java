package EjercicioEmpleados;

public class Comercial extends Empleado{
	private double productividad;

	public Comercial(String nombre, String apellido, int[] tfno, String[] email, double salario, double productividad) {
		super(nombre, apellido, tfno, email, salario);
		this.productividad = productividad;
	}

	public double getProductividad() {
		return productividad;
	}

	public void setProductividad(int productividad) {
		this.productividad = productividad;
	}

	@Override
	public String toString() {
		return super.toString() + " Productividad: " + this.productividad;
	}
	
	
}
