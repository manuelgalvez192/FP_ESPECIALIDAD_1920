package EjercicioEmpleados;

import java.util.Comparator;

public class ComparadorEmpleadoProduc implements Comparator<Empleado>{

	@Override
	public int compare(Empleado o1, Empleado o2) {
		if(o1 != null && o2 != null) {
			if(o1 instanceof Comercial && o2 instanceof Comercial) {
				if(((Comercial) o1).getProductividad() < ((Comercial) o2).getProductividad()) {
					return -1;
				}
				if(((Comercial) o1).getProductividad() > ((Comercial) o2).getProductividad()) {
					return 1;
				}
			}
		}
		return 0;
	}

}
