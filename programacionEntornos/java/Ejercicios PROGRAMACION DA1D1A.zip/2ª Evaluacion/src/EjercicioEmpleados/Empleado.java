package EjercicioEmpleados;
//Empleados: nombre, apelidos, telefono(max 3), email(max 5), salario
	//maximo 1000 empleados
	//1.a�adir empleado, 2.modificar telefono(buscar por id), 3.modificar email(buscar id), 4.modificar salario(buscar por id)
	//5.borrar empleado(buscar por id), 6.listar empleados ordenados alfabeticamente por apellido
// 7. listar empleados ordenados alfabeticamente por apellido ydespues listar empleados ordenados alfabeticamente por nombre(dentro de apellidos)
	//8.listar empleados ordenados de menor a mayor salario
	//9.salir

import java.util.Arrays;

public class Empleado {
	private String nombre;
	private String apellido;
	private int[] tfno;
	private String[] email;
	private double salario;
	private int numTfnos;
	private int numEmails;
	private int id;
	private static int i=1;
	
	public Empleado(String nombre, String apellido, int[] tfno, String[] email, double salario) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.tfno = tfno;
		this.email = email;
		this.salario = salario;
		this.numTfnos = 0;
		this.numEmails = 0;
		this.id = i;
		i++;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public int[] getTfno() {
		return tfno;
	}

	public void setTfno(int[] tfno) {
		this.tfno = tfno;
	}

	public String[] getEmail() {
		return email;
	}

	public void setEmail(String[] email) {
		this.email = email;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}
		
	public int getNumTfnos() {
		return numTfnos;
	}

	public void setNumTfnos(int numTfnos) {
		this.numTfnos = numTfnos;
	}

	public int getNumEmails() {
		return numEmails;
	}

	public void setNumEmails(int numEmails) {
		this.numEmails = numEmails;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void anyadirTfno(int telefono) {
		if(this.numTfnos != this.tfno.length) {
			this.tfno[numTfnos] = telefono;
			numTfnos++;
		}
		else {
			return;
		}
	}
	
	public void modificarTfno(Sistema s, int id, int telefono1, int telefono2) {
		int pos = 0;
		for(Empleado e1: s.getEmpleados()) {
			if(e1.getId() == id) {
				if(this.numTfnos == this.tfno.length) {
					for(int aux: this.getTfno()) {
						if(aux == telefono1) {
							this.tfno[pos] = telefono2;
						}
						pos++;
					}
				}
				else {
					this.anyadirTfno(telefono2);
					return;
				}
			}
		}
		
	}
	
	public void anyadirEmail(String email) {
		if(this.numEmails != this.email.length) {
			this.email[numEmails] = email;
			numEmails++;
		}
		else {
			return;
		}
	}
	
	public void modificarEmail(Sistema s, int id, String email1, String email2) {
		int pos = 0;
		for(Empleado e1: s.getEmpleados()) {
			if(e1.getId() == id) {
				if(this.numEmails == this.email.length) {
					for(String aux: this.getEmail()) {
						if(aux == email1) {
							this.email[pos] = email2;
						}
						pos++;
					}
				}
				else {
					this.anyadirEmail(email2);
					return;
				}
			}
		}	
	}
	
	public void modificarSalario(Sistema s, int id, double salario) {
		for(Empleado e1: s.getEmpleados()) {
			if(e1.getId() == id) {
				this.salario = salario;
			}
		}
	}

	@Override
	public String toString() {
		return "Id: "+ id + " Nombre: " + nombre + " Apellido: " + apellido + " Tfno: " + Arrays.toString(tfno) + " Email: "
				+ Arrays.toString(email) + " Salario: " + salario;
	}
	
}
