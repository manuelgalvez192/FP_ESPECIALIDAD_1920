package EjercicioEmpleados;

public class Gerente extends Empleado{

	private int numAcciones;
	
	public Gerente(String nombre, String apellido, int[] tfno, String[] email, double salario, int numAcciones) {
		super(nombre, apellido, tfno, email, salario);
		this.numAcciones = numAcciones;
	}

	public int getNumAcciones() {
		return numAcciones;
	}

	public void setNumAcciones(int numAcciones) {
		this.numAcciones = numAcciones;
	}

	@Override
	public String toString() {
		return super.toString() + " numAcciones: " + this.numAcciones;
	}
	
	
}
