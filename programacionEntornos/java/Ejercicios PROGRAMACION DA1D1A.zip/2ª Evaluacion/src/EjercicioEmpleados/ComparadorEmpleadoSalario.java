package EjercicioEmpleados;

import java.util.Comparator;

public class ComparadorEmpleadoSalario implements Comparator<Empleado>{

	@Override
	public int compare(Empleado o1, Empleado o2) {
		if(o1 != null && o2 != null) {
			if(o1.getSalario() < o2.getSalario()) {
				return -1;
			}
			if(o1.getSalario() > o2.getSalario()) {
				return 1;
			}
		}
		return 0;
	}

}
