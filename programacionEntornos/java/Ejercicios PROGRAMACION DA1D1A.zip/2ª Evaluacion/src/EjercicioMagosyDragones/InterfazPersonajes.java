package EjercicioMagosyDragones;

public interface InterfazPersonajes {
	String[] nombres = {"Doraemon", "Harlock", "Lucas"};
	
}
