package EjercicioMagosyDragones;

public class Magos extends Personajes {

	private boolean puedeAtacar;
	private int contadorAtaques=0;
	private int contadorBajas=0;

	public Magos(int id, int ataque, int pv) {
		super(id, ataque, pv);
		this.puedeAtacar = true;
	}

	
	public int atacar(Personajes p) {
		if (p.getPv()>0) {
			if (puedeAtacar) {
				p.setPv(p.getPv()-this.getAtaque());
				if (p.getPv()<=0) {
					this.contadorBajas++;
				}
				
				this.contadorAtaques++;
				this.puedeAtacar=false;
			} else {
				this.puedeAtacar=true;
			}
		}
		return p.getPv();
	}

	public void promocionar() {
		
		this.setAtaque(this.getAtaque()+1);
	}

	public void informe() {
		System.out.println("Numero de ataques: " + this.getContadorAtaques());
		System.out.println("Numero de bajas: " + this.getContadorBajas());
	}


	public boolean isPuedeAtacar() {
		return puedeAtacar;
	}


	public void setPuedeAtacar(boolean puedeAtacar) {
		this.puedeAtacar = puedeAtacar;
	}


	public int getContadorAtaques() {
		return contadorAtaques;
	}


	public void setContadorAtaques(int contadorAtaques) {
		this.contadorAtaques = contadorAtaques;
	}


	public int getContadorBajas() {
		return contadorBajas;
	}


	public void setContadorBajas(int contadorBajas) {
		this.contadorBajas = contadorBajas;
	}
	
	
}
