package EjemplosHerencia;

public class Principal {

	public static void main(String[] args) {
//		Bicycle b1, b2, b3;
//		MountainBike m1, m2,m3;
//		
//		b1 = new Bicycle(0,0,0);
//		b2 = new Bicycle(1,0,1);
//		
//		m1 = new MountainBike(0,0,0,0);
////		m1.setHeight(45);
////		
////		System.out.println(m1);
//		b1 = m1;
//		if(b1 instanceof MountainBike) {
//			m2 = (MountainBike)b1;
//		}
		

	   
	        Cat myCat = new Cat();
	        Animal myAnimal = myCat;
	        Animal.testClassMethod();
	        myAnimal.testInstanceMethod();
	    

	}

}
