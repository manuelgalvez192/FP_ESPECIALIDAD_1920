package EjerciciosHerencia;

public class LlamadaProvincial extends Llamada{
	private final double franja1 = 0.2;
	private final double franja2 = 0.25;
	private final double franja3 = 0.3;
	private int hora;
	
	public LlamadaProvincial(int numeroOrigen, int numeroDest, int duracion, int hora) {
		super(numeroOrigen, numeroDest, duracion);
		this.hora = hora;
	}

	public double calcularCoste() {
		double total=0;
		
		if(this.hora >=0 && this.hora<=8) {
			total = this.duracion*this.franja1;
		}
		else if(this.hora >= 9 && this.hora <=16) {
			total = this.duracion*this.franja2;
		}
		else if(this.hora >=17 && this.hora <=23) {
			total = this.duracion*this.franja3;
		}
		
		return total;
	}
	@Override
	public String toString() {
		return super.toString() + " Hora: " + this.hora;
	}
	
	
	
}
