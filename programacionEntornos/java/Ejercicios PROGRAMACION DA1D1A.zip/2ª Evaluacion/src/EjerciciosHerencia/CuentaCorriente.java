package EjerciciosHerencia;

public class CuentaCorriente {
	protected Titular titular;
	protected String cuenta;
	protected double saldo;
	
	public CuentaCorriente(Titular titular, String cuenta, double saldo) {
		this.titular = titular;
		this.cuenta = cuenta;
		this.saldo = saldo;
	}

	public CuentaCorriente(Titular titular, String cuenta) {
		this.titular = titular;
		this.cuenta = cuenta;
		this.saldo = 15.3;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public Titular getTitular() {
		return titular;
	}

	public String getCuenta() {
		return cuenta;
	}
	
	public void ingresar(double cantidad) {
		this.saldo = this.saldo + cantidad;
	}
	
	public void reintegro(double cantidad) {
		this.saldo = this.saldo - cantidad;
	}
	
	public String toString() {
		return "Numero de cuenta: "+this.cuenta+ " Saldo: "+this.saldo;
	}
	
	public boolean compararCuentas(CuentaCorriente c1) {
		if(c1.cuenta.compareTo(this.cuenta) == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
}
