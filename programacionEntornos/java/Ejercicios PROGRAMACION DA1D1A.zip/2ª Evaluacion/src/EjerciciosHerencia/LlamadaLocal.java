package EjerciciosHerencia;

public class LlamadaLocal extends Llamada{
	private double coste;

	public LlamadaLocal(int numeroOrigen, int numeroDest, int duracion) {
		super(numeroOrigen, numeroDest, duracion);
		this.coste = 0.15;
	}
	
	public double calcularCoste() {
		double total=0;
		
		total = super.getDuracion() * coste;
		
		return total;
		
	}
	
	@Override
	public String toString() {
		return super.toString() + " Coste: " + this.coste;
	}
	
	
}
