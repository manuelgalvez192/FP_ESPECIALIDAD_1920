package EjerciciosHerencia;

public class MainLlamada {

	public static void main(String[] args) {
		
		Llamada[] llamadas = new Llamada[50];
		Centralita cent = new Centralita(llamadas);
		
		LlamadaProvincial l1 = new LlamadaProvincial(12345567, 987654321, 378, 15);
		LlamadaLocal l2 = new LlamadaLocal(12345678,987650987,134);
		LlamadaLocal l3 = new LlamadaLocal(12345678,987650987,34);
		
		double costelocal=0, costeprov=0;
		
		cent.addLlamada(l1);
		cent.addLlamada(l2);
		cent.addLlamada(l3);
		
		costelocal=l2.calcularCoste();
		System.out.println("Coste llamada local: " +costelocal + "�");
		
		costeprov=l1.calcularCoste();
		System.out.println("Coste llamada prov: " +costeprov + "�");
		
		cent.setFacturacion(cent.getFacturacion()+costelocal);
		cent.setFacturacion(cent.getFacturacion()+costeprov);
		
		System.out.println("Facturaci�n: " + cent.getFacturacion() + "�");
		System.out.println("Numero de llamadas: " + cent.getNumLlamadas());
		
		System.out.println("Datos de las llamadas guardadas en centralita: ");
		for(int j=0; j<llamadas.length;j++) {
			if(llamadas[j] != null) {
				System.out.println(llamadas[j].toString());
			}
			
		}
				
	}
		
}
