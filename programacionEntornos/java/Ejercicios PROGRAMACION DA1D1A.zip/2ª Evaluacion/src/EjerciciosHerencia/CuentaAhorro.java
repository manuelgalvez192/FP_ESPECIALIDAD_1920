package EjerciciosHerencia;

public class CuentaAhorro extends CuentaCorriente {
	private double interes;

	public CuentaAhorro(Titular titular, String cuenta, double saldo, double interes) {
		super(titular, cuenta, saldo);
		this.interes = interes;
	}
	public CuentaAhorro(Titular titular, String cuenta, double interes) {
		super(titular, cuenta);
		this.saldo = 15.3;
		this.interes = interes;
	}
	public CuentaAhorro(Titular titular, String cuenta) {
		super(titular, cuenta);
		this.saldo = 15.3;
		this.interes = 2.5;
	}
	public double getInteres() {
		return interes;
	}
	
	public Titular getTitular() {
		return super.titular;
	}

	public String getCuenta() {
		return super.cuenta;
	}
	
	public double getSaldo() {
		return super.saldo;
	}
	
	public void calcularInteres() {
		this.saldo = (this.saldo * this.interes)+this.saldo;
	}
	public String toString() {
		return super.toString() + " Interes: " + this.interes;
	}
}
