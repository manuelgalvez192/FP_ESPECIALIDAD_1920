package EjerciciosHerencia;

public class Centralita {
	private int numLlamadas;
	private double facturacion;
	private Llamada[] llamadas;
	
	public Centralita(Llamada[] llamadas) {
		this.numLlamadas = 0;
		this.facturacion = 0;
		this.llamadas = llamadas;
	}

	public int getNumLlamadas() {
		return numLlamadas;
	}

	public void setNumLlamadas(int numLlamadas) {
		this.numLlamadas = numLlamadas;
	}

	public double getFacturacion() {
		return facturacion;
	}

	public void setFacturacion(double facturacion) {
		this.facturacion = facturacion;
	}

	public Llamada[] getLlamadas() {
		return llamadas;
	}

	public void setLlamadas(Llamada[] llamadas) {
		this.llamadas = llamadas;
	}
	
	public void addLlamada(Llamada l1) {
		for(int i=this.numLlamadas; i<this.llamadas.length;i++) {
			this.llamadas[this.numLlamadas] = l1;
			
		}
		this.numLlamadas++;
	}
	
}
