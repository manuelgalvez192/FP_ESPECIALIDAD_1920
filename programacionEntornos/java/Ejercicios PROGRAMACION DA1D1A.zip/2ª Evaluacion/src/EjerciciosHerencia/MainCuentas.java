package EjerciciosHerencia;

import java.util.Scanner;

public class MainCuentas {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		CuentaCorriente c1, c3;
		CuentaAhorro c2, c4;
		Titular t1, t2;
		String nombre, apellido;
		int edad=0;
		double saldo=0, interes=0;
		boolean res=false;
		
		System.out.println("Introduzca nombre titular cuenta: ");
		nombre = teclado.nextLine();
		System.out.println("Introduzca apellido titular cuenta: ");
		apellido = teclado.nextLine();
		System.out.println("Introduzca su edad: ");
		edad = teclado.nextInt();
		
		t1 = new Titular(nombre, apellido, edad);
		t2 = new Titular("Juan", "G�mez", 56);
		
		c1 = new CuentaCorriente(t1, "1234567", 120);
		c2 = new CuentaAhorro(t1, "987654", 0.4);
		
		c3 = new CuentaCorriente(t2, "1234567");
		c4 = new CuentaAhorro(t2, "987654", 158, 0.9);
		
		if(c1 instanceof CuentaCorriente && c3 instanceof CuentaCorriente) {
			res = c1.compararCuentas(c3);
			if(res) {
				System.out.println("Mismas cuentas");
			}
			else {
				System.out.println("Distintas cuentas");
			}
		}
		else {
			System.out.println("No puedes compara dos cuentas que no sean del mismo tipo");
		}
		
		c1.ingresar(25);
		c2.calcularInteres();
		c3.reintegro(34);
		c4.reintegro(29);
		
		System.out.println(c1.toString());
		System.out.println(c2.toString());
		System.out.println(c3.toString());
		System.out.println(c4.toString());
		
	}

}
