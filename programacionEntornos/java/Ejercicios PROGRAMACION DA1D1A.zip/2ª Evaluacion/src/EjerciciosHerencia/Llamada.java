package EjerciciosHerencia;

public abstract class Llamada {
	protected int numeroOrigen;
	protected int numeroDest;
	protected int duracion;
	
	public Llamada(int numeroOrigen, int numeroDest, int duracion) {
		this.numeroOrigen = numeroOrigen;
		this.numeroDest = numeroDest;
		this.duracion = duracion;
	}

	public int getNumeroOrigen() {
		return numeroOrigen;
	}

	public void setNumeroOrigen(int numeroOrigen) {
		this.numeroOrigen = numeroOrigen;
	}

	public int getNumeroDest() {
		return numeroDest;
	}

	public void setNumeroDest(int numeroDest) {
		this.numeroDest = numeroDest;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	abstract double calcularCoste();
	
	@Override
	public String toString() {
		return "NumeroOrigen: " + this.numeroOrigen + " NumeroDest: " + this.numeroDest + " Duracion: " + this.duracion;
	}
	
	
}
