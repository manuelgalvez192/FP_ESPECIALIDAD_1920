package EjerciciosArbolesBinarios;

public class ArbolBinario {
	 private Nodo raiz;
	 
	    /* Contructories */    
	    public ArbolBinario(int valor) {
	        this.raiz = new Nodo( valor );
	    }
	 
	    public ArbolBinario( Nodo raiz ) {
	        this.raiz = raiz;
	    }
	 
	    /* Setters y Getters */
	    public Nodo getRaiz() {
	        return raiz;
	    }
	 
	    public void setRaiz(Nodo raiz) {
	        this.raiz = raiz;
	    }
	 	
}
