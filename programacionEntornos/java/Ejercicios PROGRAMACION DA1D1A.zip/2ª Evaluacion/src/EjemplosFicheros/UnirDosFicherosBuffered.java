package EjemplosFicheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class UnirDosFicherosBuffered {
	
		public static void main(String[] args) throws IOException {
			BufferedReader in= null, in2=null;
	        PrintWriter out = null;
			
			try {
				 in = new BufferedReader(new FileReader("src/EjemplosFicheros/xanadu.txt"));
				 in2 = new BufferedReader(new FileReader("src/EjemplosFicheros/xanadu.txt"));
		         out = new PrintWriter(new BufferedWriter(new FileWriter("src/EjemplosFicheros/dosficherosbuffered.txt")));

		            String l;
		            while ((l = in.readLine()) != null) {
		                out.println(l);
		            }
		            while ((l = in2.readLine()) != null) {
		                out.println(l);
		            }
		        } finally {
		            if (in != null) {
		                in.close();
		            }
		            if (in2 != null) {
		                in2.close();
		            }
		            if (out != null) {
		                out.close();
		            }
		        }
		    }

	}
