package EjemplosFicheros;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class EjemploFicheros {
    public static void main(String[] args) throws IOException {

        FileInputStream in = null;
        FileOutputStream out = null;
        int cont=0, cont2=0, cont3=0, enlaces=0;

        try {
            in = new FileInputStream("src/EjemplosFicheros/Ejercicio31.html");
            out = new FileOutputStream("src/EjemplosFicheros/enlaces.txt");
            int c;
            String s = new String();
            char car;

            while ((c = in.read()) != -1) {
//            	if(c == 65 || c == 97) {
//            		cont++;
//            	}
//            	if(c == 10) {
//            		cont2++;
//            	}
//                out.write(c);
               car = (char)c;
               if(car == '<') {
            	   s = ""+car;
            	   cont = 1;
               }
               else {
            	   if((cont > 0)&&(cont < 7)){
            		   s+=car;
            		   cont++;
            	   }
            	   else {
            		   if(cont == 7) {
            			   s+=car;
            			   if(s.equals("<a href=")) {
            				   enlaces++;
            			   }
            			   s="";
            			   cont=0;
            		   }
            	   }
               }
	            s = "Hay: "+enlaces+" numero de enlaces";
	            char caracter;
	            int escribir;
	            
	            for(int i=0; i<s.length();i++) {
	            	caracter = s.charAt(i);
	            	escribir = caracter;
	            	out.write(escribir);
	            }
            
            }
        } finally {
        	System.out.println("Numero de a/A: "+cont);
        	
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
    }
}

