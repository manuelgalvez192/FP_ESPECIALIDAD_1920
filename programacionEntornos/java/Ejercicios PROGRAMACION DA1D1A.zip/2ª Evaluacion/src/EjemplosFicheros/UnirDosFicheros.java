package EjemplosFicheros;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class UnirDosFicheros {

	public static void main(String[] args) throws IOException {
		 FileInputStream in = null, in2=null;
		 FileOutputStream out = null;
		
		try {
			in = new FileInputStream("src/EjemplosFicheros/xanadu.txt");
			in2 = new FileInputStream("src/EjemplosFicheros/xanadu.txt");
            out = new FileOutputStream("src/EjemplosFicheros/dosficheros.txt");
            int c=0;
            while ((c = in.read()) != -1) {
   			 out.write(c);
   		 	}
            while((c = in2.read()) !=-1) {
            	out.write(c);
            }
		}finally {
            if (in != null) {
                in.close();
            }
            if(in2 != null) {
            	in2.close();
            }
            if (out != null) {
                out.close();
            }
        }
		 
	}

}
