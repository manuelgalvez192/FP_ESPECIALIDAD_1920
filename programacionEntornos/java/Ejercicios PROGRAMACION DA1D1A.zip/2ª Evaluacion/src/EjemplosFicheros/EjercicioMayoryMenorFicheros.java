package EjemplosFicheros;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.io.IOException;
//fichero con numeros en cada linea, mostrar por pantalla el mayor y crear fchero que tenga lo negativos en cada linea

public class EjercicioMayoryMenorFicheros {
	public static void main(String[] args) throws IOException {

	    BufferedReader inputStream = null;
	    PrintWriter outputStream = null;
	    int num=0, mayor=0;
	
	    try {
	        inputStream = new BufferedReader(new FileReader("src/EjemplosFicheros/ficheronumeros.txt"));
	        outputStream = new PrintWriter(new BufferedWriter(new FileWriter("src/EjemplosFicheros/ficheronegativos.txt")));
	
	        String l, s;
	        s = inputStream.readLine();
	        mayor = Integer.parseInt(s);
	        if(mayor<0) {
	        	outputStream.println(s);
	        }
	        while ((l = inputStream.readLine()) != null) {
	        	if(l == " ") {
	        		l = inputStream.readLine();
	        	}
	        	else {
	        		num = Integer.parseInt(l);
		        	if(num < 0) {
		        		outputStream.println(l);
		        	}
		        	if(num > mayor) {
		        		mayor = num;
		        	}
//		        	if(l.contains("-")) {
//		        		outputStream.println(l);
//		        	}
	        	}
	        
	        	
	        }
	    } finally {
	    	System.out.println("Numero de mayor: "+ mayor);
	        if (inputStream != null) {
	            inputStream.close();
	        }
	        if (outputStream != null) {
	            outputStream.close();
	        }
	    }
	}
}
