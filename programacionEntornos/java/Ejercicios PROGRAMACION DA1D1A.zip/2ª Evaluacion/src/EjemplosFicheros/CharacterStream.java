package EjemplosFicheros;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class CharacterStream {
    public static void main(String[] args) throws IOException {

        BufferedReader inputStream = null;
        PrintWriter outputStream = null;
        int cont=0, cont2=0, cont3=0;

        try {
            inputStream = new BufferedReader(new FileReader("src/EjemplosFicheros/Ejercicio31.html"));
            outputStream = new PrintWriter(new BufferedWriter(new FileWriter("src/EjemplosFicheros/ejemplohtml.html")));

            String l;
            while ((l = inputStream.readLine()) != null) {
            	for(int i=0; i<l.length();i++) {
            		if(l.charAt(i) == 'a' || l.charAt(i) == 'A') {
            			cont++;
            		}
            	}
            	cont2++;
            	if(l.contains("<a href=")) {
            		cont3++;
            	}
            	
                outputStream.println(l);
            }
        } finally {
        	System.out.println("Numero de a/A: "+ cont);
        	System.out.println("Numero de lineas: "+ cont2);
        	System.out.println("Numero de enlaces: "+cont3);
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
        }
    }
}