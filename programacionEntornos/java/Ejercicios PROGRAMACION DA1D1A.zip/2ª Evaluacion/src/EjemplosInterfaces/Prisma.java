package EjemplosInterfaces;

public class Prisma implements Relatable{
	public int ladoa;
	public int ladob;
	public int height;
	
	public Prisma(int ladoa, int ladob, int height) {
		this.ladoa = ladoa;
		this.ladob = ladob;
		this.height = height;
	}

	public int getVolumen() {
	   return this.ladoa * this.ladob *this.height;
	}
	
	@Override
	public int isLargerThan(Relatable other) {
		if(other instanceof Prisma) {
			 Prisma otherRect 
	            = (Prisma)other;
	        if (this.getVolumen() < otherRect.getVolumen())
	            return -1;
	        else if (this.getVolumen() > otherRect.getVolumen())
	            return 1;
	        else
	            return 0;  
		}
		else {
			return -2;
		}
		
	}
}
