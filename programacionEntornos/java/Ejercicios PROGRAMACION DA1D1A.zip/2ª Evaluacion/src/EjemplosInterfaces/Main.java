package EjemplosInterfaces;

import java.util.Scanner;

// Main que pida dats para crear planetas y prismas rectangulares, y comparar cual es mayor(planetas con planetas)

public class Main {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int rad1=0, rad2=0, a1=0, b1=0, h1=0, a2=0, b2=0, h2=0;
		Planeta p1 = null;
		Planeta p2 = null;
		Prisma pr = null;
		Prisma pr2 = null;
		int res=0;
		
		System.out.println("Introduzca radio Planeta 1: ");
		rad1 = teclado.nextInt();
		p1 = new Planeta(rad1);
		
		System.out.println("Introduzca radio Planeta 2: ");
		rad2 = teclado.nextInt();
		p2 = new Planeta(rad2);
		
		System.out.println("Introduzca lado a del Prisma 1: ");
		a1 = teclado.nextInt();
		System.out.println("Introduzca lado b del Prisma 1: ");
		b1 = teclado.nextInt();
		System.out.println("Introduzca altura del Prisma 1: ");
		h1 = teclado.nextInt();
		pr = new Prisma(a1, b1, h1);
		
		System.out.println("Introduzca lado a del Prisma 2: ");
		a2 = teclado.nextInt();
		System.out.println("Introduzca lado b del Prisma 2: ");
		b2 = teclado.nextInt();
		System.out.println("Introduzca altura del Prisma 2: ");
		h2 = teclado.nextInt();
		pr2 = new Prisma(a2, b2, h2);
		
		res = p1.isLargerThan(pr);
		if(res == 0) {
			System.out.println("Iguales de tama�o");
		}
		else if(res == 1) {
			System.out.println("Mayor de tama�o");
		}
		else if(res == -1) {
			System.out.println("Menor de tama�o");
		}
		else if(res == -2) {
			System.out.println("Distintos objetos a comparar");
		}
		
		res = 0;
		res = p1.isLargerThan(p2);
		if(res == 0) {
			System.out.println("Iguales de tama�o");
		}
		else if(res == 1) {
			System.out.println("Mayor de tama�o");
		}
		else if(res == -1) {
			System.out.println("Menor de tama�o");
		}
		else if(res == -2) {
			System.out.println("Distintos objetos a comparar");
		}
		
		res = 0;
		res = pr2.isLargerThan(pr);
		if(res == 0) {
			System.out.println("Iguales de tama�o");
		}
		else if(res == 1) {
			System.out.println("Mayor de tama�o");
		}
		else if(res == -1) {
			System.out.println("Menor de tama�o");
		}
		else if(res == -2) {
			System.out.println("Distintos objetos a comparar");
		}
		teclado.close();
		
		res = 0;
		res = pr2.isLargerThan(p2);
		if(res == 0) {
			System.out.println("Iguales de tama�o");
		}
		else if(res == 1) {
			System.out.println("Mayor de tama�o");
		}
		else if(res == -1) {
			System.out.println("Menor de tama�o");
		}
		else if(res == -2) {
			System.out.println("Distintos objetos a comparar");
		}
		teclado.close();
	}

} 