package EjemplosInterfaces;

public class Planeta implements Relatable{
	public int radio;
	
	public Planeta(int radio) {
		this.radio = radio;
	}

	@Override
	public int isLargerThan(Relatable other) {
		if(other instanceof Planeta) {
			 Planeta otherRect 
	            = (Planeta)other;
	        if (this.radio < otherRect.radio)
	            return -1;
	        else if (this.radio > radio)
	            return 1;
	        else
	            return 0;  
		}
		else {
			return -2;
		}
		
	}
	
}
