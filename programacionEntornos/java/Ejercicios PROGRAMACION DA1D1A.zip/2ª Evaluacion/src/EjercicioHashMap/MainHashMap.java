package EjercicioHashMap;

import java.util.HashMap;
import java.util.Scanner;

public class MainHashMap {

	public static void main(String[] args) {
		// Crear una aplicaci�n que almacene en un HashMap un diccionario (una palabra y su definici�n). 
		// Se podr� buscar la definici�n de una palabra, borrar una palabra y a�adir una palabra.
		
		HashMap<String, String> dicc = new HashMap<>();
		Scanner teclado = new Scanner(System.in);
		String palabra = "casa";
		String desc = "Construcci�n cubierta destinada a ser habitada.";
		String def = "", pl = "";
		dicc.put(palabra, desc);
		dicc.put("coche", "Veh�culo autom�vil de cuatro ruedas para circular por tierra, que se dirige mediante un volante y est� destinado al transporte de personas.");
		dicc.put("papel", "Pedazo rectangular de ese material laminado en blanco, manuscrito o impreso.");
		dicc.put("teclado", "Conjunto de teclas de un instrumento musical o de una m�quina o mecanismo.");
		int opcion = 0;
		boolean res = false;
		
		while(opcion !=4) {
			System.out.println("Elija opcion: ");
			System.out.println("1. Buscar definicion palabra ");
			System.out.println("2. Borrar palabra ");
			System.out.println("3. A�adir palabra ");
			opcion = teclado.nextInt();
			
			switch(opcion) {
			
			case 1: 
				teclado.nextLine();
				System.out.println("Introduzca la palabra de la que desea obtener la descripcion: ");
				def = teclado.nextLine();
				def = def.toLowerCase();
			
				res = dicc.containsKey(def);
				if(res) {
					System.out.println(dicc.get(def));
				}
				else {
					System.out.println("La palabra no se encuentra en el diccionario");
				}
				break;
				
			case 2:
				teclado.nextLine();
				System.out.println("Introduzca la palabra de la que desea borrar: ");
				def = teclado.nextLine();
				//def = def.replace(def.charAt(0),Character.toUpperCase(def.charAt(0)));
				def = def.toLowerCase();
				
				res = dicc.containsKey(def);
				if(res) {
					dicc.remove(def);
				}
				else {
					System.out.println("La palabra no se encuentra en el diccionario");
				}
				break;
			case 3:
				teclado.nextLine();
				System.out.println("Introduzca la palabra de la que desea a�adir: ");
				def = teclado.nextLine();
				//def = def.replace(def.charAt(0),Character.toUpperCase(def.charAt(0)));
				def = def.toLowerCase();
				System.out.println("Introduzca la definicion de la palabra: ");
				pl = teclado.nextLine();
				//pl = pl.replace(pl.charAt(0), Character.toUpperCase(pl.charAt(0)));
				pl = pl.toLowerCase();
				
				dicc.put(def, pl);
				break;
			case 4:
				System.out.println("Adios");
				break;
			default:
				System.out.println("Opcion erronea");
			}
		}
		
		teclado.close();
	}
	
}
