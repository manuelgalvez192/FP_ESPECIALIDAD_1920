package EjemplosExcepciones;

public class PruebaListOfNumbers {

	public static void main(String[] args) {
		ListOfNumbers l = new ListOfNumbers();
		l.writeList();

	}

}
