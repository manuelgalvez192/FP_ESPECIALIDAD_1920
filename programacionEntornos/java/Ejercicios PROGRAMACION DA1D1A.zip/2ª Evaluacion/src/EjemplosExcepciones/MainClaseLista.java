package EjemplosExcepciones;

public class MainClaseLista {

	public static void main(String[] args) {
		ClaseLista cl = new ClaseLista();
		Object ob = null;
		
		
		try {
			cl.objectAt(3);
		} catch (InvalidIndexException e) {
			System.out.println("Excepcion InvalidIndex");
			e.printStackTrace();
		}
		
		try {
			cl.firstObject();
		}catch (ObjectNotFundException e) {
			System.out.println("Excepcion ObjectNotFund");
			e.printStackTrace();
		}

		try {
			cl.indexOf(ob);
		}catch (InvalidIndexException e) {
			System.out.println("Excepcion InvalidIndex");
			e.printStackTrace();
		}
	}

}
