package EjemplosExcepciones;

public class MiExcepcion extends Exception{

	public MiExcepcion() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MiExcepcion(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public MiExcepcion(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MiExcepcion(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MiExcepcion(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
