package EjemplosExcepciones;

public class EmptyListException extends ObjectNotFundException{

	private static final long serialVersionUID = 1L;

	public EmptyListException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmptyListException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EmptyListException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmptyListException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmptyListException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
