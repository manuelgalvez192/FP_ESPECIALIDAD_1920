package EjemplosExcepciones;

import java.util.ArrayList;

public class ClaseLista {
	private ArrayList<Object> list = new ArrayList<>();

	//	indexOf(Object o) � Searches the list for the specified Object and returns its position in the list. Throws an exception if the object passed into the method is not in the list.
	public Object objectAt(int n) throws InvalidIndexException {
		if(n<0 || n>list.size()) {
			throw new InvalidIndexException();
			
		}			
		return list.get(n);
	}
	public Object firstObject() throws ObjectNotFundException{
		
		if(list.size() == 0) {
			throw new ObjectNotFundException();
		}
		
		return list.get(0);
	}
	
	public int indexOf(Object o) throws InvalidIndexException{
		int pos = 0;
		
		for(Object ob: this.list) {
			if(ob == o) {
				return pos;
			}
			pos++;
		}
		
		throw new InvalidIndexException();
	}
}
