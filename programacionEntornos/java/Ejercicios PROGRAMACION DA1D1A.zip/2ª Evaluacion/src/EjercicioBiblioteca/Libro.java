package EjercicioBiblioteca;

public class Libro extends Material{
	private String editorial;
	
	public Libro(int id, String titulo, String autor, String editorial) {
		super(id, titulo, autor);
		this.editorial = editorial;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	@Override
	public String toString() {
		return super.toString() + " Editorial: " + this.editorial;
	}
	
	
	
}
