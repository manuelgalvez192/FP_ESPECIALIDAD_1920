package EjercicioBiblioteca;

public class Biblioteca {
	private Material[] material;
	private Usuario[] usuarios;
	private int numMaterial;
	private int numUsuarios;
	
	public Biblioteca(Material[] material, Usuario[] usuarios) {
		
		this.material = material;
		this.usuarios = usuarios;
		this.numMaterial = 0;
		this.numUsuarios = 0;
	}

	public Material[] getMaterial() {
		return material;
	}

	public void setMaterial(Material[] material) {
		this.material = material;
	}

	public Usuario[] getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Usuario[] usuarios) {
		this.usuarios = usuarios;
	}

	public int getNumMaterial() {
		return numMaterial;
	}

	public void setNumMaterial(int numMaterial) {
		this.numMaterial = numMaterial;
	}

	public int getNumUsuarios() {
		return numUsuarios;
	}

	public void setNumUsuarios(int numUsuarios) {
		this.numUsuarios = numUsuarios;
	}
	
	public void addSocio(Socio s1) {
		for(int i=this.numUsuarios; i< this.usuarios.length;i++) {
			this.usuarios[this.numUsuarios] = s1;
		}
		this.numUsuarios++;
	}
	
	public void addAdmin(Admin a1) {
		for(int i=this.numUsuarios; i< this.usuarios.length;i++) {
			this.usuarios[this.numUsuarios] = a1;
		}
		this.numUsuarios++;
	}
	
	public void addLector(Lector l1) {
		for(int i=this.numUsuarios; i< this.usuarios.length;i++) {
			this.usuarios[this.numUsuarios] = l1;
		}
		this.numUsuarios++;
	}
	public void addMaterial(Material m1) {
		for(int i=this.numMaterial; i< this.material.length;i++) {
			this.material[this.numMaterial] = m1;
		}
		this.numMaterial++;
	}
	public void removeSocio(Socio s1) {
		int contador=0;
		for(Usuario s2: this.usuarios) {
			if(s2 == s1) {
				this.usuarios[contador] = null;
			}
			contador++;
		}
	}
	public void removeLector(Lector l1) {
		int contador=0;
		for(Usuario s2: this.usuarios) {
			if(s2 == l1) {
				this.usuarios[contador] = null;
			}
			contador++;
		}
	}
	public void removeMaterial(Material m1) {
		int contador=0;
		for(Material m2: this.material) {
			if(m2 == m1) {
				this.material[contador] = null;
			}
			contador++;
		}
	}
	public void listarUsuarios() {
		for(Usuario u1: this.usuarios) {
			if(u1 != null) {
				System.out.println(u1.toString());
			}
			
		}
	}
}
