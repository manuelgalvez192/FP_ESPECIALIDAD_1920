package EjercicioBiblioteca;

public class Lector extends Usuario{
	private String dni;
	
	public Lector(int id, String contrase�a, String dni) {
		super(id, contrase�a);
		this.dni = dni;
	}
	
	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public boolean leerEnSala(Biblioteca b1, String dni, String titulo) {
		boolean res = false;
		
		for(Usuario u1: b1.getUsuarios()) {
			if(u1 instanceof Lector) {
				if(((Lector) u1).getDni() == dni) {
					for(Material m2: b1.getMaterial()) {
						if(m2.getTitulo() == titulo) {
							res = true;
							return res;
						}
					}
					
				}
			}
		}
		return res;
	}
	
	public void devolverMaterial(Biblioteca b1, Material m1) {
		int pos = 0;
		for(Material m2: b1.getMaterial()) {
			if(m2 == null) {
				b1.getMaterial()[pos] = m1;
				return;
			}
			pos++;
		}
	}
	public void listarCatalogo(Biblioteca b1) {
		for(Material m2: b1.getMaterial()) {
			if(m2 != null) {
				System.out.println(m2.toString());
			}
			
		}
	}
	public boolean buscarPorTitulo(Biblioteca b1, String titulo) {
		boolean res = false;
		for(Material m2: b1.getMaterial()) {
			if(m2 == null) {
				return res;
			}
			else if(m2.getTitulo() == titulo) {
				res = true;
			}
		}
		
		return res;
	}
	
	@Override
	public String toString() {
		return super.toString()+ " Dni: "+ this.dni;
	}
	
	
}
