package EjercicioBiblioteca;

	// TIPOS USUARIOS: ADMIN(LISTAR SOCIOS Y LECTORES, DAR DE ALTA y BAJA SOCIOS Y LECTORES, DAR DE ALTA Y BAJA MATERIAL), 
	// LECTORES Y SOCIOS(DEVOLVER MATERIAL, LEER EN SALA, CONSULTAR CATALOGO, BUSCAR POR TITULO)
	// LECTORES(LEER EN SALA NECESARIO DNI)
	// SOCIOS(COGER PRESTAMO)
	// MATERIAL(ID, TITULO Y AUTOR): REVISTAS(NUMERO Y A�O DE PUBLICACION), LIBROS (EDITORIAL)
	// PRESTAMO PARA REGISTRAR

public class Admin extends Usuario{
	
	public Admin(int id, String contrase�a) {
		super(id, contrase�a);
	}
	
	public void listarSocios(Biblioteca b1) {
		for(Usuario u1: b1.getUsuarios()) {
			if(u1 instanceof Socio) {
				System.out.println(u1.toString());
			}
		}
	}
	
	public void listarLector(Biblioteca b1) {
		for(Usuario u1: b1.getUsuarios()) {
			if(u1 instanceof Lector) {
				System.out.println(u1.toString());
			}
		}
	}
	
	public void addSocio(Biblioteca b1, Socio s1) {
		
		if(b1.getNumUsuarios() == b1.getUsuarios().length) {
			for(Usuario s2: b1.getUsuarios()) {
				if(s2 == null) {
					b1.addSocio(s1);
				}
			}
		}
		else {
			b1.addSocio(s1);
		}
		
	}
	
	public void addLector(Biblioteca b1, Lector l1) {
		if(b1.getNumUsuarios() == b1.getUsuarios().length) {
			for(Usuario s2: b1.getUsuarios()) {
				if(s2 == null) {
					b1.addLector(l1);
				}
			}
		}
		else {
			b1.addLector(l1);
		}
		
	}
	
	public void addMaterial(Biblioteca b1, Material m1) {
		if(b1.getNumMaterial() == b1.getMaterial().length) {
			for(Material s2: b1.getMaterial()) {
				if(s2 == null) {
					b1.addMaterial(m1);
				}
			}
		}
		else {
			b1.addMaterial(m1);
		}
		
	}
	
	public void removeSocio(Biblioteca b1, Socio s1) {
		b1.removeSocio(s1);
	}
	
	public void removeLector(Biblioteca b1, Lector l1) {
		b1.removeLector(l1);
	}
	
	public void removeMaterial(Biblioteca b1, Material m1) {
		b1.removeMaterial(m1);
	}
	
	
}
