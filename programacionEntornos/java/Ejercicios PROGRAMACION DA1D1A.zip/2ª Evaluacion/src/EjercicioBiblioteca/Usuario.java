package EjercicioBiblioteca;

//BIBLIOTECA: USUARIOS(ID, CONTRASE�A)
	// TIPOS USUARIOS: ADMIN(LISTAR SOCIOS Y LECTORES, DAR DE ALTA SOCIOS Y LECTORES, DAR DE ALTA Y BAJA MATERIAL), 
	// LECTORES Y SOCIOS(DEVOLVER MATERIAL, LEER EN SALA, CONSULTAR CATALOGO, BUSCAR POR TITULO)
	// LECTORES(LEER EN SALA NECESARIO DNI)
	// SOCIOS(COGER PRESTAMO)
	// MATERIAL(ID, TITULO Y AUTOR): REVISTAS(NUMERO Y A�O DE PUBLICACION), LIBROS (EDITORIAL)
	// PRESTAMO PARA REGISTRAR

public class Usuario {
	protected int id;
	protected String contrase�a;
	
	public Usuario(int id, String contrase�a) {
		this.id = id;
		this.contrase�a = contrase�a;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContrase�a() {
		return contrase�a;
	}

	public void setContrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}

	@Override
	public String toString() {
		return "Id: " + this.id + " Contrase�a: " + this.contrase�a;
	}
	
	
}
