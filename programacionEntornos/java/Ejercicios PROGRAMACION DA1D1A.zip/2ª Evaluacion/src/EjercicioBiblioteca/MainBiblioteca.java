package EjercicioBiblioteca;

public class MainBiblioteca {

	public static void main(String[] args) {
		Biblioteca b1 = null;
		Material[] m1 = new Material[100];
		Usuario[] u1 = new Usuario[100];
		Socio s1 = new Socio(123,"12345", "34567890D");
		Lector l1 = new Lector(345,"45678", "12345890D");
		Admin a1 = new Admin(000, "00000");
		Libro lb1 = new Libro(145,"La Casa de Bernarda Alba", "Garcia-Lorca", "Planeta");
		Material m3 = new Material(879, "Las Rosas", "Juan");
		Material m2 = null;
		Libro lb2 = new Libro(98, "El Se�or de las Moscas", "William Golding", "Alianza Editorial");
		Revista rv1 = new Revista(678, "Computer Hoy", "Desconocido");
		Revista rv2 = new Revista(234, "Vanity Fair", "Cond� Nast Publications");
		boolean res=false;
		b1 = new Biblioteca(m1,u1);
		
		a1.addSocio(b1,s1);
		a1.addLector(b1, l1);
		b1.addAdmin(a1);
		a1.addMaterial(b1,m3);
		a1.addMaterial(b1,lb1);
		a1.addMaterial(b1, rv1);
		
		res = l1.leerEnSala(b1, "12345890D", "Las Rosas");
		if(res) {
			System.out.println("Libro obtenido para leer en sala\n");
		}
		else {
			System.out.println("Libro no disponible\n");
		}
		
		System.out.println("Lista de Material de la Biblioteca:");
		l1.listarCatalogo(b1);
		System.out.println();
		
		m2 = s1.cogerPrestamo(b1, lb1);
		System.out.println("Material obtenido en prestamo: " +m2.toString() +"\n");
		System.out.println("Lista de Material de la Biblioteca:");
		l1.listarCatalogo(b1);
		System.out.println();
		
		res = false;
		
		res = l1.buscarPorTitulo(b1, "El Se�or de las Moscas");
		if(res) {
			System.out.println("El libro existe en la Biblioteca\n");
		}
		else {
			System.out.println("Libro no encontrado\n");
		}
		
		s1.devolverMaterial(b1, lb2);
		System.out.println("Material devuelto: " + lb2.toString() +"\n");
		System.out.println("Lista de Material de la Biblioteca:");
		s1.listarCatalogo(b1);
		System.out.println();
		
		l1.devolverMaterial(b1, rv2);
		System.out.println("Material devuelto: " + rv2.toString() +"\n");
		System.out.println("Lista de Material de la Biblioteca:");
		l1.listarCatalogo(b1);
		System.out.println();
		
		System.out.println("Lista de Usuarios de la Biblioteca: ");
		b1.listarUsuarios();
		System.out.println();
		a1.removeLector(b1, l1);
		
		System.out.println("Usuario eliminado: " +l1.toString() +"\n");
		System.out.println("Lista de Usuarios de la Biblioteca: ");
		b1.listarUsuarios();
		System.out.println();
		
		
	}

}
