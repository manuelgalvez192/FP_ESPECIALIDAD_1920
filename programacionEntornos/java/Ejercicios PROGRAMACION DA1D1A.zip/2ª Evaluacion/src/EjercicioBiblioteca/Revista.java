package EjercicioBiblioteca;

public class Revista extends Material{
	private int numero;
	private int dia;
	private int mes;
	private int anyo;
	
	public Revista(int id, String titulo, String autor) {
		super(id, titulo, autor);
		this.numero = 5;//((int)Math.random()*10);
		this.dia = 20;//(int)(((int)Math.random()*100)/3.2);
		this.mes = 2;//(int)(((int)Math.random()*100)/8.2);
		this.anyo = 2010;//(int)Math.random()*1000;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		this.dia = dia;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		this.mes = mes;
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		this.anyo = anyo;
	}

	@Override
	public String toString() {
		return super.toString() + " Numero: " + this.numero + " del: " + this.dia + "/" + this.mes + "/" + this.anyo;
	}
	
	
	
}
