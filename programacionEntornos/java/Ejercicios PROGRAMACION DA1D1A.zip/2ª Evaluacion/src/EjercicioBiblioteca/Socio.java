package EjercicioBiblioteca;

	//LECTORES Y SOCIOS(DEVOLVER MATERIAL, LEER EN SALA, CONSULTAR CATALOGO, BUSCAR POR TITULO)
	// LECTORES(LEER EN SALA NECESARIO DNI)
	// SOCIOS(COGER PRESTAMO)
public class Socio extends Usuario{
	private int codSocio;
	private String dni;
	
	public Socio(int id, String contrase�a, String dni) {
		super(id, contrase�a);
		this.dni = dni;
		this.codSocio = ((int)Math.random()*100);
	}

	public int getCodSocio() {
		return codSocio;
	}

	public void setCodSocio(int codSocio) {
		this.codSocio = codSocio;
	}
		
	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public void devolverMaterial(Biblioteca b1, Material m1) {
		int pos = 0;
		for(Material m2: b1.getMaterial()) {
			if(m2 == null) {
				b1.getMaterial()[pos] = m1;
				return;
			}
			pos++;
		}
	}
	public void listarCatalogo(Biblioteca b1) {
		for(Material m2: b1.getMaterial()) {
			if(m2 != null) {
				System.out.println(m2.toString());
			}			
		}
	}
	public boolean buscarPorTitulo(Biblioteca b1, String titulo) {
		boolean res = false;
		for(Material m2: b1.getMaterial()) {
			if(m2 == null) {
				return res;
			}
			else if(m2.getTitulo() == titulo) {
				res = true;
			}
			
		}
		
		return res;
	}
	
	public boolean leerEnSala(Biblioteca b1, String titulo) {
		boolean res = false;
		
		for(Usuario u1: b1.getUsuarios()) {
			if(u1 instanceof Socio) {
					for(Material m2: b1.getMaterial()) {
						if(m2.getTitulo() == titulo) {
							res = true;
							return res;
						}
					}
					
				}
			}
	
		return res;

	}
	
	public Material cogerPrestamo(Biblioteca b1, Material m1) {
		Material m2 = null;
		int pos=0;
		for(Material m3: b1.getMaterial()) {
			if(m3 == m1) {
				m2 = b1.getMaterial()[pos];
				b1.getMaterial()[pos] = null;
			}
			pos++;
		}
			
		
		return m2;
	}
	
	@Override
	public String toString() {
		return super.toString() + " Dni: "+ this.dni + " CodSocio: " + this.codSocio;
	}
	
}
