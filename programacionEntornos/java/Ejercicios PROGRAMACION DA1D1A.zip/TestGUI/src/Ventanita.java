import java.awt.EventQueue;
/*Cuando pulsar, primero nada, luego aparece hola en el jlabel la primera vez y adios la segunda*/

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Ventanita {

	private JFrame frame;
	private JTextField textField;
	private JLabel lblNewLabel;
	private int contador=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventanita window = new Ventanita();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Ventanita() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(36, 51, 71, 34);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Pulsa");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(contador == 0) {
					lblNewLabel.setText("Hola");
					contador = 1;
				}
				else{
					lblNewLabel.setText("Adios");
					contador = 0;
				}
			}
		});
		btnNewButton.setBounds(36, 143, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(140, 58, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.setBounds(153, 143, 89, 23);
		frame.getContentPane().add(btnSalir);
	}
}
