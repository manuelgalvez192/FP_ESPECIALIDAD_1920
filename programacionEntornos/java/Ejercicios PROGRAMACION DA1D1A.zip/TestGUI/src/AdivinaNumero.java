import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/*Adivina un numero, jtextfield entre 0 y 100, siete intentos, cada vez que pulsa decirle que ha acertado 
 * o que ha fallado siendo mayor o menor que el que se quiere adivinar*/
public class AdivinaNumero {

	private JFrame frame;
	private JTextField textField;
	private int numero;
	//private int adivinar = (int)(Math.random()*10)+1;
	private int adivinar = 56;
	private int contador=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdivinaNumero window = new AdivinaNumero();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdivinaNumero() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNmero = new JLabel("Introduzca n\u00FAmero entre 1 y 100");
		lblNmero.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNmero.setBounds(85, 25, 262, 43);
		frame.getContentPane().add(lblNmero);
		
		textField = new JTextField();
		textField.setBounds(85, 80, 262, 43);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnComprobar = new JButton("Comprobar");
		btnComprobar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//while(contador != 7) {
					numero = Integer.parseInt(textField.getText());
					if(numero == adivinar) {
						JOptionPane.showMessageDialog(frame, "Numero acertado");
						frame.setVisible(false);
					}
					if(numero > 0 && numero < adivinar) {
						JOptionPane.showMessageDialog(frame, "Numero menor que el deseado");
						textField.setText("");
						//contador++;
					}
					if(numero < 100 && numero > adivinar) {
						JOptionPane.showMessageDialog(frame, "Numero mayor que el deseado");
						textField.setText("");
						//contador++;
					}
					if(numero < 0 || numero > 100) {
						JOptionPane.showMessageDialog(frame, "Numero incorrecto");
						textField.setText("");
					}
				//}
				
			}
		});
		btnComprobar.setBounds(155, 157, 121, 43);
		frame.getContentPane().add(btnComprobar);
	}

}
