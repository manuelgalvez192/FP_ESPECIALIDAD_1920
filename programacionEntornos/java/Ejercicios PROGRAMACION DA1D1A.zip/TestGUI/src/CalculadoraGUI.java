import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SwingConstants;

public class CalculadoraGUI {

	private JFrame frame;
	private JTextField textField;
	private char simbolo;
	private int cont=1;
	private int num0=0;
	private int num1=1;
	private int num2=2;
	private int num3=3;
	private int num4=4;
	private int num5=5;
	private int num6=6;
	private int num7=7;
	private int num8=8;
	private int num9=9;
	private int suma1, suma2, resta1, resta2;
	private int elevado, elevado2;
	private int mult, mult2;
	private int div, div2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalculadoraGUI window = new CalculadoraGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CalculadoraGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.BLUE);
		frame.getContentPane().setForeground(Color.YELLOW);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(34, 21, 377, 48);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton button = new JButton("7");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num7));
			}
		});
		button.setBounds(153, 93, 45, 23);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("8");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText(Integer.toString(num8));
			}
		});
		button_1.setBounds(208, 93, 45, 23);
		frame.getContentPane().add(button_1);
		
		JButton button_2 = new JButton("9");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num9));
			}
		});
		button_2.setBounds(263, 93, 45, 23);
		frame.getContentPane().add(button_2);
		
		JButton button_3 = new JButton("4");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num4));
			}
		});
		button_3.setBounds(153, 127, 45, 23);
		frame.getContentPane().add(button_3);
		
		JButton button_4 = new JButton("5");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num5));
			}
		});
		button_4.setBounds(208, 127, 45, 23);
		frame.getContentPane().add(button_4);
		
		JButton button_5 = new JButton("6");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num6));
			}
		});
		button_5.setBounds(263, 127, 45, 23);
		frame.getContentPane().add(button_5);
		
		JButton button_6 = new JButton("1");
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num1));
			}
		});
		button_6.setBounds(153, 165, 45, 23);
		frame.getContentPane().add(button_6);
		
		JButton button_7 = new JButton("2");
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num2));
			}
		});
		button_7.setBounds(208, 165, 45, 23);
		frame.getContentPane().add(button_7);
		
		JButton button_8 = new JButton("3");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num3));
			}
		});
		button_8.setBounds(263, 165, 45, 23);
		frame.getContentPane().add(button_8);
		
		JButton button_9 = new JButton("+");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				simbolo = '+';
				
				suma1 = Integer.parseInt(textField.getText());
								
			}
		});
		button_9.setBounds(27, 80, 89, 23);
		frame.getContentPane().add(button_9);
		
		JButton button_10 = new JButton("-");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				simbolo = '-';
				
				resta1 = Integer.parseInt(textField.getText());
			}
		});
		button_10.setBounds(27, 114, 89, 23);
		frame.getContentPane().add(button_10);
		
		JButton button_11 = new JButton("*");
		button_11.setVerticalAlignment(SwingConstants.BOTTOM);
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				simbolo = '*';
				
				mult = Integer.parseInt(textField.getText());
			}
		});
		button_11.setBounds(27, 148, 89, 23);
		frame.getContentPane().add(button_11);
		
		JButton button_12 = new JButton("/");
		button_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				simbolo = '/';
				
				div = Integer.parseInt(textField.getText());
			}
		});
		button_12.setBounds(27, 182, 89, 23);
		frame.getContentPane().add(button_12);
		
		JButton btnPow = new JButton("^");
		btnPow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				simbolo = '^';
				
				elevado = Integer.parseInt(textField.getText());
			}
		});
		btnPow.setBounds(27, 216, 89, 23);
		frame.getContentPane().add(btnPow);
		
		JButton button_13 = new JButton("0");
		button_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num0));
			}
		});
		button_13.setBounds(188, 199, 89, 23);
		frame.getContentPane().add(button_13);
		
		JButton button_14 = new JButton("=");
		button_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(simbolo == '+') {
					suma2 = Integer.parseInt(textField.getText());
					textField.setText(Integer.toString(suma1 = Calculadora.suma(suma1, suma2)));
				}
				if(simbolo == '-') {
					resta2 = Integer.parseInt(textField.getText());
					textField.setText(Integer.toString(resta1 = Calculadora.resta(resta1, resta2)));
				}
				if(simbolo == '*') {
					mult2 = Integer.parseInt(textField.getText());
					textField.setText(Integer.toString(mult = Calculadora.producto(mult, mult2)));
				}
				if(simbolo == '/') {
					div2 = Integer.parseInt(textField.getText());
					textField.setText(Integer.toString(div = Calculadora.division(div, div2)));
				}
				if(simbolo == '^') {
					elevado2 = Integer.parseInt(textField.getText());
					textField.setText(Integer.toString(elevado = Calculadora.potencia(elevado, elevado2)));
				}
			}
		});
		button_14.setBounds(335, 199, 89, 23);
		frame.getContentPane().add(button_14);
		
		JButton btnCe = new JButton("CE");
		btnCe.setBounds(335, 93, 89, 23);
		frame.getContentPane().add(btnCe);
	}
}
