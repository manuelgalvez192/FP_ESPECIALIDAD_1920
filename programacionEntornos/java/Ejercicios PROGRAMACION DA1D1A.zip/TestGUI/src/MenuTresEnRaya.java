import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuTresEnRaya {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuTresEnRaya window = new MenuTresEnRaya();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MenuTresEnRaya() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
	
		
		JLabel lblNewLabel = new JLabel("Men\u00FA");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 40));
		lblNewLabel.setBounds(10, 11, 414, 59);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("J1 VS J2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TresEnRayaGUI window2 = new TresEnRayaGUI();
				frame.setVisible(false);
				window2.getFrame().setVisible(true);
			}
		});
		btnNewButton.setBounds(114, 81, 207, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton button = new JButton("J1 VS CPU");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TresEnRayaGUI window3 = new TresEnRayaGUI();
				frame.setVisible(false);
				window3.getFrame().setVisible(true);
			}
		});
		button.setBounds(114, 115, 207, 23);
		frame.getContentPane().add(button);
		
		JButton button_1 = new JButton("Salir");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		button_1.setBounds(114, 149, 207, 23);
		frame.getContentPane().add(button_1);
	}
}
